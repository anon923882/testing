# Motif 1.4.1 QA (Android)

* Fixes Downloads scrolling by bounding the scroll container to the WebView viewport; #app remains clipped to keep the navigation anchored.
* Restores missing `async_timeout` required by the pinned `zeroconf==0.39.4` library on Python 3.11.
* Centralizes all Chaquopy Python requirements in app/build.gradle so they are identical in local and CI builds.
* Uses a side-by-side Android application ID `com.motif.player.qa` (label `Motif QA`) so the previously-installed Motif doesn't need to be removed. Data remains separate, and this isn't an update to the existing app.
* Regression checks assert scrolling and the dependency is packaged.

Critical: Spotify Premium OAuth and independent audio export are still NOT verified on a physical Android device. That requires an authenticated device test and may not work with provider restrictions. The build does not claim otherwise.
