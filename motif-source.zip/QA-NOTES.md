Motif v1.4 QA beta
===================
- Downloads UI condensed for phones; provider icons use brand silhouettes from Simple Icons.
- Python Spotify dependencies explicitly packaged: urllib3, idna, certifi, charset-normalizer, ifaddr, librespot and its declared dependencies.
- Spotify authentication preflight reports missing imports instead of silently failing.
- 9 Spotify unit tests and CI mobile browser regression suite.
- A persistent local QA signing key is used from this version onward. It cannot update the prior ephemeral-debug-key APK. Keep this keystore private for future upgrades.
- No authenticated Spotify Premium extraction test has been possible without a test account/device. A successful compile does not certify provider sign-in.
