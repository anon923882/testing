package com.motif.player;
import org.junit.Test;
import static org.junit.Assert.*;
public class TrackTagsTest {
 @Test public void musicVideoTitle() {
   String[] t=TrackTags.guess("Living In A Box - Living In A Box (Official Music Video)","Uploader");
   assertEquals("Living In A Box",t[0]);assertEquals("Living In A Box",t[1]);
 }
 @Test public void topicChannel(){
   String[] t=TrackTags.guess("A Real Song","Artist - Topic");
   assertEquals("A Real Song",t[0]);assertEquals("Artist",t[1]);
 }
 @Test public void noFalseArtist(){
   String[] t=TrackTags.guess("Track without a separator",null);
   assertEquals("Unknown artist",t[1]);
 }
 @Test public void musicVideoSuffix(){
   String[] t=TrackTags.guess("Björk - Army of Me [Official Video]","channel");
   assertEquals("Army of Me",t[0]);assertEquals("Björk",t[1]);
 }
}