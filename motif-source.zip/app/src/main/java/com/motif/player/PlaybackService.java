package com.motif.player;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;

/** Background playback, notification, headset / lock-screen controls. No audio leaves the device. */
public final class PlaybackService extends Service implements AudioManager.OnAudioFocusChangeListener {
    interface Listener {void onPlaybackState(String json);}
    static volatile Listener listener;
    public static final String ACTION_PLAY="com.motif.player.PLAY";
    public static final String ACTION_TOGGLE="com.motif.player.TOGGLE";
    public static final String ACTION_NEXT="com.motif.player.NEXT";
    public static final String ACTION_PREVIOUS="com.motif.player.PREVIOUS";
    public static final String ACTION_SEEK="com.motif.player.SEEK";
    public static final String ACTION_SHUFFLE="com.motif.player.SHUFFLE";
    public static final String ACTION_REPEAT="com.motif.player.REPEAT";
    public static final String ACTION_QUEUE="com.motif.player.QUEUE";
    private static final String CHANNEL="motif_playback";
    private static final int NOTIF_ID=1207;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final List<String> queue=new ArrayList<>();
    private final Map<String, JSONObject> catalog=new HashMap<>();
    private final Random random=new Random();
    private MediaPlayer player;
    private MediaSession session;
    private AudioManager audioManager;
    private String currentId=null;
    private String title="Motif",artist="Music";
    private boolean ready=false,playing=false,foreground=false,shuffle=false;
    private int repeat=0;
    private int duration=0;
    private final Runnable tick=new Runnable(){@Override public void run(){publish();if(playing)main.postDelayed(this,850);}};
    private final BroadcastReceiver noisy=new BroadcastReceiver(){@Override public void onReceive(Context ctx, Intent i){pause();}};
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){
        super.onCreate();
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"Music playback",NotificationManager.IMPORTANCE_LOW);ch.setDescription("Playback controls");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}
        session=new MediaSession(this,"Motif");
        session.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){resume();}
            @Override public void onPause(){pause();}
            @Override public void onSkipToNext(){skip(1);}
            @Override public void onSkipToPrevious(){skip(-1);}
            @Override public void onSeekTo(long ms){seek(ms);}
            @Override public void onStop(){pause();}
        });
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS|MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setActive(true);
        registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_STICKY;
        String action=intent.getAction();if(action==null)return START_STICKY;
        switch(action){
            case ACTION_PLAY:
                shuffle=intent.getBooleanExtra("shuffle",false);repeat=intent.getIntExtra("repeat",0);
                setQueue(intent.getStringExtra("queue"));playId(intent.getStringExtra("id"));break;
            case ACTION_TOGGLE:if(playing)pause();else resume();break;
            case ACTION_NEXT:skip(1);break;
            case ACTION_PREVIOUS:skip(-1);break;
            case ACTION_SEEK:seek(intent.getLongExtra("seek",0));break;
            case ACTION_SHUFFLE:shuffle=intent.getBooleanExtra("shuffle",false);publish();break;
            case ACTION_REPEAT:repeat=intent.getIntExtra("repeat",0);publish();break;
            case ACTION_QUEUE:setQueue(intent.getStringExtra("queue"));break;
            default:break;
        }
        return START_STICKY;
    }
    private void setQueue(String json){
        if(json==null)return;
        try{
            JSONArray ids=new JSONArray(json);queue.clear();catalog.clear();
            for(int i=0;i<ids.length();i++){
                JSONObject item=ids.optJSONObject(i);
                if(item!=null){String id=item.optString("id","");if(!id.isEmpty()){queue.add(id);catalog.put(id,item);}}
                else queue.add(ids.getString(i));
            }
        }
        catch(Exception ignored){}
    }
    private void playId(String id){
        if(id==null||id.isEmpty())return;
        currentId=id;ready=false;playing=false;
        if(player!=null){try{player.reset();player.release();}catch(Exception ignored){}player=null;}
        try{
            player=new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setOnPreparedListener(p->{ready=true;duration=p.getDuration();resume();});
            player.setOnCompletionListener(p->{if(repeat==2){seek(0);resume();}else skip(1);});
            player.setOnErrorListener((p,what,extra)->{pause();return true;});
            JSONObject item=catalog.get(id);
            Uri uri=item!=null&&item.has("uri") ? Uri.parse(item.optString("uri")) :
                    Uri.withAppendedPath(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
            player.setDataSource(this,uri);
            if(item!=null){title=item.optString("title","Music");artist=item.optString("artist","Unknown artist");}
            else updateTrackInfo(id);
            // Required immediately after startForegroundService on Android O+.
            showNotification();
            player.prepareAsync();
        }catch(Exception ex){ready=false;playing=false;publish();stopForeground(true);foreground=false;}
    }
    private void updateTrackInfo(String id){
        try(android.database.Cursor c=getContentResolver().query(Uri.withAppendedPath(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id),
                new String[]{android.provider.MediaStore.Audio.Media.TITLE,android.provider.MediaStore.Audio.Media.ARTIST},null,null,null)){
            if(c!=null&&c.moveToFirst()) {title=c.getString(0);artist=c.getString(1);}
        }catch(Exception ignored){title="Music";artist="Motif";}
        if(title==null)title="Music";if(artist==null)artist="Unknown artist";
    }
    private void resume(){
        if(player==null||!ready)return;
        audioManager.requestAudioFocus(this,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);
        player.start();playing=true;showNotification();updateSession();main.removeCallbacks(tick);main.post(tick);
    }
    private void pause(){
        if(player!=null&&ready&&playing)player.pause();
        playing=false;main.removeCallbacks(tick);updateSession();showNotification();publish();
        audioManager.abandonAudioFocus(this);
    }
    private void seek(long ms){if(player!=null&&ready){player.seekTo((int)Math.min(Integer.MAX_VALUE,Math.max(0,ms)));publish();}}
    private void skip(int step){
        if(queue.isEmpty()){pause();return;}
        int index=queue.indexOf(currentId);
        int next=shuffle?random.nextInt(queue.size()):index+step;
        if(next>=queue.size()||next<0){if(repeat==1)next=(next+queue.size())%queue.size();else{pause();seek(0);return;}}
        playId(queue.get(next));
    }
    private void updateSession(){
        long actions=PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|
                PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_SEEK_TO;
        int state=playing?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED;
        long position=player!=null&&ready?player.getCurrentPosition():0;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions).setState(state,position,playing?1:0).build());
        session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST,artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION,duration).build());
    }
    private PendingIntent control(String action,int code){
        Intent intent=new Intent(this,PlaybackService.class).setAction(action);
        return PendingIntent.getService(this,code,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void showNotification(){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,11,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        nb.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(artist)
          .setContentIntent(pi).setShowWhen(false).setVisibility(Notification.VISIBILITY_PUBLIC)
          .setOngoing(playing)
          .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Previous",control(ACTION_PREVIOUS,1)).build())
          .addAction(new Notification.Action.Builder(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing?"Pause":"Play",control(ACTION_TOGGLE,2)).build())
          .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Next",control(ACTION_NEXT,3)).build());
        nb.setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        Notification n=nb.build();
        if(!foreground){startForeground(NOTIF_ID,n);foreground=true;}
        else ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID,n);
    }
    private void publish(){
        Listener l=listener;if(l==null)return;
        try{JSONObject o=new JSONObject();o.put("id",currentId);o.put("playing",playing);
            o.put("position",player!=null&&ready?player.getCurrentPosition():0);o.put("duration",duration);
            l.onPlaybackState(o.toString());}catch(Exception ignored){}
    }
    @Override public void onAudioFocusChange(int focus){
        if(focus==AudioManager.AUDIOFOCUS_LOSS||focus==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT)pause();
        else if(focus==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK&&player!=null)player.setVolume(.25f,.25f);
        else if(focus==AudioManager.AUDIOFOCUS_GAIN&&player!=null)player.setVolume(1,1);
    }
    @Override public void onDestroy(){
        main.removeCallbacks(tick);
        try{unregisterReceiver(noisy);}catch(Exception ignored){}
        if(player!=null){player.release();player=null;}
        if(session!=null){session.setActive(false);session.release();}
        audioManager.abandonAudioFocus(this);
        super.onDestroy();
    }
}
