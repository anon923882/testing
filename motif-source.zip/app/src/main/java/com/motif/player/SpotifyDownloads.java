package com.motif.player;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Experimental Spotify Premium engine host. Runs an embedded Python/librespot
 * process inside Motif, not on a PC, server, or companion application.
 *
 * Integration is not considered production-ready until Chaquopy's Android
 * wheels, OAuth redirect, MediaStore commit, and actual playback are tested.
 */
public final class SpotifyDownloads {
    public interface Events {
        void send(String json);
        void libraryChanged();
    }
    private static volatile WeakReference<SpotifyDownloads> instance = new WeakReference<>(null);
    private final Activity activity;
    private final Events events;
    private final ExecutorService queue = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean closed;

    public SpotifyDownloads(Activity activity, Events events) {
        this.activity = activity;
        this.events = events;
        instance = new WeakReference<>(this);
    }
    private File privateDir() { return new File(activity.getFilesDir(), "spotify"); }
    private PyObject module() {
        if (!Python.isStarted()) Python.start(new AndroidPlatform(activity.getApplicationContext()));
        return Python.getInstance().getModule("motif_spotify");
    }
    private void send(JSONObject data) {
        ui.post(() -> { if (!closed) events.send(data.toString()); });
    }
    private void emitError(Exception e) {
        JSONObject j = new JSONObject();
        try { j.put("type", "error"); j.put("provider", "spotify");
              String message = e.getMessage();
              j.put("message", message == null ? "Spotify engine failed" : message); }
        catch (Exception ignored) {}
        send(j);
    }
    private void runPython(String operation, String link) {
        queue.execute(() -> {
            try {
                PyObject python = module();
                PyObject result = operation.equals("inspect")
                    ? python.callAttr("inspect", privateDir().getAbsolutePath(), link)
                    : python.callAttr("connect", privateDir().getAbsolutePath());
                send(new JSONObject(result.toString()));
            } catch (Exception e) { emitError(e); }
        });
    }
    public void connect() {
        try {send(new JSONObject().put("type","spotify-connecting").put("provider","spotify")
            .put("message","Preparing Spotify authentication…"));} catch(Exception ignored){}
        runPython("connect", "");
    }
    public void inspect(String link) { runPython("inspect", link); }
    public void download(String link, String proposedTitle) {
        final String jobId = UUID.randomUUID().toString();
        try {
            send(new JSONObject().put("type", "job").put("provider", "spotify")
                .put("id", jobId).put("title", proposedTitle == null || proposedTitle.isEmpty() ? "Spotify audio" : proposedTitle)
                .put("status", "queued").put("progress", 0));
        } catch (Exception ignored) {}
        queue.execute(() -> {
            try {
                PyObject result = module().callAttr("download", privateDir().getAbsolutePath(), link, jobId);
                JSONObject payload = new JSONObject(result.toString());
                File source = new File(payload.getString("path"));
                // Never trust a file path from the browser. Only the embedded
                // Python engine emits the path, and it must be a private temp file.
                File safeRoot = new File(privateDir(), "temp_audio").getCanonicalFile();
                if (!source.getCanonicalFile().getParentFile().equals(safeRoot))
                    throw new SecurityException("Unexpected audio output path");
                SavedAudio saved = commitAudio(source, payload.getJSONObject("metadata"));
                source.delete();
                send(new JSONObject().put("type", "job").put("provider", "spotify")
                        .put("id", jobId).put("status", "complete").put("progress", 100)
                        .put("uri", saved.uri.toString()).put("filename",saved.filename)
                        .put("message",TrackTags.autoAdd(activity)?"Added to music library":"Saved; add to library when ready"));
                ui.post(events::libraryChanged);
            } catch (Exception e) {
                try { send(new JSONObject().put("type", "job").put("provider", "spotify")
                        .put("id", jobId).put("status", e.getMessage() != null && e.getMessage().contains("Cancelled") ? "cancelled" : "failed").put("progress", 0)
                        .put("message", e.getMessage() == null ? "Failed" : e.getMessage())); }
                catch (Exception ignored) {}
            }
        });
    }
    public void cancel(String jobId) {
        // Cancellation must not queue behind an in-progress transfer.
        new Thread(() -> {
            try { module().callAttr("cancel", jobId); }
            catch (Exception ignored) {}
        }, "spotify-cancel").start();
    }
    public static void report(String id, String status, int progress, String message) {
        SpotifyDownloads handler = instance.get();
        if (handler == null || handler.closed) return;
        try {
            handler.send(new JSONObject().put("type", "job").put("provider", "spotify")
                    .put("id", id).put("status", status).put("progress", progress)
                    .put("message", message));
        } catch (Exception ignored) {}
    }
    public static void openAuthUrl(String url) {
        SpotifyDownloads handler = instance.get();
        if (handler == null) return;
        // Only the Spotify authentication host may be opened. Do not accept an
        // arbitrary URL from the WebView or downloaded metadata.
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equals(uri.getScheme())) throw new SecurityException("Auth URL must use HTTPS");
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (!(host.equals("accounts.spotify.com") || host.equals("open.spotify.com")))
                throw new SecurityException("Unexpected authentication destination");
            handler.send(new JSONObject().put("type","spotify-login-opening")
                .put("message","Opening Spotify sign-in in your browser"));
            handler.ui.post(() -> {
                try {handler.activity.startActivity(new Intent(Intent.ACTION_VIEW, uri)
                    .addCategory(Intent.CATEGORY_BROWSABLE));}
                catch (Exception ex) {handler.emitError(ex);}
            });
        } catch (Exception e) { handler.emitError(e); }
    }
    private static final class SavedAudio {
        final Uri uri; final String filename;
        SavedAudio(Uri uri, String filename) {this.uri=uri;this.filename=filename;}
    }
    private SavedAudio commitAudio(File source, JSONObject meta) throws Exception {
        String title = meta.optString("title", "Track");
        String cleanName = title.replaceAll("[^a-zA-Z0-9 ._()-]", "_");
        if (cleanName.length() > 100) cleanName = cleanName.substring(0, 100);
        String filename = cleanName + "-" + UUID.randomUUID().toString().substring(0, 8) + ".ogg";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/ogg");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Motif/");
            values.put(MediaStore.Audio.Media.TITLE, title);
            values.put(MediaStore.Audio.Media.ARTIST, meta.optString("artist", "Unknown artist"));
            values.put(MediaStore.Audio.Media.ALBUM, meta.optString("album", ""));
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = activity.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("MediaStore declined to save audio");
            try {
                try (FileInputStream in = new FileInputStream(source);
                     OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Cannot open audio destination");
                    byte[] buffer = new byte[64 * 1024];
                    for (int n; (n = in.read(buffer)) != -1;) out.write(buffer, 0, n);
                }
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                activity.getContentResolver().update(uri, values, null, null);
                TrackTags.save(activity,filename,title,meta.optString("artist","Unknown artist"),meta.optString("album",""));
                TrackTags.downloadCompleted(activity,filename);
                return new SavedAudio(uri,filename);
            } catch (Exception error) {
                activity.getContentResolver().delete(uri, null, null);
                throw error;
            }
        }
        // Android <10 fallback, app-owned music directory; these versions may
        // need an additional WRITE_EXTERNAL_STORAGE request for public Music/.
        File dir = new File(activity.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Motif");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IllegalStateException("Cannot create music directory");
        File target = new File(dir, filename);
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[64 * 1024];
            for (int n; (n = in.read(buffer)) != -1;) out.write(buffer, 0, n);
        }
        MediaScannerConnection.scanFile(activity, new String[]{target.toString()},
                new String[]{"audio/ogg"}, null);
        TrackTags.save(activity,filename,title,meta.optString("artist","Unknown artist"),meta.optString("album",""));
        TrackTags.downloadCompleted(activity,filename);
        return new SavedAudio(Uri.fromFile(target),filename);
    }
    public void close() {
        closed = true;
        queue.shutdownNow();
    }
}
