package com.motif.player;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.ClipData;
import android.media.MediaMetadataRetriever;
import android.provider.OpenableColumns;
import java.util.LinkedHashSet;
import java.util.Set;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowInsets;
import android.view.View;
import android.widget.FrameLayout;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Motif's native host. No networking or remote accounts. The Android music catalog
 * is read via MediaStore; audio is played by PlaybackService outside the WebView.
 */
public final class MainActivity extends Activity implements PlaybackService.Listener {
    private static final int REQUEST_AUDIO = 234;
    private static final int REQUEST_PICKER = 235;
    private static final int REQUEST_IMPORT = 236;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService scanner = Executors.newSingleThreadExecutor();
    private WebView web;
    private YouTubeDownloads downloader;
    private SpotifyDownloads spotify;
    private ValueCallback<Uri[]> filePicker;
    private volatile boolean destroyed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(12,14,14));
        window.setNavigationBarColor(Color.rgb(12,14,14));
        downloader = new YouTubeDownloads(this, new YouTubeDownloads.Events() {
            @Override public void send(String payload) { invokeJS("window.motifScrapeEvent && window.motifScrapeEvent(" + JSONObject.quote(payload) + ")"); }
            @Override public void libraryChanged() { main.postDelayed(MainActivity.this::scanLibrary,1000); }
        });
        spotify = new SpotifyDownloads(this, new SpotifyDownloads.Events() {
            @Override public void send(String payload) { invokeJS("window.motifScrapeEvent && window.motifScrapeEvent(" + JSONObject.quote(payload) + ")"); }
            @Override public void libraryChanged() { main.postDelayed(MainActivity.this::scanLibrary, 1000); }
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(12,14,14));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "MotifAndroid");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePicker != null) filePicker.onReceiveValue(null);
                filePicker = callback;
                try {
                    startActivityForResult(params.createIntent(), REQUEST_PICKER);
                    return true;
                } catch (Exception ex) {
                    filePicker = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        // Android 15+ draws apps edge-to-edge by default. Apply real system
        // insets to the native host, not CSS env() guesses, so toolbar actions
        // cannot sit behind the status icons or camera cutout.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(12,14,14));
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets sys = insets.getInsets(
                    WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars() | WindowInsets.Type.displayCutout());
                view.setPadding(sys.left,sys.top,sys.right,sys.bottom);
                return insets;
            });
            root.requestApplyInsets();
        } else {
            root.setFitsSystemWindows(true);
        }
        setContentView(root);
        PlaybackService.listener = this;
        web.loadUrl("file:///android_asset/index.html");
    }

    private String permission() {
        return Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
    }
    private boolean hasPermission() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission()) == PackageManager.PERMISSION_GRANTED;
    }
    private void requireLibrary() {
        if (hasPermission()) scanLibrary();
        else requestPermissions(new String[]{permission()}, REQUEST_AUDIO);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_AUDIO) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) scanLibrary();
            else invokeJS("window.motifPermissionDenied && window.motifPermissionDenied()");
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQUEST_IMPORT && result == RESULT_OK && data != null) {
            Set<String> imported=new LinkedHashSet<>(getPreferences(0).getStringSet("imported",new LinkedHashSet<>()));
            if(data.getData()!=null) addImported(imported,data.getData());
            ClipData clips=data.getClipData();
            if(clips!=null)for(int i=0;i<clips.getItemCount();i++)addImported(imported,clips.getItemAt(i).getUri());
            getPreferences(0).edit().putStringSet("imported",imported).apply();
            scanLibrary();
        }
        if (request == REQUEST_PICKER && filePicker != null) {
            filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            filePicker = null;
        }
    }
    private void addImported(Set<String> imported, Uri uri){
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        imported.add(uri.toString());
    }
    private void chooseAudioFiles(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent,REQUEST_IMPORT);
    }
    private void scanLibrary() {
        scanner.execute(() -> {
            try {
                JSONArray tracks = new JSONArray();
                Set<String> seenUris=new LinkedHashSet<>();
                long total = 0;
                Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                String[] columns = {
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE,
                    MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DATE_ADDED,
                    MediaStore.Audio.Media.DISPLAY_NAME
                };
                try (Cursor c = hasPermission() ? getContentResolver().query(base, columns,
                        MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " > 0",
                        null, MediaStore.Audio.Media.DATE_ADDED + " DESC") : null) {
                    if (c != null) {
                        while (c.moveToNext()) {
                            long id = c.getLong(0), ms = c.getLong(4), bytes = Math.max(0, c.getLong(5)), albumId = c.getLong(6);
                            String name=c.getString(8);
                            if(TrackTags.hidden(this,name)) continue;
                            JSONObject overrides=TrackTags.get(this,name);
                            String title=known(c.getString(1),"Untitled");
                            String artist=known(c.getString(2),"Unknown artist");
                            String album=known(c.getString(3),"Unknown album");
                            if(overrides!=null){
                                title=overrides.optString("title",title);
                                artist=overrides.optString("artist",artist);
                                album=overrides.optString("album",album);
                            } else if("Unknown artist".equals(artist) && name!=null) {
                                String[] guessed=TrackTags.guess(name.replaceFirst("\\.[^.]+$","")
                                    .replaceFirst("-[a-zA-Z0-9_-]{11}$",""),"");
                                if(!"Unknown artist".equals(guessed[1])){artist=guessed[1];title=guessed[0];}
                            }
                            JSONObject t = new JSONObject();
                            t.put("id", Long.toString(id));
                            t.put("title",title);
                            t.put("artist",artist);
                            t.put("album",album);
                            t.put("seconds", Math.max(1,ms / 1000));
                            t.put("bytes", bytes);
                            t.put("dateAdded", c.getLong(7));
                            String mediaUri=ContentUris.withAppendedId(base,id).toString();
                            t.put("uri", mediaUri);
                            seenUris.add(mediaUri);
                            if (albumId > 0) t.put("cover", ContentUris.withAppendedId(
                                    Uri.parse("content://media/external/audio/albumart"),albumId).toString());
                            tracks.put(t);
                            total += bytes;
                        }
                    }
                }
                // SAF imports can come from folders and providers not indexed in MediaStore.
                for(String savedUri:getPreferences(0).getStringSet("imported",new LinkedHashSet<>())){
                    try{
                        Uri uri=Uri.parse(savedUri);
                        if(seenUris.contains(savedUri)) continue;
                        String filename="Audio track",title=null,artist=null,album=null;
                        long bytes=0,ms=0;
                        try(Cursor meta=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
                            if(meta!=null&&meta.moveToFirst()){
                                filename=meta.getString(0);
                                bytes=meta.isNull(1)?0:meta.getLong(1);
                            }
                        }
                        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
                        try{
                            retriever.setDataSource(this,uri);
                            title=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                            artist=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                            album=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                            String duration=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                            if(duration!=null)ms=Long.parseLong(duration);
                        }finally{retriever.release();}
                        String cleanFile=filename.replaceFirst("\\.[^.]+$", "")
                            .replaceFirst("-[a-zA-Z0-9_-]{11}$", "");
                        if("Unknown artist".equals(known(artist,"Unknown artist"))) {
                            String[] inferred=TrackTags.guess(cleanFile, "");
                            if(!"Unknown artist".equals(inferred[1])) {artist=inferred[1];title=inferred[0];}
                        }
                        JSONObject t=new JSONObject();
                        t.put("id","saf-"+Integer.toHexString(savedUri.hashCode()));
                        t.put("title",known(title,filename.replaceFirst("\\.[^.]+$","")));
                        t.put("artist",known(artist,"Unknown artist"));
                        t.put("album",known(album,"Unknown album"));
                        t.put("seconds",Math.max(1,ms/1000));
                        t.put("bytes",bytes);
                        t.put("uri",uri.toString());
                        t.put("dateAdded",System.currentTimeMillis()/1000);
                        tracks.put(t);total+=bytes;
                    }catch(Exception ignored){}
                }
                StatFs fs = new StatFs(Environment.getExternalStorageDirectory().getPath());
                JSONObject payload = new JSONObject();
                payload.put("tracks",tracks);
                payload.put("totalBytes",total);
                payload.put("freeBytes",fs.getAvailableBytes());
                invokeJS("window.motifLibraryReceived(" + JSONObject.quote(payload.toString()) + ")");
            } catch (Exception ex) {
                invokeJS("window.motifNativeError && window.motifNativeError(" + JSONObject.quote("Music scan failed: " + ex.getMessage()) + ")");
            }
        });
    }
    private String known(String text, String fallback) {
        return text == null || text.trim().isEmpty() || text.startsWith("<unknown") ? fallback : text;
    }
    private void invokeJS(String script) {
        main.post(() -> { if (!destroyed && web != null) web.evaluateJavascript(script,null); });
    }
    @Override public void onPlaybackState(String json) {
        invokeJS("window.motifPlaybackReceived(" + JSONObject.quote(json) + ")");
    }
    private void command(String cmd, String id, String queue, boolean shuffle, int repeat, long seek) {
        main.post(() -> {
            Intent intent = new Intent(this,PlaybackService.class).setAction(cmd);
            if(id!=null)intent.putExtra("id",id);
            if(queue!=null)intent.putExtra("queue",queue);
            intent.putExtra("shuffle",shuffle);
            intent.putExtra("repeat",repeat);
            intent.putExtra("seek",seek);
            // PlaybackService only becomes foreground for actual playback.
            if (Build.VERSION.SDK_INT >= 26 && PlaybackService.ACTION_PLAY.equals(cmd)) startForegroundService(intent);
            else startService(intent);
        });
    }
    private final class Bridge {
        @JavascriptInterface public void requestLibrary(){main.post(MainActivity.this::requireLibrary);}
        @JavascriptInterface public void connectSpotify(){spotify.connect();}
        @JavascriptInterface public void setAutoAddDownloads(boolean enabled){TrackTags.setAutoAdd(MainActivity.this,enabled);}
        @JavascriptInterface public void revealDownloadedTrack(String filename){TrackTags.reveal(MainActivity.this,filename);main.post(MainActivity.this::scanLibrary);}
        @JavascriptInterface public void inspectSpotify(String url){spotify.inspect(url);}
        @JavascriptInterface public void downloadSpotify(String url,String title){spotify.download(url,title);}
        @JavascriptInterface public void cancelSpotify(String id){spotify.cancel(id);}
        @JavascriptInterface public void inspectYouTube(String url){downloader.inspect(url);}
        @JavascriptInterface public void downloadYouTube(String url,String format){downloader.download(url,format);}
        @JavascriptInterface public void cancelYouTube(long id){downloader.cancel(id);}
        @JavascriptInterface public void importAudio(){main.post(MainActivity.this::chooseAudioFiles);}
        @JavascriptInterface public void play(String id, String queue, boolean shuffle, int repeat){command(PlaybackService.ACTION_PLAY,id,queue,shuffle,repeat,0);}
        @JavascriptInterface public void toggle(){command(PlaybackService.ACTION_TOGGLE,null,null,false,0,0);}
        @JavascriptInterface public void seek(long ms){command(PlaybackService.ACTION_SEEK,null,null,false,0,ms);}
        @JavascriptInterface public void setShuffle(boolean shuffle){command(PlaybackService.ACTION_SHUFFLE,null,null,shuffle,0,0);}
        @JavascriptInterface public void setRepeat(int mode){command(PlaybackService.ACTION_REPEAT,null,null,false,mode,0);}
        @JavascriptInterface public void setQueue(String queue){command(PlaybackService.ACTION_QUEUE,null,queue,false,0,0);}
    }
    @Override public void onResume(){super.onResume();PlaybackService.listener=this;}
    @Override public void onBackPressed() {if(web!=null)web.evaluateJavascript("window.appGoBack && window.appGoBack()",null);else super.onBackPressed();}
    @Override public void onDestroy() {
        destroyed = true;
        if (PlaybackService.listener == this) PlaybackService.listener = null;
        if (filePicker!=null)filePicker.onReceiveValue(null);
        scanner.shutdownNow();
        if(downloader!=null)downloader.close();
        if(spotify!=null)spotify.close();
        if (web!=null){web.destroy();web=null;}
        super.onDestroy();
    }
}
