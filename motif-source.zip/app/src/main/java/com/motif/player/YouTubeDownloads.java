package com.motif.player;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.playlist.PlaylistInfo;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * On-device audio extraction for publicly reachable YouTube URLs.
 * No metadata-only downloads, preview fabrication, external servers, or DRM bypass.
 * NewPipeExtractor is GPLv3; distributing this project with it requires GPL compliance.
 * Media is downloaded using Android's system DownloadManager (no conversion or upscaling).
 */
public final class YouTubeDownloads {
    public interface Events {
        void send(String payload);
        void libraryChanged();
    }
    private final Context context;
    private final Events events;
    private final DownloadManager dm;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<Long, Job> downloads = new HashMap<>();
    private long nextId = 1;
    private boolean polling;
    private volatile boolean closed;

    private static class Job {
        long id, transferId;
        String title, filename, artist, album;
        int previous = -1;
        int lastStatus = -1;
        volatile boolean cancelled;
        Job(long id, String title) { this.id=id; this.title=title; }
    }

    public YouTubeDownloads(Context ctx, Events listener) {
        context=ctx.getApplicationContext();
        events=listener;
        dm=(DownloadManager)ctx.getSystemService(Context.DOWNLOAD_SERVICE);
        NewPipe.init(new HttpExtractorDownloader());
    }

    private static boolean supported(String raw) {
        try {
            Uri u = Uri.parse(raw);
            if (!"https".equalsIgnoreCase(u.getScheme())) return false;
            String h = u.getHost();
            if (h==null) return false;
            h=h.toLowerCase(java.util.Locale.ROOT);
            return h.equals("youtu.be") || h.equals("youtube.com") || h.endsWith(".youtube.com");
        } catch (Exception ignored) { return false; }
    }

    public void inspect(final String url) {
        worker.execute(() -> {
            try {
                if (!supported(url)) throw new IllegalArgumentException("Only YouTube and YouTube Music URLs are supported for direct audio downloads.");
                JSONObject result=new JSONObject();
                result.put("type","inspect");
                JSONArray items=new JSONArray();
                Uri link=Uri.parse(url);
                String list=link.getQueryParameter("list");
                if (list!=null && !list.isEmpty() || link.getPath()!=null && link.getPath().startsWith("/playlist")) {
                    PlaylistInfo info=PlaylistInfo.getInfo(url);
                    result.put("title",info.getName());
                    addItems(items,info.getRelatedItems());
                    Page page=info.getNextPage();
                    while(page!=null && items.length()<250) {
                        ListExtractor.InfoItemsPage<StreamInfoItem> next=PlaylistInfo.getMoreItems(info.getService(),info.getUrl(),page);
                        addItems(items,next.getItems());
                        page=next.getNextPage();
                    }
                } else {
                    StreamInfo info=StreamInfo.getInfo(url);
                    result.put("title",info.getName());
                    JSONObject item=new JSONObject();
                    item.put("url",info.getUrl());
                    item.put("title",info.getName());
                    item.put("artist",info.getUploaderName());
                    item.put("seconds",info.getDuration());
                    items.put(item);
                }
                if(items.length()==0) throw new IOException("The source has no accessible audio tracks.");
                result.put("items",items);
                events.send(result.toString());
            } catch (Exception e) { error("Could not inspect source: "+safe(e)); }
        });
    }

    private void addItems(JSONArray into, List<StreamInfoItem> source) throws Exception {
        if(source==null) return;
        for(StreamInfoItem item:source){
            if(into.length()>=250) return;
            JSONObject t=new JSONObject();
            t.put("url",item.getUrl());
            t.put("title",item.getName());
            t.put("artist",item.getUploaderName());
            t.put("seconds",item.getDuration());
            into.put(t);
        }
    }

    public void download(final String url, final String preferredFormat) {
        if(!supported(url)){error("Invalid YouTube URL.");return;}
        final Job job;
        synchronized(downloads) { job=new Job(nextId++,"Resolving audio…"); downloads.put(job.id,job); }
        sendJob(job,"queued",0,"Finding available formats");
        worker.execute(() -> {
            try {
                StreamInfo info=StreamInfo.getInfo(url);
                String[] inferred=TrackTags.guess(info.getName(),info.getUploaderName());
                job.title=inferred[0];job.artist=inferred[1];job.album="";
                AudioStream selected=null;
                int bestBitrate=Integer.MIN_VALUE;
                for(AudioStream candidate:info.getAudioStreams()) {
                    if(candidate==null||!candidate.isUrl()||candidate.getDeliveryMethod()!=DeliveryMethod.PROGRESSIVE_HTTP)continue;
                    if(!candidate.getContent().startsWith("https://"))continue;
                    if(candidate.getFormat()==null)continue;
                    String ext=candidate.getFormat().getSuffix().toLowerCase(java.util.Locale.ROOT);
                    boolean formatIsM4a=ext.equals("m4a")||ext.equals("mp4");
                    boolean formatIsWebm=ext.equals("webm")||ext.equals("webma");
                    if(!formatIsM4a&&!formatIsWebm)continue;
                    if("m4a".equals(preferredFormat)&&!formatIsM4a)continue;
                    if("webm".equals(preferredFormat)&&!formatIsWebm)continue;
                    int rate=candidate.getAverageBitrate();
                    if(rate>bestBitrate) {bestBitrate=rate;selected=candidate;}
                }
                if(selected==null)throw new IOException("No directly downloadable audio stream in the selected format. Choose another format.");
                String ext=selected.getFormat().getSuffix();
                if(ext.equals("webma"))ext="webm";
                if(ext.equals("mp4"))ext="m4a";
                String file=sanitize(info.getName())+"-"+sanitize(info.getId())+"."+ext;
                job.filename=file;
                TrackTags.save(context,file,job.title,job.artist,job.album);
                DownloadManager.Request request=new DownloadManager.Request(Uri.parse(selected.getContent()));
                request.setTitle(info.getName());
                request.setDescription("Motif · "+info.getUploaderName());
                request.setMimeType(ext.equals("m4a")?"audio/mp4":"audio/webm");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setAllowedOverMetered(true);
                request.setAllowedOverRoaming(false);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC,"Motif/"+file);
                if(android.os.Build.VERSION.SDK_INT<29)request.allowScanningByMediaScanner();
                if(job.cancelled)return;
                job.transferId=dm.enqueue(request);
                sendJob(job,"queued",0,"Waiting for download manager");
                poll();
            } catch(Exception e) {
                sendJob(job,"failed",0,safe(e));
                synchronized(downloads){downloads.remove(job.id);}
            }
        });
    }

    public void cancel(long jobId) {
        Job job;
        synchronized(downloads){job=downloads.remove(jobId);}
        if(job!=null){job.cancelled=true;
            if(job.transferId>0)dm.remove(job.transferId);
            sendJob(job,"cancelled",0,"Cancelled");
        }
    }
    private void poll() {
        if(closed||polling)return;
        polling=true;
        main.postDelayed(new Runnable(){
            @Override public void run() {
                if(closed){polling=false;return;}
                boolean pending=false;
                List<Job> snap;
                synchronized(downloads){snap=new ArrayList<>(downloads.values());}
                for(Job j:snap) {
                    if(j.transferId<=0)continue;
                    DownloadManager.Query query=new DownloadManager.Query().setFilterById(j.transferId);
                    try(Cursor c=dm.query(query)) {
                        if(c==null||!c.moveToFirst()){sendJob(j,"failed",0,"Download was removed");remove(j);continue;}
                        int status=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        long transferred=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                        long total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                        int percent=total>0?(int)(transferred*100/total):0;
                        if(j.previous!=percent||j.lastStatus!=status){
                            j.previous=percent;j.lastStatus=status;
                            if(status==DownloadManager.STATUS_SUCCESSFUL){
                                TrackTags.downloadCompleted(context,j.filename);
                                sendJob(j,"complete",100,TrackTags.autoAdd(context)?"Saved to Music/Motif":"Saved — not added to library");
                                events.libraryChanged();remove(j);
                            }
                            else if(status==DownloadManager.STATUS_FAILED){sendJob(j,"failed",percent,"Android DownloadManager reported a failed transfer");remove(j);}
                            else sendJob(j,status==DownloadManager.STATUS_RUNNING?"downloading":"queued",percent,"");
                        }
                    } catch(Exception e){sendJob(j,"failed",0,safe(e));remove(j);}
                }
                synchronized(downloads){pending=!downloads.isEmpty();}
                if(pending)main.postDelayed(this,1100); else polling=false;
            }
        },500);
    }
    private void remove(Job j){synchronized(downloads){downloads.remove(j.id);}}
    private void sendJob(Job j,String status,int progress,String message){
        try{JSONObject x=new JSONObject();x.put("type","job");x.put("id",j.id);x.put("title",j.title);x.put("status",status);x.put("progress",progress);x.put("message",message);x.put("provider","youtube");
            if(j.filename!=null)x.put("filename",j.filename);
            events.send(x.toString());}catch(Exception ignored){}
    }
    private void error(String message){try{JSONObject x=new JSONObject();x.put("type","error");x.put("message",message);x.put("provider","youtube");
            if(j.filename!=null)x.put("filename",j.filename);
            events.send(x.toString());}catch(Exception ignored){}}
    private static String safe(Exception e){String t=e.getMessage();return t==null?e.getClass().getSimpleName():t;}
    private static String sanitize(String s){
        String out=s==null?"Track":s.replaceAll("[\\x00-\\x1F<>:\"/\\\\|?*]"," ").replaceAll("\\s+"," ").trim();
        return out.isEmpty()?"Track":out.substring(0,Math.min(out.length(),100));
    }
    public void close(){closed=true;worker.shutdownNow();}

    /** Network adapter for extractor requests only; media bytes use system DownloadManager. */
    private static final class HttpExtractorDownloader extends Downloader {
        @Override public Response execute(Request request) throws IOException {
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(request.url()).openConnection();
                c.setConnectTimeout(25000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent","Mozilla/5.0 (Android; Mobile; rv:140.0) Gecko/140.0 Firefox/140.0");
                c.setRequestMethod(request.httpMethod());
                for(Map.Entry<String,List<String>> entry:request.headers().entrySet()){
                    for(String v:entry.getValue()) c.addRequestProperty(entry.getKey(),v);
                }
                byte[] data=request.dataToSend();
                if(data!=null){c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(data);}}
                int status=c.getResponseCode();
                InputStream in=status>=400?c.getErrorStream():c.getInputStream();
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                if(in!=null)try(InputStream stream=in){byte[] buf=new byte[16384];int n;while((n=stream.read(buf))!=-1){bytes.write(buf,0,n);if(bytes.size()>20*1024*1024)throw new IOException("Extractor response too large");}}
                Map<String,List<String>> headers=new HashMap<>(c.getHeaderFields());headers.remove(null);
                return new Response(status,c.getResponseMessage(),headers,bytes.toString("UTF-8"),c.getURL().toString());
            }finally{if(c!=null)c.disconnect();}
        }
    }
}
