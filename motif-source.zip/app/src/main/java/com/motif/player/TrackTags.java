package com.motif.player;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.Locale;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Track titles and metadata persisted for downloads whose container has no ID3/MP4 tags. */
public final class TrackTags {
    private TrackTags() {}
    private static final String PREF = "motif-track-tags";
    private static final Pattern VIDEO_SUFFIX = Pattern.compile("(?i)\\s*[\\[(]\\s*(?:official\\s+)?(?:music\\s+video|visuali[sz]er|lyric\\s+video|audio|video|lyrics)\\s*[\\])]\\s*$");
    private static final Pattern DASH = Pattern.compile("\\s+[-–—]\\s+");

    public static String[] guess(String title, String uploader) {
        String cleaned = title == null ? "" : title.trim();
        for(int i=0;i<3;i++) cleaned = VIDEO_SUFFIX.matcher(cleaned).replaceFirst("").trim();
        String artist = uploader == null ? "" : uploader.trim();
        if(artist.endsWith(" - Topic")) artist=artist.substring(0,artist.length()-8).trim();
        Matcher m=DASH.matcher(cleaned);
        if (m.find() && m.start()>0 && m.end()<cleaned.length()) {
            String left=cleaned.substring(0,m.start()).trim();
            String right=cleaned.substring(m.end()).trim();
            // "Artist - Track" is the common upload convention. Prefer it
            // over a channel name, but never claim metadata is authoritative.
            if(!left.isEmpty()&&!right.isEmpty()) return new String[]{right,left};
        }
        if(artist.isEmpty())artist="Unknown artist";
        return new String[]{cleaned.isEmpty()?"Untitled":cleaned,artist};
    }
    public static void save(Context ctx, String fileName, String title, String artist, String album) {
        if(fileName==null||fileName.isEmpty())return;
        String key="tag:"+fileName;
        try {
            JSONObject json=new JSONObject().put("title",title).put("artist",artist).put("album",album);
            ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(key,json.toString()).apply();
        }catch(Exception ignored){}
    }
    public static JSONObject get(Context ctx,String fileName){
        try {String value=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("tag:"+fileName,null);
            return value==null?null:new JSONObject(value);}catch(Exception ignored){return null;}
    }
    /** Cache one Spotify cover in private app storage (never a token or public provider URL). */
    public static void cacheCover(Context ctx, String filename, String remoteUrl) {
        if (filename == null || filename.isEmpty() || remoteUrl == null) return;
        try {
            URL url = new URL(remoteUrl);
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (!"https".equals(url.getProtocol()) ||
                !(host.equals("i.scdn.co") || host.equals("mosaic.scdn.co") || host.equals("image-cdn-ak.spotifycdn.com"))) return;
            HttpURLConnection conn=(HttpURLConnection)url.openConnection();
            conn.setConnectTimeout(8000); conn.setReadTimeout(8000); conn.setInstanceFollowRedirects(false);
            try {
                if(conn.getResponseCode()!=200 || conn.getContentLengthLong()>2000000) return;
                Bitmap raw=BitmapFactory.decodeStream(conn.getInputStream());
                if(raw==null) return;
                int max=Math.max(raw.getWidth(),raw.getHeight());
                Bitmap image=max>400?Bitmap.createScaledBitmap(raw,Math.max(1,raw.getWidth()*400/max),Math.max(1,raw.getHeight()*400/max),true):raw;
                File dir=new File(ctx.getFilesDir(),"motif-artwork");
                if(!dir.isDirectory() && !dir.mkdirs()) return;
                String key=Integer.toHexString(filename.hashCode())+".jpg";
                try(FileOutputStream out=new FileOutputStream(new File(dir,key))){image.compress(Bitmap.CompressFormat.JPEG,82,out);}
                ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("cover:"+filename,key).apply();
            } finally {conn.disconnect();}
        } catch(Exception ignored){} // Offline artwork is best-effort; do not lose a valid audio download.
    }
    public static String localCover(Context ctx,String filename) {
        if(filename==null)return null;
        String key=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("cover:"+filename,null);
        if(key==null || !key.matches("[0-9a-fA-F]+\\.jpg"))return null;
        File art=new File(new File(ctx.getFilesDir(),"motif-artwork"),key);
        if(!art.isFile()||art.length()>500000)return null;
        try(FileInputStream in=new FileInputStream(art)){
            byte[] bytes=new byte[(int)art.length()];
            int offset=0;while(offset<bytes.length){int n=in.read(bytes,offset,bytes.length-offset);if(n<0)break;offset+=n;}
            if(offset==bytes.length)return "data:image/jpeg;base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP);
        }catch(Exception ignored){}
        return null;
    }
    public static boolean autoAdd(Context ctx){return ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("autoAdd",true);}
    public static void setAutoAdd(Context ctx,boolean value){ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("autoAdd",value).apply();}
    public static void downloadCompleted(Context ctx,String filename){
        ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("hide:"+filename,!autoAdd(ctx)).apply();
    }
    public static boolean hidden(Context ctx,String filename){return ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("hide:"+filename,false);}
    public static void reveal(Context ctx,String filename){ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove("hide:"+filename).apply();}
}
