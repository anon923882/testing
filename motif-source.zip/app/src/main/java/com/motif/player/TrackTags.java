package com.motif.player;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Track titles and metadata persisted for downloads whose container has no ID3/MP4 tags. */
public final class TrackTags {
    private TrackTags() {}
    private static final String PREF = "motif-track-tags";
    private static final Pattern VIDEO_SUFFIX = Pattern.compile("(?i)\\s*[\\[(]\\s*(?:official\\s+)?(?:music\\s+video|visuali[sz]er|lyric\\s+video|audio|video|lyrics)\\s*[\\])]\\s*$");
    private static final Pattern DASH = Pattern.compile("\\s+[-–—]\\s+");

    public static String[] guess(String title, String uploader) {
        String cleaned = title == null ? "" : title.trim();
        for(int i=0;i<3;i++) cleaned = VIDEO_SUFFIX.matcher(cleaned).replaceFirst("").trim();
        String artist = uploader == null ? "" : uploader.trim();
        if(artist.endsWith(" - Topic")) artist=artist.substring(0,artist.length()-8).trim();
        Matcher m=DASH.matcher(cleaned);
        if (m.find() && m.start()>0 && m.end()<cleaned.length()) {
            String left=cleaned.substring(0,m.start()).trim();
            String right=cleaned.substring(m.end()).trim();
            // "Artist - Track" is the common upload convention. Prefer it
            // over a channel name, but never claim metadata is authoritative.
            if(!left.isEmpty()&&!right.isEmpty()) return new String[]{right,left};
        }
        if(artist.isEmpty())artist="Unknown artist";
        return new String[]{cleaned.isEmpty()?"Untitled":cleaned,artist};
    }
    public static void save(Context ctx, String fileName, String title, String artist, String album) {
        if(fileName==null||fileName.isEmpty())return;
        String key="tag:"+fileName;
        try {
            JSONObject json=new JSONObject().put("title",title).put("artist",artist).put("album",album);
            ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(key,json.toString()).apply();
        }catch(Exception ignored){}
    }
    public static JSONObject get(Context ctx,String fileName){
        try {String value=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("tag:"+fileName,null);
            return value==null?null:new JSONObject(value);}catch(Exception ignored){return null;}
    }
    public static boolean autoAdd(Context ctx){return ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("autoAdd",true);}
    public static void setAutoAdd(Context ctx,boolean value){ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("autoAdd",value).apply();}
    public static void downloadCompleted(Context ctx,String filename){
        ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("hide:"+filename,!autoAdd(ctx)).apply();
    }
    public static boolean hidden(Context ctx,String filename){return ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("hide:"+filename,false);}
    public static void reveal(Context ctx,String filename){ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove("hide:"+filename).apply();}
}
