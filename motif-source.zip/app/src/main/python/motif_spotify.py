"""Experimental on-device Spotify Premium engine for Motif.

Uses the open-source librespot-python Spotify client. Original Spotify audio
is requested at VERY_HIGH quality and stored as Ogg Vorbis; no transcoding or
lossless quality claims. This is a feasibility candidate, NOT an Android-tested
or verified downloader. The package dependencies and OAuth callback need a
real-device test before this can be enabled in a release.

The module uses the app-private directory for credentials and temporary tracks.
Spotify usernames/passwords are never accepted through Motif's WebView.
"""

import json
import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

_SESSION = None
_CANCELLED = set()
_LOCK = threading.RLock()
_ID_RE = re.compile(r"^[A-Za-z0-9]{22}$")
_SUPPORTED = {"track", "album", "playlist"}


class SpotifyError(Exception):
    pass


def parse_url(raw):
    """Validate supported Spotify share links; never pass arbitrary URLs to a network client."""
    try:
        p = urlparse(raw.strip())
    except Exception as e:
        raise SpotifyError("Invalid Spotify URL") from e
    host = (p.hostname or "").lower()
    if p.scheme != "https" or host not in ("open.spotify.com", "play.spotify.com"):
        raise SpotifyError("Enter an open.spotify.com track, album or playlist link")
    chunks = [x for x in p.path.split("/") if x]
    if chunks and chunks[0].startswith("intl-"):
        chunks.pop(0)
    if len(chunks) < 2 or chunks[0] not in _SUPPORTED or not _ID_RE.fullmatch(chunks[1]):
        raise SpotifyError("Supported Spotify URLs: track, album and playlist")
    return chunks[0], chunks[1]


def _android():
    from java import jclass
    return jclass("com.motif.player.SpotifyDownloads")


def _notify(job_id, status, progress, message=""):
    try:
        _android().report(str(job_id), str(status), int(progress), str(message))
    except Exception:
        pass


def _session(private_dir):
    global _SESSION
    with _LOCK:
        if _SESSION is not None:
            return _SESSION
        from librespot.core import Session
        directory = Path(private_dir)
        directory.mkdir(parents=True, exist_ok=True)
        credentials = str(directory / "spotify_credentials.json")
        session = None
        if os.path.isfile(credentials):
            try:
                session = Session.Builder().stored_file(credentials).create()
            except Exception:
                # A revoked token must not leave the app stuck forever.
                session = None
        if session is None:
            def show_url(url):
                _android().openAuthUrl(str(url))
            # OAuth may require an embedded localhost callback; validate on phone.
            builder = Session.Builder()
            # Store credentials in app private storage if supported by this
            # librespot-python version; user should not enter a password in JS.
            try:
                conf = Session.Configuration.Builder().set_stored_credential_file(credentials).build()
                builder = Session.Builder(conf=conf)
            except (AttributeError, TypeError):
                pass
            session = builder.oauth(show_url).create()
        kind = str(session.get_user_attribute("type") or "")
        if kind.lower() != "premium":
            raise SpotifyError("Spotify Premium is required for this source")
        _SESSION = session
        return session


def dependency_check():
    """Import every runtime dependency except unused PyOgg, before starting sign-in.

    Direct Ogg stream copying needs no Ogg decoder. Import-checking PyOgg caused
    an Android root-directory PermissionError despite never using its decoder.
    This checks imports only; it does not claim a valid Spotify session.
    """
    import importlib
    required = ("urllib3", "idna", "certifi", "charset_normalizer",
                "requests", "Cryptodome", "google.protobuf", "defusedxml",
                "websocket", "ifaddr", "async_timeout", "zeroconf",
                "librespot.core", "librespot.metadata", "librespot.audio.decoders")
    failed = []
    for name in required:
        try:
            importlib.import_module(name)
        except (ImportError, OSError) as exc:
            failed.append(f"{name} ({type(exc).__name__}: {str(exc)[:100]})")
    if failed:
        raise SpotifyError("Spotify engine incomplete: " + "; ".join(failed))
    return True


def connect(private_dir):
    dependency_check()
    s = _session(private_dir)
    user = str(s.username() or "")
    return json.dumps({"type": "spotify-connected", "username": user[:2] + "••••" if user else "Premium connected", "quality": "320 kbps Ogg Vorbis"})


def _request_json(session, path, params=None):
    """Fetch a Spotify catalog response with explicit status and timeout handling.

    These endpoints only expose metadata, and may be restricted by the user's
    permissions and Spotify's development-mode limits.
    """
    import requests
    token = session.tokens().get("user-read-email")
    if not token:
        raise SpotifyError("No Spotify catalog token was granted")
    try:
        response = requests.get(
            "https://api.spotify.com/v1/" + path,
            headers={"Authorization": "Bearer " + token},
            params=params or {}, timeout=(10, 25))
    except requests.RequestException as exc:
        raise SpotifyError("Spotify could not be reached. Check your connection") from exc
    if response.status_code == 401:
        raise SpotifyError("Spotify session expired. Reconnect your account")
    if response.status_code == 403:
        raise SpotifyError("Spotify denied access. Playlist items may require ownership or collaboration")
    if response.status_code == 404:
        raise SpotifyError("That track, album or playlist is unavailable")
    if response.status_code == 429:
        raise SpotifyError("Spotify temporarily rate-limited requests; try again later")
    if response.status_code >= 400:
        raise SpotifyError("Spotify catalog returned HTTP " + str(response.status_code))
    try:
        return response.json()
    except ValueError as exc:
        raise SpotifyError("Spotify returned malformed catalog data") from exc


def _track_data(track):
    """Safely normalize one Spotify track, not a podcast, episode or local entry."""
    track_id = str(track.get("id") or "")
    if not _ID_RE.fullmatch(track_id) or track.get("type", "track") != "track":
        raise SpotifyError("Unsupported playlist item")
    artists = ", ".join(str(a.get("name") or "") for a in (track.get("artists") or []) if isinstance(a, dict))
    album = track.get("album") or {}
    images = album.get("images") or []
    return {"url": "https://open.spotify.com/track/" + track_id,
            "title": track.get("name") or "Untitled",
            "artist": artists or "Unknown artist",
            "album": album.get("name") or "",
            "cover": images[0].get("url", "") if images else "",
            "seconds": max(0, int((track.get("duration_ms") or 0) / 1000))}


def inspect(private_dir, link):
    """Inspect Spotify catalog metadata using the current playlist-items API.

    This is independent of whether independent audio extraction is supported.
    """
    kind, item_id = parse_url(link)
    session = _session(private_dir)
    items = []
    if kind == "track":
        item = _request_json(session, "tracks/" + item_id)
        items = [_track_data(item)]
        title = item.get("name", "Track")
    elif kind == "album":
        album = _request_json(session, "albums/" + item_id)
        title = album.get("name", "Album")
        page = album.get("tracks") or {}
        offset = 0
        while True:
            page_items = page.get("items") or []
            for track in page_items:
                if not isinstance(track, dict):
                    continue
                track = dict(track, album=album)
                try: items.append(_track_data(track))
                except SpotifyError: continue
                if len(items) >= 300: break
            offset += len(page_items)
            if not page.get("next") or len(items) >= 300 or not page_items:
                break
            page = _request_json(session, "albums/" + item_id + "/tracks", {"limit": 50, "offset": offset})
    else:
        playlist = _request_json(session, "playlists/" + item_id)
        title = playlist.get("name", "Playlist")
        # The 2026 API names this collection 'items', not 'tracks'. Its
        # embedded first page can be metadata-only; fetch the items endpoint.
        page = _request_json(session, "playlists/" + item_id + "/items", {"limit": 50, "offset": 0})
        offset = 0
        while True:
            entries = page.get("items") or []
            for entry in entries:
                if not isinstance(entry, dict): continue
                track = entry.get("item") or entry.get("track")
                if not isinstance(track, dict): continue
                try: items.append(_track_data(track))
                except SpotifyError: continue
                if len(items) >= 300: break
            offset += len(entries)
            if not page.get("next") or len(items) >= 300 or not entries:
                break
            page = _request_json(session, "playlists/" + item_id + "/items", {"limit": 50, "offset": offset})
    if not items:
        raise SpotifyError("No accessible tracks returned by Spotify")
    return json.dumps({"type": "inspect", "title": title, "provider": "spotify", "items": items})


def cancel(job_id):
    _CANCELLED.add(str(job_id))


def download(private_dir, link, job_id):
    """Stream original Very High Spotify Ogg to an app-private temporary file.

    Java is responsible for committing into MediaStore after success.
    Cancellation leaves no partial track in the Android media library.
    """
    kind, track_id = parse_url(link)
    if kind != "track":
        raise SpotifyError("Select individual tracks from an inspected release")
    session = _session(private_dir)
    from librespot.audio.decoders import AudioQuality, VorbisOnlyAudioQuality
    from librespot.metadata import TrackId
    job_id = str(job_id)
    temp_dir = Path(private_dir) / "temp_audio"
    temp_dir.mkdir(exist_ok=True, parents=True)
    temp_file = temp_dir / (track_id + "_" + job_id + ".ogg")
    _notify(job_id, "downloading", 0, "Requesting 320 kbps stream")
    try:
        track = _request_json(session, "tracks/" + track_id)
        metadata = _track_data(track)
        audio_id = TrackId.from_uri("spotify:track:" + track_id)
        stream = session.content_feeder().load(audio_id,
                   VorbisOnlyAudioQuality(AudioQuality.VERY_HIGH), False, None)
        total = max(1, int(stream.input_stream.size or 1))
        source = stream.input_stream.stream()
        copied, last_percent = 0, -1
        try:
            with temp_file.open("wb") as output:
                while True:
                    if job_id in _CANCELLED:
                        raise SpotifyError("Cancelled")
                    chunk = source.read(64 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    copied += len(chunk)
                    percent = min(99, int(copied * 100 / total))
                    if percent >= last_percent + 5:
                        _notify(job_id, "downloading", percent)
                        last_percent = percent
        finally:
            source.close()
        if not copied or temp_file.stat().st_size == 0:
            raise SpotifyError("Spotify returned no audio data")
        with temp_file.open("rb") as check:
            if check.read(4) != b"OggS":
                raise SpotifyError("Received bytes are not a playable Ogg stream")
        # Keep the source codec exactly as received; never fake FLAC quality.
        return json.dumps({"path": str(temp_file), "metadata": metadata,
                           "bytes": temp_file.stat().st_size, "codec": "ogg"})
    except Exception:
        temp_file.unlink(missing_ok=True)
        raise
    finally:
        _CANCELLED.discard(job_id)
