"""Experimental on-device Spotify Premium engine for Motif.

Uses the open-source librespot-python Spotify client. Original Spotify audio
is requested at VERY_HIGH quality and stored as Ogg Vorbis; no transcoding or
lossless quality claims. This is a feasibility candidate, NOT an Android-tested
or verified downloader. The package dependencies and OAuth callback need a
real-device test before this can be enabled in a release.

The module uses the app-private directory for credentials and temporary tracks.
Spotify usernames/passwords are never accepted through Motif's WebView.
"""

import json
import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

_SESSION = None
_CANCELLED = set()
_LOCK = threading.RLock()
_ID_RE = re.compile(r"^[A-Za-z0-9]{22}$")
_SUPPORTED = {"track", "album", "playlist"}


class SpotifyError(Exception):
    def __init__(self, message, code="spotify_error", retry_after=0):
        super().__init__(message)
        self.code = code
        self.retry_after = max(0, int(retry_after or 0))


_RATE_LIMIT_LOCK = threading.RLock()
_RATE_LIMIT_UNTIL = 0.0


def _rate_limit_wait():
    """Return remaining delay without hitting Spotify again."""
    with _RATE_LIMIT_LOCK:
        return max(0, int(_RATE_LIMIT_UNTIL - time.monotonic() + 0.999))


def _remember_rate_limit(seconds):
    global _RATE_LIMIT_UNTIL
    with _RATE_LIMIT_LOCK:
        _RATE_LIMIT_UNTIL = max(_RATE_LIMIT_UNTIL, time.monotonic() + seconds)


def _safe_response(operation, private_dir, text):
    """Return structured errors to the app instead of losing 429 details in Java."""
    try:
        result = inspect(private_dir, text) if operation == "inspect" else search(private_dir, text)
        return result
    except SpotifyError as exc:
        return json.dumps({"type": "error", "provider": "spotify", "code": exc.code,
                           "retryAfter": exc.retry_after, "message": str(exc)})


def inspect_safe(private_dir, url):
    return _safe_response("inspect", private_dir, url)


def search_safe(private_dir, query):
    return _safe_response("search", private_dir, query)


def parse_url(raw):
    """Validate supported Spotify share links; never pass arbitrary URLs to a network client."""
    try:
        p = urlparse(raw.strip())
    except Exception as e:
        raise SpotifyError("Invalid Spotify URL") from e
    host = (p.hostname or "").lower()
    if p.scheme != "https" or host not in ("open.spotify.com", "play.spotify.com"):
        raise SpotifyError("Enter an open.spotify.com track, album or playlist link")
    chunks = [x for x in p.path.split("/") if x]
    if chunks and chunks[0].startswith("intl-"):
        chunks.pop(0)
    if len(chunks) < 2 or chunks[0] not in _SUPPORTED or not _ID_RE.fullmatch(chunks[1]):
        raise SpotifyError("Supported Spotify URLs: track, album and playlist")
    return chunks[0], chunks[1]


def _android():
    from java import jclass
    return jclass("com.motif.player.SpotifyDownloads")


def _notify(job_id, status, progress, message=""):
    try:
        _android().report(str(job_id), str(status), int(progress), str(message))
    except Exception:
        pass


def _session(private_dir, interactive=True):
    """Build the client with app-private durable credentials, never with cwd defaults.

    Android updates retain filesDir. The UI must call resume() to read those
    credentials; relaunching OAuth on every WebView creation is unnecessary.
    """
    global _SESSION
    with _LOCK:
        if _SESSION is not None:
            return _SESSION
        from librespot.core import Session
        directory = Path(private_dir)
        directory.mkdir(parents=True, exist_ok=True)
        credentials = directory / "spotify_credentials.json"
        cache = directory / "cache"
        cache.mkdir(exist_ok=True)
        conf = (Session.Configuration.Builder()
                .set_stored_credential_file(str(credentials))
                .set_cache_dir(str(cache))
                .set_store_credentials(True)
                .build())
        session = None
        if credentials.is_file():
            try:
                session = Session.Builder(conf=conf).stored_file(str(credentials)).create()
            except Exception:
                if not interactive:
                    raise SpotifyError("Saved Spotify session needs reconnecting", "auth_expired")
        if session is None:
            if not interactive:
                raise SpotifyError("No stored Spotify account", "session_missing")
            def show_url(url):
                _android().openAuthUrl(str(url))
            success_page = ("<!doctype html><html><head><meta name='viewport' "
                "content='width=device-width, initial-scale=1'><style>"
                "body{margin:0;background:#0d1110;color:#f2f5ef;font-family:system-ui;"
                "min-height:100dvh;display:grid;place-items:center;text-align:center}"
                "main{padding:28px}h1{font-size:28px}p{color:#acbaa9;line-height:1.6}"
                "</style></head><body><main><h1>Authorization received</h1>"
                "<p>Return to Motif to finish connecting Spotify.</p>"
                "</main></body></html>")
            session = Session.Builder(conf=conf).oauth(show_url,success_page).create()
        if str(session.get_user_attribute("type") or "").lower() != "premium":
            raise SpotifyError("Spotify Premium is required for this source")
        _SESSION = session
        return session


def resume(private_dir):
    """Try cached credentials without opening a sign-in flow or contacting a Web API."""
    if not (Path(private_dir)/"spotify_credentials.json").is_file():
        return json.dumps({"type":"spotify-session-missing"})
    try:
        s = _session(private_dir, interactive=False)
        user = str(s.username() or "")
        return json.dumps({"type":"spotify-connected","username":user[:2]+"••••" if user else "Premium connected","quality":"320 kbps Ogg Vorbis","restored":True})
    except (SpotifyError, OSError, ValueError):
        return json.dumps({"type":"spotify-session-missing"})

def dependency_check():
    """Import every runtime dependency except unused PyOgg, before starting sign-in.

    Direct Ogg stream copying needs no Ogg decoder. Import-checking PyOgg caused
    an Android root-directory PermissionError despite never using its decoder.
    This checks imports only; it does not claim a valid Spotify session.
    """
    import importlib
    required = ("urllib3", "idna", "certifi", "charset_normalizer",
                "requests", "Cryptodome", "google.protobuf", "defusedxml",
                "websocket", "ifaddr", "async_timeout", "zeroconf",
                "librespot.core", "librespot.metadata", "librespot.audio.decoders")
    failed = []
    for name in required:
        try:
            importlib.import_module(name)
        except (ImportError, OSError) as exc:
            failed.append(f"{name} ({type(exc).__name__}: {str(exc)[:100]})")
    if failed:
        raise SpotifyError("Spotify engine incomplete: " + "; ".join(failed))
    return True


def connect(private_dir):
    dependency_check()
    s = _session(private_dir)
    user = str(s.username() or "")
    return json.dumps({"type": "spotify-connected", "username": user[:2] + "••••" if user else "Premium connected", "quality": "320 kbps Ogg Vorbis"})


def _request_json(session, path, params=None):
    """One user-initiated Spotify catalog request; honor rate/quota responses.

    Do not retry automatically, loop while limited or attempt to evade quotas.
    """
    import requests
    remaining = _rate_limit_wait()
    if remaining:
        raise SpotifyError(f"Spotify requested a cooldown. Try again in {remaining}s.",
                           "rate_limited", remaining)
    token = session.tokens().get("user-read-email")
    if not token:
        raise SpotifyError("No Spotify catalog token was granted", "auth_required")
    try:
        response = requests.get(
            "https://api.spotify.com/v1/" + path,
            headers={"Authorization": "Bearer " + token},
            params=params or {}, timeout=(10, 25))
    except requests.RequestException as exc:
        raise SpotifyError("Spotify could not be reached. Check your connection", "network_error") from exc
    if response.status_code == 401:
        raise SpotifyError("Spotify catalog session expired; reconnect your account", "auth_expired")
    if response.status_code == 403:
        raise SpotifyError("Spotify denied catalog access. This account or app may lack permissions.", "access_denied")
    if response.status_code == 404:
        raise SpotifyError("That track, album or playlist is unavailable", "not_found")
    if response.status_code == 429:
        try:
            error_body = response.json().get("error", {})
        except (ValueError, AttributeError, TypeError):
            error_body = {}
        if isinstance(error_body, dict) and error_body.get("reason") == "QUOTA_EXCEEDED":
            raise SpotifyError("Spotify's developer quota is exhausted. Try again after the quota resets; repeated requests will not help.",
                               "quota_exceeded")
        try:
            seconds = min(3600, max(1, int(response.headers.get("Retry-After", "30"))))
        except (AttributeError, ValueError, TypeError):
            seconds = 30
        _remember_rate_limit(seconds)
        raise SpotifyError(f"Spotify Web API's shared application token is rate-limited. Retry in {seconds}s, or use a direct track/album link.",
                           "rate_limited", seconds)
    if response.status_code >= 400:
        raise SpotifyError("Spotify catalog returned HTTP " + str(response.status_code), "catalog_error")
    try:
        return response.json()
    except ValueError as exc:
        raise SpotifyError("Spotify returned malformed catalog data", "malformed_data") from exc


def _track_data(track):
    """Safely normalize one Spotify track, not a podcast, episode or local entry."""
    track_id = str(track.get("id") or "")
    if not _ID_RE.fullmatch(track_id) or track.get("type", "track") != "track":
        raise SpotifyError("Unsupported playlist item")
    artists = ", ".join(str(a.get("name") or "") for a in (track.get("artists") or []) if isinstance(a, dict))
    album = track.get("album") or {}
    images = album.get("images") or []
    return {"url": "https://open.spotify.com/track/" + track_id,
            "title": track.get("name") or "Untitled",
            "artist": artists or "Unknown artist",
            "album": album.get("name") or "",
            "cover": images[0].get("url", "") if images else "",
            "seconds": max(0, int((track.get("duration_ms") or 0) / 1000))}


def _session_track_data(session, track_id):
    """Track details from the authenticated playback session, not Web API v1.

    The Web API token issued to the common librespot app identity is shared
    across unrelated users, and has been returning 429 on the first request.
    Reuse the client's own track-metadata facility without issuing an
    unrelated Web API lookup. One lookup per user action; no retry storm.
    """
    from librespot.metadata import TrackId
    try:
        track = session.api().get_metadata_4_track(TrackId.from_base62(track_id))
    except Exception as exc:
        code = getattr(exc, "code", None)
        if code == 429 or "429" in str(exc):
            raise SpotifyError("Spotify is limiting metadata access for this client. Try again later.", "metadata_rate_limited") from exc
        raise SpotifyError("Spotify track details are unavailable through the playback session.", "metadata_unavailable") from exc
    album = getattr(track, "album", None)
    return _normalize_session_track(track_id, track, album)


def _normalize_session_track(track_id, track, album=None, fallback_artists=None):
    """Normalize protobuf track metadata into Motif's existing track model."""
    artists = [str(a.name) for a in (getattr(track, "artist", None) or []) if getattr(a, "name", "")]
    if not artists:
        artists = fallback_artists or []
    cover = ""
    if album is not None:
        covers = list(getattr(album, "cover", None) or [])
        if not covers:
            covers = list(getattr(getattr(album, "cover_group", None), "image", None) or [])
        images = [img for img in covers if getattr(img, "file_id", None)]
        if images:
            best = max(images, key=lambda img: (getattr(img, "width", 0) or 0, getattr(img, "height", 0) or 0))
            cover = "https://i.scdn.co/image/" + bytes(best.file_id).hex()
    return {"url": "https://open.spotify.com/track/" + track_id,
            "title": str(getattr(track, "name", "") or "Untitled"),
            "artist": ", ".join(artists) or "Unknown artist",
            "album": str(getattr(album, "name", "") or ""),
            "cover": cover,
            "seconds": max(0, int((getattr(track, "duration", 0) or 0) / 1000))}


def _session_album_data(session, album_id):
    """Album contents via playback-session metadata; no /v1/albums request."""
    from librespot.metadata import AlbumId, TrackId
    try:
        album = session.api().get_metadata_4_album(AlbumId.from_base62(album_id))
    except Exception as exc:
        code = getattr(exc, "code", None)
        if code == 429 or "429" in str(exc):
            raise SpotifyError("Spotify is limiting album metadata for this client.", "metadata_rate_limited") from exc
        raise SpotifyError("Spotify album details are unavailable through the playback session.", "metadata_unavailable") from exc
    items = []
    album_artists = [str(a.name) for a in (getattr(album, "artist", None) or []) if getattr(a, "name", "")]
    for disc in getattr(album, "disc", ()):
        for track in getattr(disc, "track", ()):
            gid = getattr(track, "gid", b"")
            if not gid or len(gid) != 16: continue
            track_id = TrackId.from_hex(bytes(gid).hex()).to_spotify_uri().rsplit(":", 1)[-1]
            items.append(_normalize_session_track(track_id, track, album, album_artists))
            if len(items) >= 300:
                return items, str(getattr(album, "name", "") or "Album")
    return items, str(getattr(album, "name", "") or "Album")


def inspect(private_dir, link):
    """Inspect Spotify catalog metadata using the current playlist-items API.

    This is independent of whether independent audio extraction is supported.
    """
    kind, item_id = parse_url(link)
    session = _session(private_dir)
    items = []
    if kind == "track":
        # One direct track URL never needs a separate Web API token.
        track = _session_track_data(session, item_id)
        items = [track]
        title = track["title"]
    elif kind == "album":
        items, title = _session_album_data(session, item_id)
    else:
        playlist = _request_json(session, "playlists/" + item_id)
        title = playlist.get("name", "Playlist")
        # The 2026 API names this collection 'items', not 'tracks'. Its
        # embedded first page can be metadata-only; fetch the items endpoint.
        page = _request_json(session, "playlists/" + item_id + "/items", {"limit": 50, "offset": 0})
        offset = 0
        while True:
            entries = page.get("items") or []
            for entry in entries:
                if not isinstance(entry, dict): continue
                track = entry.get("item") or entry.get("track")
                if not isinstance(track, dict): continue
                try: items.append(_track_data(track))
                except SpotifyError: continue
                if len(items) >= 300: break
            offset += len(entries)
            if not page.get("next") or len(items) >= 300 or not entries:
                break
            page = _request_json(session, "playlists/" + item_id + "/items", {"limit": 50, "offset": offset})
    if not items:
        raise SpotifyError("No accessible tracks returned by Spotify")
    return json.dumps({"type": "inspect", "title": title, "provider": "spotify", "items": items})


def search(private_dir, query):
    """Spotify catalog search requires separate, quota-limited Web API access.

    Users can inspect track and album URLs without this optional public API.
    Search only triggers on a deliberate tap, with no background polling.
    """
    query = str(query or "").strip()
    if len(query) < 2 or len(query) > 120:
        raise SpotifyError("Enter at least two characters to search Spotify", "invalid_query")
    response = _request_json(_session(private_dir), "search", {"q": query, "type": "track", "limit": 10})
    tracks = ((response.get("tracks") or {}).get("items") or [])
    matches = []
    for track in tracks:
        if not isinstance(track, dict):
            continue
        try:
            matches.append(_track_data(track))
        except SpotifyError:
            continue
    if not matches:
        raise SpotifyError("No matching Spotify tracks found", "no_results")
    return json.dumps({"type":"inspect", "provider":"spotify", "title":"Search results", "items":matches})

def cancel(job_id):
    _CANCELLED.add(str(job_id))


def _copy_stream(source, destination, job_id, total, notify=_notify):
    """Copy only the remaining bytes in a finite librespot stream.

    librespot-python's AbsChunkedInputStream.read(n) doesn't return EOF
    reliably for sized reads: at the end it can request an out-of-bounds
    chunk. Avoid speculative reads after source.size() - source.pos().
    Never accept a truncated/empty stream as a successful download.
    """
    remaining = int(total)
    if remaining <= 0:
        raise SpotifyError("Spotify returned an empty stream", "empty_stream")
    copied = 0
    last_percent = -1
    try:
        output_handle = open(destination, 'wb')
    except OSError as exc:
        raise SpotifyError('Android cannot create the audio file: ' + str(exc), 'local_storage_error') from exc
    with output_handle as output:
        while remaining:
            if str(job_id) in _CANCELLED:
                raise SpotifyError("Cancelled", "cancelled")
            try:
                chunk = source.read(min(64 * 1024, remaining))
            except OSError as exc:
                if exc.errno == 9:
                    raise SpotifyError("Spotify audio socket closed during transfer", "stale_connection") from exc
                raise
            if not chunk:
                raise SpotifyError("Spotify audio ended before the expected byte count", "truncated_stream")
            if len(chunk) > remaining:
                raise SpotifyError("Spotify returned more audio than expected", "invalid_stream")
            try:
                output.write(chunk)
            except OSError as exc:
                raise SpotifyError("Android could not write the audio file: " + str(exc), "local_storage_error") from exc
            remaining -= len(chunk)
            copied += len(chunk)
            percent = min(99, int(100 * copied / total))
            if percent >= last_percent + 5:
                notify(job_id, "downloading", percent)
                last_percent = percent
    return copied


def _reset_closed_session():
    """Discard a stale in-process session before restoring saved credentials.

    Never delete credentials and never trigger OAuth during transfer recovery.
    """
    global _SESSION
    with _LOCK:
        stale, _SESSION = _SESSION, None
    if stale is not None:
        try:
            stale.close()
        except (OSError, RuntimeError, AttributeError):
            pass


def _copy_from_spotify_session(private_dir, track_id, job_id, temp_file):
    from librespot.audio.decoders import AudioQuality, VorbisOnlyAudioQuality
    from librespot.metadata import TrackId

    session = _session(private_dir, interactive=False)
    # This request is deliberately separate from the stream to identify errors.
    _notify(job_id, "downloading", 0, "Resolving Spotify track")
    metadata = _session_track_data(session, track_id)
    audio_id = TrackId.from_uri("spotify:track:" + track_id)
    _notify(job_id, "downloading", 0, "Opening audio stream")
    try:
        stream = session.content_feeder().load(
            audio_id, VorbisOnlyAudioQuality(AudioQuality.VERY_HIGH), False, None)
    except OSError as exc:
        if exc.errno == 9:
            raise SpotifyError("Spotify playback connection closed while opening the stream", "stale_connection") from exc
        raise
    source = stream.input_stream.stream()
    try:
        total = int(source.size()) - int(source.pos())
        _notify(job_id, "downloading", 0, "Transferring audio")
        try:
            _copy_stream(source, temp_file, job_id, total)
        except OSError as exc:
            if exc.errno == 9:
                raise SpotifyError("Spotify playback connection closed during transfer", "stale_connection") from exc
            raise
    finally:
        try:
            source.close()
        except (OSError, ValueError):
            # A third-party stream may close its socket twice. Do not replace
            # a successful transfer or hide its original error with cleanup.
            pass
    with open(temp_file, 'rb') as check:
        if check.read(4) != b'OggS':
            raise SpotifyError("Audio has no valid Ogg header", "invalid_audio")
    return metadata


def download(private_dir, link, job_id):
    """Transfer into an app-private temp file; Java commits successful tracks.

    Restore stored credentials silently after a stale socket error and retry
    only once. Do not retry invalid keys, auth failures, rate limits, or
    truncation. Both attempts share a single job and partial bytes are removed.
    """
    kind, track_id = parse_url(link)
    if kind != "track":
        raise SpotifyError("Select individual tracks from an inspected release")
    job_id = str(job_id)
    temp_dir = Path(private_dir) / "temp_audio"
    temp_dir.mkdir(exist_ok=True, parents=True)
    temp_file = temp_dir / (track_id + "_" + job_id + ".ogg")
    try:
        for attempt in range(2):
            try:
                if attempt:
                    _notify(job_id, "downloading", 0, "Restoring Spotify connection (one retry)")
                    _reset_closed_session()
                metadata = _copy_from_spotify_session(private_dir, track_id, job_id, temp_file)
                return json.dumps({"path": str(temp_file), "metadata": metadata,
                                   "bytes": temp_file.stat().st_size, "codec": "ogg"})
            except SpotifyError as exc:
                temp_file.unlink(missing_ok=True)
                if exc.code == "stale_connection" and attempt == 0 and job_id not in _CANCELLED:
                    continue
                if exc.code == "stale_connection":
                    raise SpotifyError("Spotify playback connection closed again after reconnecting. "
                                       "Retry later or restart Motif QA.", "connection_lost") from exc
                raise
            except OSError as exc:
                temp_file.unlink(missing_ok=True)
                if exc.errno == 9 and attempt == 0 and job_id not in _CANCELLED:
                    continue
                if exc.errno == 9:
                    raise SpotifyError("A bad file descriptor persisted after session recovery "
                                       "(network or local file); exact stage unavailable", "bad_descriptor") from exc
                raise
    finally:
        _CANCELLED.discard(job_id)
        # No partial audio should remain on any error; complete file is
        # intentionally retained for Android's MediaStore commit.
