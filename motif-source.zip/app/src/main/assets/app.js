/* Motif — offline music player. Library comes from Android MediaStore or user imports. */
const $=s=>document.querySelector(s);document.body.insertAdjacentHTML('beforeend','<input id="music-import-input" type="file" accept="audio/*,.mp3,.m4a,.flac,.ogg,.wav,.opus" multiple hidden>');
document.body.insertAdjacentHTML('beforeend','<input id="playlist-import-file" type="file" accept=".csv,.m3u,.m3u8,.json,text/csv,text/plain,application/json" hidden>');
const icons={refresh:'<path d="M21 12a9 9 0 1 1-2.5-6.2"/><path d="M21 3v6h-6"/>',home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',library:'<rect x="3" y="5.5" width="4.2" height="14.5" rx="1"/><rect x="9.1" y="3.5" width="4.4" height="16.5" rx="1"/><path d="m16 5.5 3.2-.8 3.2 13.6-3.2.8z"/>',homeSolid:'<path d="M3 10 12 3l9 7v10a1 1 0 0 1-1 1h-5.7v-7.4H9.7V21H4a1 1 0 0 1-1-1Z" fill="currentColor" stroke="none"/>',librarySolid:'<rect x="3" y="5.5" width="4.2" height="14.5" rx="1" fill="currentColor" stroke="none"/><rect x="9.1" y="3.5" width="4.4" height="16.5" rx="1" fill="currentColor" stroke="none"/><path d="m16 5.5 3.2-.8 3.2 13.6-3.2.8z" fill="currentColor" stroke="none"/>',plus:'<path d="M12 5v14M5 12h14"/>',arrowLeft:'<path d="m15 18-6-6 6-6"/>',arrowRight:'<path d="m9 18 6-6-6-6"/>',more:'<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',moreV:'<circle cx="12" cy="5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="19" r="1.4"/>',play:'<path d="m8 5 12 7-12 7z" fill="currentColor" stroke="none"/>',pause:'<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/>',next:'<path d="m5 5 11 7-11 7z" fill="currentColor" stroke="none"/><path d="M19 5v14" stroke-width="2.5"/>',prev:'<path d="m19 5-11 7 11 7z" fill="currentColor" stroke="none"/><path d="M5 5v14" stroke-width="2.5"/>',heart:'<path d="M20.5 5.7a5.2 5.2 0 0 0-7.35 0L12 6.86l-1.15-1.16a5.2 5.2 0 0 0-7.35 7.35L12 21l8.5-7.95a5.2 5.2 0 0 0 0-7.35Z"/>',heartFill:'<path d="M20.5 5.7a5.2 5.2 0 0 0-7.35 0L12 6.86l-1.15-1.16a5.2 5.2 0 0 0-7.35 7.35L12 21l8.5-7.95a5.2 5.2 0 0 0 0-7.35Z" fill="currentColor" stroke="none"/>',check:'<path d="m5 12 4 4L19 6"/>',shuffle:'<path d="M17 3h4v4M3 17l6-6M21 3l-7 7M14 14l7 7M17 21h4v-4M3 7l4 4"/>',repeat:'<path d="m17 2 4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3"/>',repeatOne:'<path d="m17 2 4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3"/><path d="M12 11v5m-1-4 1-1"/>',queue:'<path d="M4 5h16M4 10h16M4 15h10M17 17v5m-3-2.5 3-2.5 3 2.5"/>',device:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',download:'<path d="M12 3v13m-5-5 5 5 5-5M4 19v2h16v-2"/>',sort:'<path d="M3 7h15M3 12h11M3 17h7M19 14l3 3-3 3m3-3v-7"/>',grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',list:'<path d="M9 6h12M9 12h12M9 18h12M3 6h.1M3 12h.1M3 18h.1"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a2 2 0 0 0 .4 2.2l-2.5 2.5a2 2 0 0 0-2.2-.4 2 2 0 0 0-1.2 1.8h-3.8A2 2 0 0 0 9 19.3a2 2 0 0 0-2.2.4l-2.5-2.5a2 2 0 0 0 .4-2.2 2 2 0 0 0-1.8-1.2v-3.6A2 2 0 0 0 4.7 9a2 2 0 0 0-.4-2.2l2.5-2.5A2 2 0 0 0 9 4.7a2 2 0 0 0 1.2-1.8h3.6A2 2 0 0 0 15 4.7a2 2 0 0 0 2.2-.4l2.5 2.5A2 2 0 0 0 19.3 9a2 2 0 0 0 1.8 1.2v3.6A2 2 0 0 0 19.4 15Z"/>',bell:'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M19.07 4.93l-1.42 1.42M6.35 17.65l-1.42 1.42"/>',moon:'<path d="M20 14.3A8 8 0 0 1 9.7 4 8.6 8.6 0 1 0 20 14.3z"/>',equalizer:'<path d="M4 9v6M8 4v16M12 7v10M16 2v20M20 10v4"/>',folder:'<path d="M3 6a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',music:'<path d="M9 18V5l12-2v13M9 9l12-2"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',album:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/>',artist:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',back:'<path d="m19 12-7 7-7-7M12 19V5"/>',sliders:'<path d="M4 7h16M4 17h16M8 4v6m8 4v6"/>',x:'<path d="M5 5 19 19M19 5 5 19"/>',drag:'<path d="M4 7h16M4 12h16M4 17h16"/>',edit:'<path d="m4 20 4.5-1 11-11-3.5-3.5-11 11zM14 6l3.5 3.5"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',share:'<path d="M12 16V3m-5 5 5-5 5 5M5 14v6h14v-6"/>',lock:'<rect x="4" y="11" width="16" height="11" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',sound:'<path d="M4 10h4l5-4v12l-5-4H4zM17 9a5 5 0 0 1 0 6"/>',checkcircle:'<circle cx="12" cy="12" r="10"/><path d="m7 12 3.5 3.5L17 9"/>',sparkles:'<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 18l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/>',chevronDown:'<path d="m6 9 6 6 6-6"/>',headphones:'<path d="M3 14v-3a9 9 0 0 1 18 0v3M3 14h5v7H6a3 3 0 0 1-3-3zm18 0h-5v7h2a3 3 0 0 0 3-3z"/>',filter:'<path d="M4 7h16M7 12h10M10 17h4"/>'};
function I(n,s='',klass=''){return `<svg class="ico ${s} ${klass}" viewBox="0 0 24 24" aria-hidden="true">${icons[n]||icons.music}</svg>`}
const art=id=>`art/${id}.jpg`;
// No seeded music, simulated tracks, recommendation feed, or fake artist statistics.
let tracks=[];
let collections=[{id:'liked',name:'Liked Songs',art:'likedsongs',type:'Playlist',desc:'Saved favorites',songIds:[]}];
const FALLBACK_ART='data:image/svg+xml;charset=utf-8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="320" viewBox="0 0 320 320"><defs><linearGradient id="a" x2="1" y2="1"><stop stop-color="#314c40"/><stop offset="1" stop-color="#171e1b"/></linearGradient></defs><rect width="320" height="320" fill="url(#a)"/><g fill="none" stroke="#9dbba1" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" opacity=".75"><path d="M135 92v110a28 28 0 1 1-17-26V110l92-20v93a28 28 0 1 1-17-26V70z"/></g></svg>');
function trackArt(t){return t&&t.cover?esc(t.cover):FALLBACK_ART}
const HAS_NATIVE=!!window.MotifAndroid;
let browserAudio=null,mediaDb=null,libraryLoaded=false,nativeStats={totalBytes:0,freeBytes:0,storageBytes:0},mediaRefreshActive=false;
function saved(){try{return JSON.parse(localStorage.getItem('motif-state'))||{}}catch(e){return {}}}
const store=saved();
const starterPlaylists=[];
const legacyAccount={id:'p-default',name:'Listener',handle:'listener',avatar:'sunset',image:null,liked:store.liked||[],custom:store.custom||starterPlaylists};
const priorAccounts=store.accounts||(Object.keys(store).length?[legacyAccount]:[]);
const accounts=store.schemaVersion===1?priorAccounts:priorAccounts.map(a=>({...a,liked:[],custom:(a.custom||[]).filter(c=>String(c.id).startsWith('custom')).map(c=>({...c,songIds:[]}))}));
const currentAccount=accounts.find(a=>a.id===store.accountId)||accounts[0]||{id:null,liked:[],custom:[]};
const S={screen:accounts.length?'home':'welcome',tab:'home',detail:null,artist:null,viewPlayer:false,aux:null,sheet:null,modal:null,search:'',searchFilter:'All',homeFilter:'All',libFilter:'All',libGrid:false,sort:'Recently added',playing:false,hasPlayed:false,track:null,position:0,shuffle:false,repeat:0,accounts,accountId:currentAccount.id,liked:new Set((currentAccount.liked||[]).map(String)),custom:currentAccount.custom||[],opts:{dark:true,motion:true,...(store.opts||{})},screenStack:[],activeQueue:[],history:store.schemaVersion===1?store.history||[]:[],selectedTarget:null,editorDraft:null,profileDraft:null,accountSwitchContext:'settings',lyrics:store.schemaVersion===1?store.lyrics||{}:{}};
function persist(){
 const a=S.accounts.find(a=>a.id===S.accountId);
 if(a){a.liked=[...S.liked];a.custom=S.custom}
 try{localStorage.setItem('motif-state',JSON.stringify({accounts:S.accounts,accountId:S.accountId,opts:S.opts,history:S.history.slice(0,20),lyrics:S.lyrics,schemaVersion:1}))}catch(e){if(e?.name==='QuotaExceededError')toast('Storage full. Try a smaller image.');}
}
function allCollections(){return [collections[0],...S.custom]}
function cById(id){return allCollections().find(c=>c.id===id)||collections[0]}
function account(){return S.accounts.find(a=>a.id===S.accountId)||S.accounts[0]}
const avatarGradients={sunset:'linear-gradient(145deg,#eec4a3,#ad6e91 58%,#624e81)',lime:'linear-gradient(140deg,#d8f48d,#589e7b 65%,#2a605b)',violet:'linear-gradient(135deg,#b3a3f0,#7778cb 65%,#3a3567)',ocean:'linear-gradient(135deg,#8bc6d3,#438ca3 65%,#365075)',ember:'linear-gradient(145deg,#e7b279,#ad634f 60%,#583b4e)',slate:'linear-gradient(145deg,#b5c6c8,#5b7287 62%,#354454)'};
function profileAvatar(a=account(),size=''){return `<span class="profile-avatar ${size}" style="background:${avatarGradients[a.avatar]||avatarGradients.sunset}">${a.image?`<img src="${esc(a.image)}" alt="">`:esc((a.name||'M').trim().charAt(0).toUpperCase())}</span>`}
function cover(c){return c.coverData||art(c.art||'nightdrive')}
function coverPicker(value){return `<div class="cover-palette">${['nightdrive','softfocus','golden','focus','nights','archive'].map(p=>`<button class="cover-choice ${value===p?'selected':''}" data-act="coverPick" data-value="${p}" aria-label="Select cover ${p}"><img src="${art(p)}" alt="">${value===p?`<span>${I('check','sm')}</span>`:''}</button>`).join('')}</div>`}
function storageSize(){return tracks.reduce((sum,t)=>sum+(t.bytes||0),0)}
function sizeString(bytes){if(!Number.isFinite(bytes)||bytes<=0)return '0 B';const units=['B','KB','MB','GB','TB'];let n=bytes,i=0;while(n>=1024&&i<units.length-1){n/=1024;i++}return `${n>=100?Math.round(n):n.toFixed(n>=10?1:2)} ${units[i]}`}
function approxSize(){return sizeString(storageSize())}
function format(t){return `${Math.floor(t/60)}:${String(Math.floor(t%60)).padStart(2,'0')}`}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function mark(){return '<span class="brandglyph"><b></b><b></b><b></b></span>'}
let transitionIntent="forward"; // MOTIF_MOTION_V3
function open(screen,data){transitionIntent="forward";if(S.viewPlayer)S.viewPlayer=false;if(S.aux)S.aux=null;S.screenStack.push({screen:S.screen,detail:S.detail,artist:S.artist});S.screen=screen;if(screen==='detail')S.detail=data;if(screen==='artist')S.artist=data;if(['home','search','import','library'].includes(screen))S.tab=screen;render()}
function back(){transitionIntent="back";if(S.sheet){S.sheet=null;render();return}if(S.modal){S.modal=null;render();return}if(S.aux){S.aux=null;render();return}if(S.viewPlayer){S.viewPlayer=false;render();return}const prev=S.screenStack.pop();if(prev){S.screen=prev.screen;S.detail=prev.detail;S.artist=prev.artist;if(['home','search','import','library'].includes(S.screen))S.tab=S.screen}else{S.screen='home';S.tab='home'}render()}
window.appGoBack=back;
function section(title,body,right=''){return `<div class="section-heading">${title}${right?`<span class="more">${right}</span>`:''}</div>${body}`}
function mediaCard(c,extra=''){return `<button class="media-card ${extra}" data-act="collection" data-id="${c.id}"><img class="cover" src="${cover(c)}" alt=""><div class="name clamp1">${esc(c.name)}</div><div class="caption clamp2">${c.id==='liked'?`${S.liked.size} tracks`:`${c.songIds.length+(c.importedMissing?.length||0)} tracks · ${c.type}`}</div></button>`}
function mediaRow(cs){return `<div class="horizontal-scroll">${cs.map(c=>mediaCard(c)).join('')}</div>`}
function getTrack(id){return tracks.find(t=>String(t.id)===String(id))}
function trackRow(t,opts={}){return `<div class="track ${opts.album?'album-song':''}" data-act="playTrack" data-id="${t.id}"><img src="${trackArt(t)}" alt=""><div class="info"><div class="name clamp1" style="${S.track===t.id?'color:var(--accent)':''}">${esc(t.title)}</div><div class="meta clamp1">${esc(t.artist)}${opts.subtitle?' · '+esc(opts.subtitle):''}</div></div>${S.track===t.id&&S.playing?'<span class="equalizer"><i></i><i></i><i></i></span>':''}<button class="tail" data-act="menuTrack" data-id="${t.id}" aria-label="Track options">${I('moreV','sm')}</button></div>`}
function tracksHTML(ids,opts={}){return ids.map(id=>getTrack(id)).filter(Boolean).map((t,n)=>trackRow(t,{...opts,number:n+1})).join('')}
function emptyLibraryState(){return `<div class="empty-library"><div class="empty-library-glyph">${I('music','lg')}</div><strong>${libraryLoaded?'Your library is empty':'Finding your music'}</strong><p>${HAS_NATIVE?'Choose audio files or scan music already on your phone.':'Import audio files from your device to start listening.'}</p><button class="pill-primary" data-act="importMusic">${I('plus','sm')} Add music</button>${HAS_NATIVE?`<button class="empty-secondary" data-act="rescan">Scan phone library</button>`:''}</div>`}
function home(){
 const quick=allCollections().slice(0,8);
 const filter=S.homeFilter;
 const visible=filter==='Tracks'?[]:quick;
 const recently=[...S.history,...tracks.map(t=>t.id)].filter((id,i,a)=>a.indexOf(id)===i&&tracks.some(t=>t.id===id)).slice(0,6);
 return `<div class="screen screen-home"><div class="hero-wash"></div><div class="head home-head"><button data-act="profile" aria-label="Profile">${profileAvatar()}</button><div class="chips">${['All','Tracks','Playlists'].map(c=>`<button class="chip ${filter===c?'active':''}" data-act="homeFilter" data-value="${c}">${c}</button>`).join('')}</div><button class="icon-button push" data-act="settings" aria-label="Settings">${I('settings')}</button></div>
 ${filter!=='Tracks'&&visible.length?`<div class="quick-grid">${visible.map(c=>`<button class="tile" data-act="collection" data-id="${c.id}"><img src="${cover(c)}" alt=""><strong class="clamp2">${esc(c.name)}</strong></button>`).join('')}</div>`:''}
 ${filter!=='Playlists'?section('Your tracks',`<div class="home-tracks">${recently.length?tracksHTML(recently):emptyLibraryState()}</div>`,`<button class="text-link" data-act="viewTracks">See all ${I('arrowRight','xs')}</button>`):''}
 ${filter!=='Tracks'?section('Your playlists',S.custom.length?mediaRow(S.custom):`<div class="empty-state">Create your first playlist to organize your music.</div>`,`<button class="text-link" data-act="create">${I('plus','xs')} New</button>`):''}
 ${filter==='All'&&tracks.length?`<div class="library-spotlight"><div class="spot-art">${I('music','lg')}</div><div><div class="spot-eyebrow">YOUR COLLECTION</div><strong>${tracks.length} ${tracks.length===1?'track':'tracks'}. All yours.</strong><span>Your music, organized your way.</span></div><button class="spot-arrow" data-act="viewTracks" aria-label="Explore tracks">${I('arrowRight')}</button></div>`:''}
 </div>`}
function searchResults(){
 const query=S.search.trim().toLowerCase(),f=S.searchFilter;
 if(!query)return `<div class="search-invite"><div class="search-invite-icon">${I('search','lg')}</div><strong>Find something good.</strong><p>Search your tracks and playlists.</p></div>${section('Your playlists',S.custom.length?mediaRow(S.custom.slice(0,6)):`<div class="empty-state">No playlists yet.</div>`)}`;
 const songs=tracks.filter(t=>[t.title,t.artist,t.album].some(x=>x.toLowerCase().includes(query)));
 const cs=allCollections().filter(c=>c.name.toLowerCase().includes(query));
 let out=`<div class="chips app-pad search-chips">${['All','Tracks','Playlists'].map(x=>`<button class="chip ${f===x?'active':''}" data-act="searchFilter" data-value="${x}">${x}</button>`).join('')}</div>`;
 if((f==='All'||f==='Tracks')&&songs.length)out+=section('Tracks',songs.slice(0,f==='All'?7:99).map(t=>trackRow(t)).join(''));
 if((f==='All'||f==='Playlists')&&cs.length)out+=section('Playlists',mediaRow(cs));
 if(out.indexOf('section-heading')===-1)out+=`<div class="no-results">${I('search','lg')}<strong>No matches</strong>Try another title, artist, or playlist.</div>`;
 return out;
}
function search(){return `<div class="screen"><div class="search-head"><h1 class="main-title">Search</h1><button data-act="profile" class="push" aria-label="Profile">${profileAvatar(account(),'small')}</button></div><label class="search-field">${I('search')}<input id="search-input" placeholder="Tracks or playlists" autocomplete="off" value="${esc(S.search)}"><button data-act="clearSearch" style="${S.search?'':'display:none'}">${I('x','sm')}</button></label><div id="search-results">${searchResults()}</div></div>`}
function libraryList(){
 if(S.libFilter==='Tracks'){
 let list=[...tracks];
 if(S.sort==='Alphabetical')list.sort((a,b)=>a.title.localeCompare(b.title));
 if(S.sort==='Artist')list.sort((a,b)=>a.artist.localeCompare(b.artist));
 return `<div class="library-track-list">${list.length?list.map(t=>trackRow(t)).join(''):emptyLibraryState()}</div>`;
 }
 let cs=allCollections();
 if(S.sort==='Alphabetical')cs=[...cs].sort((a,b)=>a.name.localeCompare(b.name));
 else if(S.sort==='Recently added')cs=[...cs].reverse();
 if(S.libGrid)return `<div class="library-grid">${cs.map(c=>mediaCard(c)).join('')}</div>`;
 return cs.map(c=>`<button class="library-item" data-act="collection" data-id="${c.id}"><img src="${cover(c)}" alt=""><div><div class="name clamp1">${esc(c.name)}</div><div class="caption clamp1">${c.id==='liked'?S.liked.size:c.songIds.length+(c.importedMissing?.length||0)} tracks · Playlist</div></div><span data-act="menuCollection" data-id="${c.id}" class="icon-button">${I('moreV','sm')}</span></button>`).join('');
}
function library(){const count=S.libFilter==='Tracks'?tracks.length:allCollections().length;return `<div class="screen"><div class="library-toolbar"><button data-act="profile" aria-label="Profile">${profileAvatar(account(),'small')}</button><div class="name">Your Library</div><button class="icon-button" data-act="libSearch" aria-label="Search library">${I('search')}</button><button class="icon-button create-button" data-act="create" aria-label="Create playlist">${I('plus','lg')}</button></div><div class="chips library-filters">${['All','Playlists','Tracks'].map(c=>`<button class="chip ${S.libFilter===c?'active':''}" data-act="libFilter" data-value="${c}">${c}</button>`).join('')}</div><div class="sort-row"><button data-act="sort">${I('sort','xs')} ${esc(S.sort)} ${I('chevronDown','xs')}</button><span class="library-count">${count} ${S.libFilter==='Tracks'?'tracks':'playlists'}</span>${S.libFilter!=='Tracks'?`<button class="view-switch" data-act="viewToggle" aria-label="Switch view">${I(S.libGrid?'list':'grid','sm')}</button>`:''}</div>${S.libFilter==='All'?`<div class="library-inline-title">Playlists <button data-act="create">${I('plus','sm')} New</button></div>`:''}<div class="library-list">${libraryList()}</div>${S.libFilter==='All'?`<button class="library-all-tracks" data-act="viewTracks"><span class="all-tracks-icon">${I('music')}</span><span><strong>All tracks</strong><small>${tracks.length} tracks</small></span>${I('arrowRight','sm')}</button>`:''}<div style="height:25px"></div></div>`}
function detail(){
 const c=cById(S.detail);const ids=(c.id==='liked'?[...S.liked]:c.songIds).filter(id=>!!getTrack(id));const dur=ids.reduce((sum,id)=>sum+getTrack(id).seconds,0);
 const col={liked:'#55519d',night:'#405e75',repeat:'#764979',focus:'#4b7863',golden:'#827045',nostalgia:'#66725e'}[c.id]||'#526456';
 return `<div class="screen screen-detail"><div class="detail-top" style="--detailColor:${col}"><div class="backline"><button class="icon-button" data-act="back">${I('arrowLeft','lg')}</button></div><img class="detail-art" src="${cover(c)}" alt="Playlist artwork"></div><div class="detail-body"><div class="detail-title">${esc(c.name)}</div><p class="detail-description">${esc(c.desc||'')}</p><div class="detail-owner">${profileAvatar(account(),'small')}${esc(account().name)}</div><div class="detail-info">${ids.length+(c.importedMissing?.length||0)} tracks · ${Math.round(dur/60)} min</div><div class="detail-actions">${c.id!=='liked'?`<button data-act="editPlaylist" data-id="${c.id}" aria-label="Edit playlist">${I('edit')}</button>`:''}<button data-act="menuCollection" data-id="${c.id}" aria-label="More playlist options">${I('moreV')}</button><span class="push"></span><button data-act="toggleShuffle" style="color:${S.shuffle?'var(--accent)':'#a6ada6'}" aria-label="Shuffle">${I('shuffle')}</button><button class="circle-play large" data-act="playCollection" data-id="${c.id}">${I('play','lg')}</button></div></div><div class="playlist-track-list">${ids.length?tracksHTML(ids):!c.importedMissing?.length?`<div class="empty-state">${I('music','lg')}<strong>No tracks yet</strong>Add songs from Search or All tracks.</div>`:''}${pendingTrackRows(c)}</div>${c.id!=='liked'?`<button class="playlist-add" data-act="addTracks" data-id="${c.id}">${I('plus','sm')} Add tracks</button>`:''}</div>`;
}
function settings(){
 const row=(icon,title,subtitle,act)=>`<button class="setting-item" data-act="${act}"><span class="sico">${I(icon)}</span><span class="setting-text"><span class="name">${title}</span><span class="desc">${subtitle}</span></span>${I('arrowRight','sm')}</button>`;
 const toggle=(key,title,subtitle,icon)=>`<button class="setting-item" data-act="setting" data-id="${key}"><span class="sico">${I(icon)}</span><span class="setting-text"><span class="name">${title}</span><span class="desc">${subtitle}</span></span><span class="toggle ${S.opts[key]?'on':''}"></span></button>`;
 return `<div class="screen settings-page"><div class="settings-header"><button class="icon-button" data-act="back">${I('arrowLeft')}</button><h1>Settings</h1></div><button class="profile-card profile-navigation" data-act="profile">${profileAvatar(account(),'medium')}<div class="profile-intro"><strong>${esc(account().name)}</strong><p>View and edit profile</p></div>${I('arrowRight','sm')}</button><div class="settings-group"><h2>Account</h2>${row('artist','Manage accounts','Profiles and switching','accounts')}${row('edit','Edit profile','Name and profile picture','editProfile')}</div><div class="settings-separator"></div><div class="settings-group"><h2>Library</h2>${row('album','Storage usage','View music space and breakdown','storage')}${row('plus','Add music files','Choose audio files from your device','importMusic')}${row('refresh','Rescan library','Check for new music','rescan')}${row('music','All tracks',`${tracks.length} tracks available`,'viewTracks')}${row('list','Your playlists',`${allCollections().length} playlists`,'viewPlaylists')}</div><div class="settings-separator"></div><div class="settings-group"><h2>Appearance</h2>${toggle('dark','Dark theme','Switch the interface theme','moon')}${toggle('motion','Interface animations','Transitions and motion effects','sparkles')}</div><div class="settings-separator"></div><div class="settings-group"><h2>About</h2><div class="setting-item info-item"><span class="sico">${I('info')}</span><span class="setting-text"><span class="name">Motif</span><span class="desc">Version 1.0 · Offline music player</span></span></div></div><div class="settings-bottom"></div></div>`;
}
function mini(){if(S.screen==='welcome'||!S.hasPlayed||!getTrack(S.track))return '';const t=getTrack(S.track);if(!t)return '';return `<div class="mini-player" data-act="expandPlayer"><img src="${trackArt(t)}" alt=""><div class="info"><div class="name clamp1">${esc(t.title)}</div><div class="artist clamp1">${esc(t.artist)}</div></div><button data-act="like" data-id="${t.id}" aria-label="Like track" style="color:${S.liked.has(t.id)?'var(--accent)':'#f0f4f0'}">${I(S.liked.has(t.id)?'heartFill':'heart','sm')}</button><button data-act="togglePlay" aria-label="${S.playing?'Pause':'Play'}">${I(S.playing?'pause':'play')}</button><div class="mini-progress"><span style="width:${Math.min(100,S.position/t.seconds*100)}%"></span></div></div>`}
function nav(){if(S.screen==='welcome')return '';return `<nav class="tabbar" aria-label="Main navigation">${[['home','Home'],['search','Search'],['import','Downloads'],['library','Your Library']].map(([name,label])=>`<button class="${S.tab===name?'on':''}" data-act="tab" data-value="${name}" aria-label="${label}" ${S.tab===name?'aria-current="page"':''}><span class="nav-icon">${I(name,'','nav-outline')}${I(name==='home'?'homeSolid':name==='library'?'librarySolid':name==='import'?'importSolid':'search','','nav-solid')}</span><span class="nav-label">${label}</span></button>`).join('')}</nav>`}

function player(){
 const t=getTrack(S.track);if(!t)return '';const p=Math.max(0,Math.min(100,S.position/Math.max(1,t.seconds)*100));
 const cl=['#65776b','#374d40','#1b2a23'];
 return `<div class="player-view"><div class="player-screen" style="--playTop:${cl[0]};--playMid:${cl[1]};--playBottom:${cl[2]}"><div class="player-header"><button class="icon-button" data-act="collapsePlayer" aria-label="Minimize player">${I('chevronDown','lg')}</button><div class="context"><div class="over">NOW PLAYING</div><div class="under clamp1">${esc(t.album)}</div></div><button class="icon-button" data-act="menuTrack" data-id="${t.id}" aria-label="Track options">${I('moreV')}</button></div><img class="player-art" src="${trackArt(t)}" alt="${esc(t.album)} artwork"><div class="player-track"><div class="info"><div class="name clamp1">${esc(t.title)}</div><div class="artist clamp1">${esc(t.artist)}</div></div><button class="icon-button like ${S.liked.has(t.id)?'liked':''}" data-act="like" data-id="${t.id}" aria-label="Like this track">${I(S.liked.has(t.id)?'heartFill':'heart','lg')}</button></div><div class="seek"><input id="seek-range" type="range" min="0" max="${t.seconds}" value="${S.position}" style="--progress:${p}%" aria-label="Seek track"><div class="times"><span id="current-time">${format(S.position)}</span><span>${format(t.seconds)}</span></div></div><div class="player-controls"><button class="${S.shuffle?'active':''}" data-act="toggleShuffle" aria-label="Shuffle">${I('shuffle')}</button><button data-act="previous" aria-label="Previous track">${I('prev','lg')}</button><button class="main-play" data-act="togglePlay" aria-label="${S.playing?'Pause':'Play'}">${I(S.playing?'pause':'play','lg')}</button><button data-act="next" aria-label="Next track">${I('next','lg')}</button><button class="${S.repeat?'active':''}" data-act="repeat" aria-label="Repeat">${I(S.repeat===2?'repeatOne':'repeat')}</button></div><div class="player-utilities"><button data-act="lyrics">${I('music','sm')} <span>Lyrics</span></button><div class="utility-divider"></div><button data-act="addTo" data-id="${t.id}">${I('plus','sm')}<span>Playlist</span></button><div class="utility-divider"></div><button data-act="queue">${I('queue','sm')}<span>Queue</span></button></div></div></div>`;
}
function lyricsPage(){
 const t=getTrack(S.track);if(!t)return '';const raw=S.lyrics[t.id];
 const lrc=raw?raw.split(/\r?\n/).map(x=>{const match=x.match(/^\[(\d+):(\d+(?:\.\d+)?)\](.*)$/);return match?{time:Number(match[1])*60+Number(match[2]),text:match[3].trim()}:null}).filter(Boolean):[];
 const lines=raw?(lrc.length?lrc:raw.split(/\r?\n/).filter(Boolean).map(x=>({text:x}))):[];
 return `<div class="player-view auxiliary-view lyrics-view"><div class="lyrics-screen"><div class="heading"><button class="icon-button" data-act="auxBack">${I('arrowLeft')}</button><div class="heading-title"><div class="eyebrow">LYRICS</div><strong>${esc(t.title)}</strong></div><button class="icon-button" data-act="importLyrics" aria-label="Import lyrics">${I('plus')}</button></div>${lines.length?`<div class="lines">${lines.map(l=>`<p class="${l.time!=null&&l.time<=S.position?'current':''}">${esc(l.text)}</p>`).join('')}</div><button class="lyrics-import-link" data-act="importLyrics">${I('edit','sm')} Replace lyrics</button>`:`<div class="lyrics-empty"><div class="lyrics-symbol">${I('music','lg')}</div><h2>No lyrics added</h2><p>Import an LRC or text file to display lyrics for this track.</p><button class="pill-primary" data-act="importLyrics">${I('plus','sm')} Import lyrics</button></div>`}<div class="floating"><img class="cover" src="${trackArt(t)}" alt=""><span class="floating-copy"><strong>${esc(t.title)}</strong><small>${esc(t.artist)}</small></span><button data-act="togglePlay">${I(S.playing?'pause':'play')}</button></div></div></div>`;
}
function queuePage(){const t=getTrack(S.track);if(!t)return '';const follow=S.activeQueue.filter(id=>!!getTrack(id)&&String(id)!==String(S.track));return `<div class="player-view auxiliary-view queue-view"><div class="queue-screen"><div class="header"><button class="icon-button" data-act="auxBack">${I('arrowLeft')}</button><strong>Queue</strong></div><div class="queue-label">Now playing</div><div class="queue-card"><img src="${trackArt(t)}"><div class="info"><strong>${esc(t.title)}</strong><span>${esc(t.artist)}</span></div><button data-act="togglePlay">${I(S.playing?'pause':'play')}</button></div><div class="queue-label">Next up <span class="subtle" style="font-weight:400">· ${follow.length} tracks</span></div>${follow.map((id,i)=>`<div class="track" data-act="playTrack" data-id="${id}"><img src="${trackArt(getTrack(id))}"><div class="info"><div class="name clamp1">${esc(getTrack(id).title)}</div><div class="meta clamp1">${esc(getTrack(id).artist)}</div></div><button class="drag" data-act="removeQueue" data-index="${i}" title="Remove">${I('x','sm')}</button><button class="drag" data-act="moveQueue" data-index="${i}" title="Move down">${I('chevronDown','sm')}</button></div>`).join('')}<div class="spacer20"></div></div></div>`}
function sheet(){if(!S.sheet)return '';const item=S.sheet;let t=getTrack(item.id)||getTrack(S.track)||{id:0,title:'',artist:''};let c=cById(item.id||'liked');let title=item.type==='track'?t.title:item.type==='sort'?'Sort by':item.type==='target'?'Add to playlist':c.name;let opts=[];
 if(item.type==='track')opts=[['like',S.liked.has(t.id)?'Remove from Liked Songs':'Add to Liked Songs','heart'],['addTo','Add to playlist','plus'],['queueAdd','Add to queue','queue']];
 else if(item.type==='sort')opts=(S.libFilter==='Tracks'?['Recently added','Alphabetical','Artist']:['Recently added','Alphabetical']).map(x=>['selectSort',x,S.sort===x?'check':'sort']);
 else if(item.type==='target')opts=[...allCollections().filter(c=>c.id!=='liked').map(c=>['targetAdd',c.name,'plus',c.id]),['create','Create playlist','plus']];
 else opts=[['playCollection','Play playlist','play'],...(c.id!=='liked'?[['editPlaylist','Edit playlist','edit'],['deletePlaylist','Delete playlist','x']]:[])];
 return `<div class="sheet-overlay" data-act="dismiss"><div class="sheet" data-no-dismiss><div class="sheet-handle"></div><div class="sheet-head">${item.type==='track'?`<img src="${trackArt(t)}" alt="">`:''}<div class="sheet-heading"><strong>${esc(title)}</strong>${item.type==='track'?`<div class="muted">${esc(t.artist)}</div>`:''}</div><button data-act="dismiss" aria-label="Close">${I('x','sm')}</button></div>${opts.map(o=>`<button class="sheet-option" data-act="${o[0]}" data-id="${o[3]||item.id||S.track}" ${o[0]==='selectSort'?`data-value="${o[1]}"`:''}>${I(o[2])}<span>${esc(o[1])}</span></button>`).join('')}</div></div>`;
}
function modal(){if(!S.modal)return '';if(S.modal==='confirmRemoveAccount')return `<div class="modal-overlay" data-act="dismiss"><div class="modal" data-no-dismiss><h2>Delete account?</h2><p class="helper">This removes the profile and its playlists from this device. Your music files will not be deleted.</p><div class="modal-foot"><button data-act="dismiss">Cancel</button><button class="danger-button" data-act="confirmRemoveAccount">Delete</button></div></div></div>`;if(S.modal==='confirmDelete')return `<div class="modal-overlay" data-act="dismiss"><div class="modal" data-no-dismiss><h2>Delete playlist?</h2><p class="helper">This removes the playlist, not the music in it.</p><div class="modal-foot"><button data-act="dismiss">Cancel</button><button class="danger-button" data-act="confirmDelete">Delete playlist</button></div></div></div>`;return '';}
function welcome(){return `<div class="screen welcome-screen"><div class="welcome-glow"></div><div class="welcome-mark">${mark()}</div><div class="welcome-content"><span class="welcome-label">MOTIF</span><h1>A better home<br>for your music.</h1><p>All your tracks and playlists, exactly where you want them.</p><button class="pill-primary welcome-action" data-act="newAccount">Create account ${I('arrowRight','sm')}</button><div class="welcome-caption">Create your profile to get started.</div></div></div>`}
function playlistEditor(){const d=S.editorDraft||{name:'',desc:'',art:'nightdrive',coverData:null,songIds:[]};const editing=!!d.id;return `<div class="screen editor-screen"><div class="editor-top"><button data-act="back">Cancel</button><strong>${editing?'Edit playlist':'New playlist'}</strong><button class="editor-save" data-act="savePlaylist">Save</button></div><div class="editor-art"><img src="${d.coverData||art(d.art)}" alt="Playlist cover"><span class="editor-cover-overlay">${I('edit','sm')} Cover art</span></div><div class="editor-caption">Choose a cover</div>${coverPicker(d.art)}<button class="editor-upload" data-act="choosePlaylistImage">${I('plus','sm')} Upload image</button><div class="editor-fields"><label>PLAYLIST NAME<input id="playlist-name" maxlength="60" placeholder="Give it a name" value="${esc(d.name)}"></label><label>DESCRIPTION<textarea id="playlist-desc" maxlength="220" rows="3" placeholder="Add a description (optional)">${esc(d.desc)}</textarea></label></div>${editing?`<button class="editor-delete" data-act="deletePlaylist" data-id="${d.id}">${I('x','sm')} Delete playlist</button>`:''}<input id="playlist-file-input" type="file" accept="image/*" hidden></div>`}
function profilePage(){const a=account();return `<div class="screen profile-page"><div class="settings-header"><button class="icon-button" data-act="back">${I('arrowLeft')}</button><h1>Profile</h1><button class="icon-button push" data-act="editProfile" aria-label="Edit">${I('edit')}</button></div><div class="profile-hero"><div class="profile-halo">${profileAvatar(a,'huge')}</div><h1>${esc(a.name)}</h1><p>@${esc(a.handle)}</p><button class="secondary-pill" data-act="editProfile">Edit profile</button></div><div class="profile-stats"><span><strong>${S.custom.length}</strong> Playlists</span><span><strong>${tracks.length}</strong> Tracks</span><span><strong>${S.liked.size}</strong> Liked</span></div><div class="settings-group"><h2>Manage</h2><button class="setting-item" data-act="accounts"><span class="sico">${I('artist')}</span><span class="setting-text"><span class="name">Switch account</span><span class="desc">Manage profiles</span></span>${I('arrowRight','sm')}</button><button class="setting-item" data-act="storage"><span class="sico">${I('album')}</span><span class="setting-text"><span class="name">Storage</span><span class="desc">Music space overview</span></span>${I('arrowRight','sm')}</button></div></div>`}
function profileEditor(){const d=S.profileDraft||{};return `<div class="screen editor-screen profile-editor"><div class="editor-top"><button data-act="back">Cancel</button><strong>${d.id?'Edit profile':'Create account'}</strong><button class="editor-save" data-act="saveProfile">Save</button></div><div class="profile-editor-avatar">${profileAvatar({...d,name:d.name||'M'},'huge')}</div><div class="editor-caption">Choose a profile picture</div><div class="avatar-palette">${Object.entries(avatarGradients).map(([k,v])=>`<button class="avatar-choice ${d.avatar===k?'selected':''}" data-act="avatarPick" data-value="${k}" style="background:${v}">${d.avatar===k?I('check','sm'):esc((d.name||'M')[0].toUpperCase())}</button>`).join('')}</div><button class="editor-upload" data-act="chooseAvatarImage">${I('plus','sm')} Upload photo</button><div class="editor-fields"><label>DISPLAY NAME<input id="profile-name" maxlength="30" placeholder="Your name" value="${esc(d.name||'')}"></label><label>USERNAME<input id="profile-handle" maxlength="24" placeholder="username" value="${esc(d.handle||'')}"></label></div><div class="editor-note">Profiles are saved on this device in the UI prototype. Account authentication is not connected yet.</div><input id="avatar-file-input" type="file" accept="image/*" hidden></div>`}
function accountsPage(){return `<div class="screen accounts-page"><div class="settings-header"><button class="icon-button" data-act="back">${I('arrowLeft')}</button><h1>Accounts</h1></div><div class="account-label">CHOOSE A PROFILE</div><div class="accounts-list">${S.accounts.map(a=>`<button class="account-row ${a.id===S.accountId?'selected':''}" data-act="switchAccount" data-id="${a.id}">${profileAvatar(a,'medium')}<span class="account-copy"><strong>${esc(a.name)}</strong><small>@${esc(a.handle)}</small></span>${a.id===S.accountId?`<span class="account-current">Current ${I('check','sm')}</span>`:I('arrowRight','sm')}</button>`).join('')}</div><button class="account-add" data-act="newAccount">${I('plus','sm')} Create an account</button><div class="account-note">Profiles and their playlists stay on this device. There is no cloud account or sign-in.</div>${S.accounts.length>1?`<button class="account-remove" data-act="removeAccount">Delete current account</button>`:''}</div>`}
function storagePage(){const n=storageSize(),avail=nativeStats.freeBytes||0;return `<div class="screen storage-page"><div class="settings-header"><button class="icon-button" data-act="back">${I('arrowLeft')}</button><h1>Storage</h1><button class="icon-button push" data-act="rescan" aria-label="Refresh library">${I('refresh')}</button></div><div class="storage-hero"><div class="storage-overline">MUSIC STORAGE</div><div class="storage-number">${sizeString(n)}</div><div class="storage-subtitle">Audio files in your music library</div><div class="storage-chart"><div class="storage-center">${I('music','lg')}<small>${tracks.length} tracks</small></div></div></div><div class="storage-legend"><div><i class="storage-dot primary-dot"></i><span>Music files <small>Actual file sizes</small></span><strong>${sizeString(n)}</strong></div><div><i class="storage-dot secondary-dot"></i><span>Available device space <small>${HAS_NATIVE?'Internal shared storage':'Browser storage'}</small></span><strong>${avail?sizeString(avail):'—'}</strong></div></div><div class="storage-summary"><div><strong>${tracks.length}</strong><small>Tracks</small></div><div><strong>${S.custom.length+1}</strong><small>Playlists</small></div><div><strong>${avail?sizeString(avail):'—'}</strong><small>Free space</small></div></div><div class="storage-disclaimer">${I('info','sm')}<span>Sizes reflect the audio files accessible to Motif. Playlists do not duplicate music files.</span></div></div>`}
function addTracksPage(){const c=cById(S.detail);const selected=new Set(c.songIds);return `<div class="screen add-tracks-page"><div class="settings-header"><button class="icon-button" data-act="back">${I('arrowLeft')}</button><h1>Add tracks</h1></div><p class="app-pad subtle">Choose tracks for <strong>${esc(c.name)}</strong></p><div class="add-tracks-list">${tracks.map(t=>`<button class="add-song" data-act="togglePlaylistTrack" data-id="${t.id}"><img src="${trackArt(t)}" alt=""><span class="song-copy"><strong>${esc(t.title)}</strong><small>${esc(t.artist)}</small></span><span class="song-check ${selected.has(t.id)?'checked':''}">${selected.has(t.id)?I('check','sm'):I('plus','sm')}</span></button>`).join('')}</div></div>`}
// Keep chrome mounted. Rebuilding every node on every tap restarted animations,
// causing flicker, double entrance effects and disappearing focus states.
function render(){
 const root=$('#app');
 const previousScreen=Array.from(root.children).find(x=>x.classList.contains('screen')&&!x.classList.contains('motion-leave'));
 const oldName=root.dataset.screen||'';
 const sameScreen=oldName===S.screen;
 const oldScroll=previousScreen?.scrollTop||0;
 const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||false;
 const animated=S.opts.motion&&!reduce;
 const direction=transitionIntent;
 transitionIntent='forward';
 root.classList.toggle('light',!S.opts.dark);
 root.classList.toggle('no-motion',!S.opts.motion);
 const html=S.screen==='welcome'?welcome():S.screen==='home'?home():S.screen==='search'?search():S.screen==='import'?downloadsPage():S.screen==='library'?library():S.screen==='detail'?detail():S.screen==='settings'?settings():S.screen==='playlistEditor'?playlistEditor():S.screen==='profile'?profilePage():S.screen==='profileEditor'?profileEditor():S.screen==='accounts'?accountsPage():S.screen==='storage'?storagePage():S.screen==='addTracks'?addTracksPage():S.screen==='resolve'?resolvePage():home();
 const showChrome=!['welcome','playlistEditor','profileEditor'].includes(S.screen);
 const draft=document.createElement('div');
 draft.innerHTML=html+(showChrome?mini()+nav():'')+(S.viewPlayer?player():'')+(S.aux==='lyrics'?lyricsPage():S.aux==='queue'?queuePage():'')+sheet()+modal();
 // Sweep transition remnants left by rapidly repeated navigation.
 root.querySelectorAll('.motion-leave').forEach(el=>el.remove());
 const nextScreen=draft.querySelector('.screen');
 // Tab views must never be composited on top of the outgoing view.
 // Only the newly active view is mounted; this prevents the text/image
 // double-exposure visible on Android during a rapid tab change.
 if(previousScreen){
  if(!sameScreen&&animated)nextScreen.classList.add('motion-enter','motion-'+direction);
  previousScreen.replaceWith(nextScreen);
  if(sameScreen)nextScreen.scrollTop=oldScroll;
 }else root.prepend(nextScreen);
 // Nav is one long-lived element. Its active icon fades rather than remounting.
 let oldNav=root.querySelector('.tabbar'),newNav=draft.querySelector('.tabbar');
 if(oldNav&&newNav){
  const oldButtons=oldNav.querySelectorAll('button'),newButtons=newNav.querySelectorAll('button');
  oldButtons.forEach((button,i)=>{
   const active=newButtons[i].classList.contains('on');
   button.classList.toggle('on',active);
   active?button.setAttribute('aria-current','page'):button.removeAttribute('aria-current');
  });
 }else if(oldNav&&!newNav)oldNav.remove();else if(newNav)root.appendChild(newNav);
 // Mini-player changes without replaying its entrance animation on every action.
 let oldMini=root.querySelector('.mini-player'),newMini=draft.querySelector('.mini-player');
 if(oldMini&&newMini){oldMini.innerHTML=newMini.innerHTML;}
 else if(oldMini&&!newMini)oldMini.remove();
 else if(newMini){if(animated)newMini.classList.add('mini-arrive');root.appendChild(newMini)}
 const reconcileOverlay=(selector,duration)=>{
  const existing=Array.from(root.querySelectorAll(selector)).find(e=>!e.classList.contains('motion-leave'));
  const incoming=draft.querySelector(selector);
  if(existing&&incoming){
   // This is a content update, NOT an entrance; avoid restarting motion.
   const scroll=existing.querySelector('.player-screen,.lyrics-screen,.queue-screen,.sheet')?.scrollTop||0;
   existing.replaceWith(incoming);
   const sc=incoming.querySelector('.player-screen,.lyrics-screen,.queue-screen,.sheet');if(sc)sc.scrollTop=scroll;
  }else if(existing&&!incoming){
   if(animated){existing.classList.add('motion-leave');existing.setAttribute('aria-hidden','true');existing.setAttribute('inert','');existing.querySelectorAll('[data-act]').forEach(x=>x.removeAttribute('data-act'));window.setTimeout(()=>existing.remove(),duration)}
   else existing.remove();
  }else if(incoming){
   if(animated)incoming.classList.add('motion-enter');
   root.appendChild(incoming);
  }
 };
 reconcileOverlay('.player-view:not(.auxiliary-view)',390);
 reconcileOverlay('.player-view.auxiliary-view',270);
 reconcileOverlay('.sheet-overlay',340);
 reconcileOverlay('.modal-overlay',260);
 root.dataset.screen=S.screen;
}

function toast(msg){let el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),1700)}
function syncNativeQueue(){if(HAS_NATIVE)nativeCommand('setQueue',JSON.stringify(S.activeQueue.map(i=>getTrack(i)).filter(Boolean).map(x=>({id:x.id,uri:x.uri,title:x.title,artist:x.artist}))))}
function nativeCommand(name,...args){if(HAS_NATIVE&&typeof window.MotifAndroid[name]==='function'){try{return window.MotifAndroid[name](...args)}catch(e){console.warn(name,e);toast('Playback error')}}}
function syncPlaybackUI(){const t=getTrack(S.track);if(!t)return;const ratio=Math.min(100,S.position/Math.max(1,t.seconds)*100),r=$('#seek-range');if(r){r.value=S.position;r.style.setProperty('--progress',ratio+'%')}const time=$('#current-time');if(time)time.textContent=format(S.position);const prog=$('.mini-progress span');if(prog)prog.style.width=ratio+'%'}
async function playTrack(id){const t=getTrack(id);if(!t)return;S.track=t.id;S.position=0;S.playing=true;S.hasPlayed=true;S.sheet=null;S.history=[t.id,...S.history.filter(x=>x!==t.id)].slice(0,20);if(!S.activeQueue.length||!S.activeQueue.some(i=>String(i)===String(t.id)))S.activeQueue=tracks.map(x=>x.id);persist();render();if(HAS_NATIVE){nativeCommand('play',String(t.id),JSON.stringify(S.activeQueue.map(i=>getTrack(i)).filter(Boolean).map(x=>({id:x.id,uri:x.uri,title:x.title,artist:x.artist}))),S.shuffle,S.repeat);}else{if(!browserAudio)createBrowserAudio();if(!t.url){S.playing=false;toast('The file is unavailable; import it again.');render();return}browserAudio.src=t.url;try{await browserAudio.play()}catch(e){S.playing=false;toast('Could not play this format');render()}}}
function createBrowserAudio(){browserAudio=new Audio();browserAudio.preload='metadata';browserAudio.addEventListener('loadedmetadata',()=>{const t=getTrack(S.track);if(t&&Number.isFinite(browserAudio.duration)){t.seconds=Math.max(1,Math.round(browserAudio.duration));if(mediaDb)dbTx(mediaDb,'readwrite',s=>s.put({id:t.id,title:t.title,artist:t.artist,album:t.album,seconds:t.seconds,bytes:t.bytes,dateAdded:t.dateAdded,blob:t.blob,coverBlob:t.coverBlob})).catch(()=>{});render()}});browserAudio.addEventListener('timeupdate',()=>{S.position=browserAudio.currentTime||0;syncPlaybackUI()});browserAudio.addEventListener('pause',()=>{if(!HAS_NATIVE){S.playing=false;render()}});browserAudio.addEventListener('play',()=>{S.playing=true;render()});browserAudio.addEventListener('ended',()=>{if(S.repeat===2){browserAudio.currentTime=0;browserAudio.play()}else next()});browserAudio.addEventListener('error',()=>{S.playing=false;render()})}
async function toggleRealPlayback(){if(!getTrack(S.track))return;if(HAS_NATIVE){nativeCommand('toggle');S.playing=!S.playing;render();return}if(!browserAudio||!browserAudio.src){await playTrack(S.track);return}if(browserAudio.paused){try{await browserAudio.play()}catch(e){toast('Unable to play file')}}else browserAudio.pause()}
function next(){if(!tracks.length)return;const queue=S.activeQueue.filter(x=>!!getTrack(x));let idx=queue.findIndex(x=>String(x)===String(S.track));if(!queue.length)return;
 if(!S.shuffle&&idx>=queue.length-1&&!S.repeat){S.playing=false;if(browserAudio){browserAudio.pause();browserAudio.currentTime=0}S.position=0;render();return}
 let id=S.shuffle?queue[Math.floor(Math.random()*queue.length)]:queue[(idx+1)%queue.length];if(id==null)id=tracks[0].id;playTrack(id)}
function previous(){if(S.position>3){S.position=0;if(HAS_NATIVE)nativeCommand('seek',0);else if(browserAudio)browserAudio.currentTime=0;syncPlaybackUI();return}const queue=S.activeQueue.filter(x=>getTrack(x));let idx=queue.findIndex(x=>String(x)===String(S.track)),id=queue[(idx-1+queue.length)%queue.length]??tracks[0]?.id;if(id!=null)playTrack(id)}
function addToPlaylist(pid){let c=S.custom.find(c=>c.id===pid);if(!c)return toast('Choose a playlist');const id=S.selectedTarget??S.track;if(!c.songIds.some(x=>String(x)===String(id)))c.songIds.push(id);S.sheet=null;persist();render();toast(`Added to ${c.name}`)}
function action(el,event){let a=el.dataset.act,id=el.dataset.id,value=el.dataset.value;
 if(a==='dismiss'){if(event&&event.target.closest('[data-no-dismiss]')&&event.target===el)return;S.sheet=null;S.modal=null;render();return}
 switch(a){
 case 'impSource':IMP.source=value;IMP.error='';IMP.items=[];render();break;
 case 'impAdvanced':IMP.advanced=!IMP.advanced;render();break;
 case 'importPaste':navigator.clipboard?.readText().then(x=>{IMP.url=x||'';render()}).catch(()=>toast('Paste your link manually'));break;
 case 'analyzeImport':impAnalyze();break;
 case 'importPlaylistFile':document.querySelector('#playlist-import-file')?.click();break;
 case 'impUnmatched':IMP.hideUnmatched=!IMP.hideUnmatched;render();break;
 case 'impSavePlaylist':impSave();break;
 case 'impReset':IMP.items=[];IMP.error='';IMP.notice='';IMP.title='';render();break;
 case 'impResolve':S.resolveInfo={id,index:Number(el.dataset.index)};open('resolve');break;
 case 'impPickMatch':{let c=S.custom.find(c=>c.id===S.resolveInfo?.id);if(!c)break;let i=S.resolveInfo.index;c.importedMissing.splice(i,1);if(!c.songIds.some(x=>String(x)===String(id)))c.songIds.push(String(id));S.screen='detail';S.detail=c.id;S.screenStack=[];persist();render();toast('Track linked');break;}
 case 'impRemoveMissing':{let c=S.custom.find(c=>c.id===S.resolveInfo?.id);if(!c)break;c.importedMissing.splice(S.resolveInfo.index,1);S.screen='detail';S.detail=c.id;S.screenStack=[];persist();render();toast('Entry removed');break;}
 case 'downloadProvider':DL.provider=value;DL.url='';DL.error='';DL.items=[];DL.selected.clear();DL.format=value==='spotify'?'ogg':'best';render();break;
 case 'spotifyConnect':if(typeof MotifAndroid!=='undefined'&&typeof MotifAndroid.connectSpotify==='function'){DL.busy=true;DL.error='';render();MotifAndroid.connectSpotify()}else{DL.error='Spotify engine requires the experimental native Android build.';render()}break;
 case 'downloadInspect':scrapeInspect();break;
 case 'downloadQueue':scrapeQueueSelected();break;
 case 'downloadToggle':{const i=Number(el.dataset.index);if(DL.selected.has(i))DL.selected.delete(i);else DL.selected.add(i);render();break;}
 case 'downloadAll':DL.selected=new Set(DL.items.map((_,i)=>i));render();break;
 case 'downloadNone':DL.selected.clear();render();break;
 case 'downloadCancel':{const job=DL.jobs.find(j=>String(j.id)===String(el.dataset.id));if(job?.provider==='spotify'&&typeof MotifAndroid!=='undefined'&&typeof MotifAndroid.cancelSpotify==='function')MotifAndroid.cancelSpotify(String(el.dataset.id));else if(typeof MotifAndroid!=='undefined'&&typeof MotifAndroid.cancelYouTube==='function')MotifAndroid.cancelYouTube(Number(el.dataset.id));break;}
 case 'downloadRemove':DL.jobs=DL.jobs.filter(j=>String(j.id)!==String(el.dataset.id));render();break;
 case 'downloadOpenSettings':DL.showOptions=!DL.showOptions;render();break;
 case 'tab':transitionIntent='tab';S.screenStack=[];S.screen=value;S.tab=value;S.viewPlayer=false;S.aux=null;S.sheet=null;render();break;
 case 'back':back();break;
 case 'settings':open('settings');break;
 case 'profile':open('profile');break;
 case 'accounts':open('accounts');break;
 case 'storage':open('storage');break;
 case 'rescan':requestMusicScan();break;
 case 'importMusic':HAS_NATIVE?nativeCommand('importAudio'):$('#music-import-input')?.click();break;
 case 'collection':open('detail',id);break;
 case 'homeFilter':S.homeFilter=value;render();break;
 case 'libFilter':S.libFilter=value;S.sort='Recently added';render();break;
 case 'viewTracks':transitionIntent='tab';S.screen='library';S.tab='library';S.libFilter='Tracks';S.viewPlayer=false;S.screenStack=[];render();break;
 case 'viewPlaylists':transitionIntent='tab';S.screen='library';S.tab='library';S.libFilter='Playlists';S.screenStack=[];render();break;
 case 'libSearch':transitionIntent='tab';S.screen='search';S.tab='search';S.search='';render();setTimeout(()=>$('#search-input')?.focus(),50);break;
 case 'clearSearch':S.search='';S.searchFilter='All';render();$('#search-input')?.focus();break;
 case 'searchFilter':S.searchFilter=value;$('#search-results').innerHTML=searchResults();break;
 case 'sort':S.sheet={type:'sort'};render();break;
 case 'selectSort':S.sort=value;S.sheet=null;render();break;
 case 'viewToggle':S.libGrid=!S.libGrid;render();break;
 case 'playTrack':playTrack(id);break;
 case 'playCollection':{let c=cById(id),ids=c.id==='liked'?[...S.liked]:c.songIds;if(ids.length){S.activeQueue=[...ids];playTrack(ids[0])}else toast('Playlist is empty');break}
 case 'expandPlayer':S.viewPlayer=true;render();break;
 case 'collapsePlayer':S.viewPlayer=false;render();break;
 case 'togglePlay':toggleRealPlayback();break;
 case 'previous':previous();break;
 case 'next':next();break;
 case 'toggleShuffle':S.shuffle=!S.shuffle;nativeCommand('setShuffle',S.shuffle);render();toast(S.shuffle?'Shuffle on':'Shuffle off');break;
 case 'repeat':S.repeat=(S.repeat+1)%3;nativeCommand('setRepeat',S.repeat);render();toast(['Repeat off','Repeat all','Repeat one'][S.repeat]);break;
 case 'like':{let i=String(id);S.liked.has(i)?S.liked.delete(i):S.liked.add(i);persist();render();toast(S.liked.has(i)?'Added to Liked Songs':'Removed from Liked Songs');break}
 case 'menuTrack':S.sheet={type:'track',id};S.selectedTarget=id;render();break;
 case 'menuCollection':S.sheet={type:'collection',id};render();break;
 case 'addTo':S.sheet={type:'target',id};S.selectedTarget=id||S.track;render();break;
 case 'targetAdd':addToPlaylist(id);break;
 case 'queueAdd':S.activeQueue.push(id);syncNativeQueue();S.sheet=null;render();toast('Added to queue');break;
 case 'removeQueue':S.activeQueue.splice(Number(el.dataset.index),1);syncNativeQueue();render();break;
 case 'moveQueue':{let i=Number(el.dataset.index),j=(i+1)%S.activeQueue.length;[S.activeQueue[i],S.activeQueue[j]]=[S.activeQueue[j],S.activeQueue[i]];syncNativeQueue();render();break}
 case 'queue':S.aux='queue';render();break;
 case 'lyrics':S.aux='lyrics';render();break;
 case 'auxBack':S.aux=null;render();break;
 case 'importLyrics':$('#lyrics-file-input')?.click();break;
 case 'setting':S.opts[id]=!S.opts[id];persist();render();break;
 case 'create':{S.sheet=null;S.editorDraft={name:'',desc:'',art:'nightdrive',coverData:null,songIds:S.selectedTarget!=null?[S.selectedTarget]:[]};S.selectedTarget=null;open('playlistEditor');break}
 case 'editPlaylist':{S.sheet=null;const c=S.custom.find(c=>c.id===id);if(!c)return;S.editorDraft={...c,songIds:[...c.songIds]};open('playlistEditor');break}
 case 'coverPick':S.editorDraft.art=value;S.editorDraft.coverData=null;render();break;
 case 'choosePlaylistImage':$('#playlist-file-input')?.click();break;
 case 'savePlaylist':{const d=S.editorDraft||{},name=(d.name||'').trim();if(!name){toast('Enter a playlist name');$('#playlist-name')?.focus();return}if(d.id){let c=S.custom.find(x=>x.id===d.id);if(c)Object.assign(c,{name,desc:d.desc||'',art:d.art,coverData:d.coverData})}else{let c={id:'custom'+Date.now(),type:'Playlist',name,desc:d.desc||'',art:d.art||'nightdrive',coverData:d.coverData||null,songIds:d.songIds||[]};S.custom.unshift(c);S.detail=c.id}S.screen='detail';S.tab='library';S.screenStack=[];S.editorDraft=null;persist();render();toast('Playlist saved');break}
 case 'deletePlaylist':S.sheet=null;S.deleteTarget=id||S.editorDraft?.id;S.modal='confirmDelete';render();break;
 case 'confirmDelete':{S.custom=S.custom.filter(c=>c.id!==S.deleteTarget);S.modal=null;S.screen='library';S.libFilter='Playlists';S.tab='library';S.screenStack=[];S.editorDraft=null;persist();render();toast('Playlist deleted');break}
 case 'addTracks':S.detail=id;open('addTracks');break;
 case 'togglePlaylistTrack':{let c=S.custom.find(c=>c.id===S.detail);if(!c)return;if(c.songIds.includes(id))c.songIds=c.songIds.filter(x=>x!==id);else c.songIds.push(id);persist();render();break}
 case 'newAccount':S.profileDraft={name:'',handle:'',avatar:'sunset',image:null};S.screenStack.push({screen:S.screen,detail:S.detail});S.screen='profileEditor';render();break;
 case 'editProfile':S.profileDraft={...account()};open('profileEditor');break;
 case 'avatarPick':S.profileDraft.avatar=value;S.profileDraft.image=null;render();break;
 case 'chooseAvatarImage':$('#avatar-file-input')?.click();break;
 case 'saveProfile':{const d=S.profileDraft,name=(d.name||'').trim(),handle=(d.handle||'').trim().replace(/^@/,'').replace(/\s+/g,'').toLowerCase();if(!name||!handle){toast('Name and username are required');return}if(S.accounts.some(x=>x.id!==d.id&&x.handle===handle)){toast('Username already in use');return}if(d.id){Object.assign(account(),{name,handle,avatar:d.avatar,image:d.image})}else{const id='p'+Date.now();S.accounts.push({id,name,handle,avatar:d.avatar,image:d.image,liked:[],custom:[]});S.accountId=id;S.liked=new Set();S.custom=[]}S.profileDraft=null;S.screen='home';S.tab='home';S.screenStack=[];persist();render();if(HAS_NATIVE)setTimeout(requestMusicScan,400);toast('Profile saved');break}
 case 'switchAccount':{if(id===S.accountId){open('profile');break}persist();S.accountId=id;let a=account();S.liked=new Set((a.liked||[]).map(String));S.custom=a.custom||[];S.screen='home';S.tab='home';S.screenStack=[];persist();render();toast(`Switched to ${a.name}`);break}
 case 'removeAccount':S.modal='confirmRemoveAccount';render();break;
 case 'confirmRemoveAccount':{if(S.accounts.length<=1)return;S.accounts=S.accounts.filter(a=>a.id!==S.accountId);S.accountId=S.accounts[0].id;S.liked=new Set((account().liked||[]).map(String));S.custom=account().custom||[];S.screen='home';S.tab='home';S.screenStack=[];S.modal=null;persist();render();toast('Account removed');break}
 case 'toast':toast(value);break;
 }
}
document.addEventListener('click',e=>{let el=e.target.closest('[data-act]');if(!el)return;if(el.dataset.act==='dismiss'&&e.target.closest('[data-no-dismiss]')&&el.classList.contains('sheet-overlay')||el.dataset.act==='dismiss'&&e.target.closest('[data-no-dismiss]')&&el.classList.contains('modal-overlay'))return;e.stopPropagation();action(el,e)});
document.addEventListener('input',e=>{
 if(e.target.id==='download-url')DL.url=e.target.value;
 if(e.target.id==='download-format')DL.format=e.target.value;
 if(e.target.id==='import-url'){IMP.url=e.target.value;const p=impProvider(IMP.url);if(p)IMP.source={'Spotify':'spotify','YouTube':'youtube','Apple Music':'apple'}[p];}
 if(e.target.id==='imp-youtube-key')IMP.keyYoutube=e.target.value;
 if(e.target.id==='imp-spotify-token')IMP.tokenSpotify=e.target.value;
 if(e.target.id==='imp-apple-token')IMP.tokenApple=e.target.value;
 if(e.target.id==='search-input'){S.search=e.target.value;S.searchFilter='All';$('#search-results').innerHTML=searchResults();const x=$('[data-act=clearSearch]');if(x)x.style.display=S.search?'':'none'}
 if(e.target.id==='seek-range'){S.position=Number(e.target.value);if(HAS_NATIVE)nativeCommand('seek',Math.round(S.position*1000));else if(browserAudio)browserAudio.currentTime=S.position;e.target.style.setProperty('--progress',`${S.position/getTrack(S.track).seconds*100}%`);let t=$('#current-time');if(t)t.textContent=format(S.position)}
 if(e.target.id==='playlist-name'&&S.editorDraft)S.editorDraft.name=e.target.value;
 if(e.target.id==='playlist-desc'&&S.editorDraft)S.editorDraft.desc=e.target.value;
 if(e.target.id==='profile-name'&&S.profileDraft)S.profileDraft.name=e.target.value;
 if(e.target.id==='profile-handle'&&S.profileDraft)S.profileDraft.handle=e.target.value;
});
async function imageFromFile(file){if(!file||!file.type.startsWith('image/')){toast('Select an image');return null}if(file.size>8*1024*1024){toast('Please select an image under 8 MB');return null}return new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>{let im=new Image();im.onload=()=>{const c=document.createElement('canvas'),size=450;c.width=c.height=size;const z=Math.min(im.width,im.height),sx=(im.width-z)/2,sy=(im.height-z)/2;c.getContext('2d').drawImage(im,sx,sy,z,z,0,0,size,size);resolve(c.toDataURL('image/jpeg',.75))};im.onerror=()=>resolve(null);im.src=reader.result};reader.onerror=()=>resolve(null);reader.readAsDataURL(file)})}
document.addEventListener('change',async e=>{
 if(e.target.id==='playlist-import-file'){await impReadFile(e.target.files?.[0]);e.target.value=''}
 if(e.target.id==='music-import-input'){await importMusicFiles(e.target.files||[]);e.target.value=''}
 if(e.target.id==='playlist-file-input'){let image=await imageFromFile(e.target.files?.[0]);if(image&&S.editorDraft){S.editorDraft.coverData=image;render()}}
 if(e.target.id==='avatar-file-input'){let image=await imageFromFile(e.target.files?.[0]);if(image&&S.profileDraft){S.profileDraft.image=image;render()}}
 if(e.target.id==='lyrics-file-input'){let f=e.target.files?.[0];if(f){S.lyrics[S.track]=(await f.text()).slice(0,45000);persist();render();toast('Lyrics imported')}e.target.value=''}
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'||e.key==='Backspace'&&e.target.tagName!=='INPUT'){if(S.sheet||S.modal||S.aux||S.viewPlayer||S.screen!=='home'){e.preventDefault();back()}}if(e.key==='Enter'&&e.target.id==='new-name'){action({dataset:{act:'savePlaylist'}})}});
// Natural, velocity-aware swipe-to-dismiss on header / artwork only; seek and
// controls keep normal native behavior. Motion is transform-only while dragging.
let playerGesture=null;
document.addEventListener('pointerdown',e=>{
 if(!S.viewPlayer||S.aux||!S.opts.motion||!e.isPrimary)return;
 if(!e.target.closest('.player-header,.player-art'))return;
 if(e.target.closest('button'))return;
 const panel=e.target.closest('.player-view:not(.auxiliary-view)');if(!panel)return;
 playerGesture={panel,id:e.pointerId,y:e.clientY,x:e.clientX,started:performance.now(),drag:0};
});
document.addEventListener('pointermove',e=>{
 const g=playerGesture;if(!g||e.pointerId!==g.id)return;
 const dy=e.clientY-g.y,dx=e.clientX-g.x;
 if(dy>4&&dy>Math.abs(dx)*1.3){g.drag=dy;g.panel.style.transition='none';g.panel.style.transform=`translate3d(0,${dy}px,0)`;g.panel.style.borderRadius=`${Math.min(24,dy/15)}px ${Math.min(24,dy/15)}px 0 0`;}
});
function endPlayerGesture(e){const g=playerGesture;if(!g||e.pointerId!==g.id)return;playerGesture=null;
 const velocity=g.drag/Math.max(1,performance.now()-g.started);
 if(g.drag>Math.min(130,window.innerHeight*.22)||g.drag>55&&velocity>.55){
  g.panel.style.transform='';g.panel.style.transition='';g.panel.style.borderRadius='';S.viewPlayer=false;render();
 }else if(g.drag>0){
  g.panel.style.transition='transform 290ms cubic-bezier(.2,.9,.2,1),border-radius 290ms ease';
  g.panel.style.transform='translate3d(0,0,0)';g.panel.style.borderRadius='0';
  window.setTimeout(()=>{if(g.panel.isConnected){g.panel.style.transition='';g.panel.style.transform='';g.panel.style.borderRadius='';}},300);
 }
}
document.addEventListener('pointerup',endPlayerGesture);document.addEventListener('pointercancel',endPlayerGesture);
window.addEventListener('popstate',back);
// Content access is requested by the user; no tracking or network access.
async function requestMusicScan(){if(HAS_NATIVE){nativeCommand('requestLibrary');return}await loadBrowserLibrary()}
window.motifPermissionDenied=()=>{libraryLoaded=true;render();toast('Allow music access in Android settings, or add files directly.')};
window.motifNativeError=msg=>toast(String(msg).slice(0,100));
document.addEventListener('error',e=>{if(e.target.tagName==='IMG'&&e.target.src?.startsWith('content:')){e.target.onerror=null;e.target.src=FALLBACK_ART}},true);
window.motifLibraryReceived=(json)=>{try{const data=typeof json==='string'?JSON.parse(json):json;tracks=(data.tracks||[]).map(t=>({...t,id:String(t.id),seconds:Math.max(1,Math.floor(t.seconds||0)),bytes:Number(t.bytes)||0}));nativeStats={totalBytes:data.totalBytes||0,freeBytes:data.freeBytes||0};libraryLoaded=true;/* Preserve favorites if storage is temporarily unavailable. *//* Preserve playlist references if storage is temporarily unavailable. */if(!getTrack(S.track))S.track=tracks[0]?.id??null;S.activeQueue=S.activeQueue.filter(id=>getTrack(id));if(!S.activeQueue.length)S.activeQueue=tracks.map(t=>t.id);persist();render();}catch(e){console.error('Library scan error',e);toast('Could not load music library')}};
window.motifPlaybackReceived=(json)=>{
 try{
  const st=typeof json==='string'?JSON.parse(json):json;
  const prior=S.track;
  if(st.id!=null&&getTrack(st.id))S.track=String(st.id);
  S.playing=!!st.playing;if(st.id!=null)S.hasPlayed=true;S.position=Math.max(0,(st.position||0)/1000);
  if(st.duration>0){const t=getTrack(S.track);if(t)t.seconds=Math.round(st.duration/1000)}
  if(prior!==S.track){render();return}
  syncPlaybackUI();
  const p=$('.player-controls .main-play');if(p){p.innerHTML=I(S.playing?'pause':'play','lg');p.setAttribute('aria-label',S.playing?'Pause':'Play')}
  const m=$('.mini-player [data-act=togglePlay]');if(m)m.innerHTML=I(S.playing?'pause':'play');
 }catch(e){console.error('Playback state',e)}
};
const DB_NAME='motif-audio-v1';
function openMediaDB(){return new Promise((resolve,reject)=>{const q=indexedDB.open(DB_NAME,1);q.onupgradeneeded=()=>{q.result.createObjectStore('audio',{keyPath:'id'})};q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)})}
function dbTx(db,mode,fn){return new Promise((resolve,reject)=>{const tx=db.transaction('audio',mode),store=tx.objectStore('audio');let req=fn(store);tx.oncomplete=()=>resolve(req.result);tx.onerror=()=>reject(tx.error)})}
async function loadBrowserLibrary(){if(!mediaDb)mediaDb=await openMediaDB();const rec=await dbTx(mediaDb,'readonly',s=>s.getAll());tracks.forEach(t=>{if(t.url?.startsWith('blob:'))URL.revokeObjectURL(t.url);if(t.cover?.startsWith('blob:'))URL.revokeObjectURL(t.cover)});tracks=rec.map(x=>({...x,id:String(x.id),url:URL.createObjectURL(x.blob),cover:x.coverBlob?URL.createObjectURL(x.coverBlob):FALLBACK_ART}));libraryLoaded=true;nativeStats.freeBytes=0;try{const e=await navigator.storage?.estimate();nativeStats.freeBytes=Math.max(0,(e?.quota||0)-(e?.usage||0))}catch{}if(!getTrack(S.track))S.track=tracks[0]?.id??null;S.activeQueue=tracks.map(t=>t.id);render()}
async function audioTags(file){
 const tags={};
 try{
  const bytes=new Uint8Array(await file.slice(0,Math.min(file.size,1024*1024)).arrayBuffer());
  if(bytes.length<10||String.fromCharCode(...bytes.slice(0,3))!=='ID3')return tags;
  const version=bytes[3],sync=(o)=>(bytes[o]<<21)|(bytes[o+1]<<14)|(bytes[o+2]<<7)|bytes[o+3];
  if(version!==3&&version!==4)return tags;
  const max=Math.min(bytes.length,10+sync(6));let off=10;
  const decode=(frame)=>{
   const enc=frame[0];const raw=frame.slice(1);let text='';
   if(enc===0)text=new TextDecoder('iso-8859-1').decode(raw);
   else if(enc===3)text=new TextDecoder().decode(raw);
   else if(enc===1){const be=raw[0]===0xfe&&raw[1]===0xff;text=new TextDecoder(be?'utf-16be':'utf-16le').decode(raw[0]===0xff&&raw[1]===0xfe||be?raw.slice(2):raw)}
   else text=new TextDecoder('utf-16be').decode(raw);
   return text.replace(/\u0000/g,'').trim();
  };
  while(off+10<=max){
   const frameId=String.fromCharCode(...bytes.slice(off,off+4));
   if(!/^[A-Z0-9]{4}$/.test(frameId))break;
   const len=version===4?sync(off+4):((bytes[off+4]<<24)>>>0)+(bytes[off+5]<<16)+(bytes[off+6]<<8)+bytes[off+7];
   off+=10;if(len<=0||off+len>max)break;
   const value=bytes.slice(off,off+len);
   if(frameId==='TIT2')tags.title=decode(value);
   if(frameId==='TPE1')tags.artist=decode(value);
   if(frameId==='TALB')tags.album=decode(value);
   if(frameId==='TLEN')tags.seconds=Math.round(Number(decode(value))/1000)||0;
   if(frameId==='APIC'&&len<700000){
    let at=-1,mime='image/jpeg';
    for(let i=0;i<value.length-3;i++){
     if(value[i]===0xff&&value[i+1]===0xd8&&value[i+2]===0xff){at=i;mime='image/jpeg';break}
     if(value[i]===0x89&&value[i+1]===0x50&&value[i+2]===0x4e&&value[i+3]===0x47){at=i;mime='image/png';break}
    }
    if(at>0)tags.coverBlob=new Blob([value.slice(at)],{type:mime});
   }
   off+=len;
  }
 }catch(e){console.warn('Metadata read',e)}
 return tags;
}
async function importMusicFiles(fileList){
 if(!mediaDb)mediaDb=await openMediaDB();let ok=0;
 for(const f of [...fileList]){
  if(!f.type.startsWith('audio/')&&!/\.(mp3|m4a|aac|ogg|opus|flac|wav|webm)$/i.test(f.name))continue;
  const name=f.name.replace(/\.[^.]+$/,'').replace(/_/g,' '),tags=await audioTags(f);
  const id='file-'+Date.now()+'-'+Math.random().toString(36).slice(2,8);
  const rec={id,title:tags.title||name,artist:tags.artist||'Unknown artist',album:tags.album||'Unknown album',seconds:tags.seconds||0,bytes:f.size,dateAdded:Date.now(),blob:f,coverBlob:tags.coverBlob||null};
  try{await dbTx(mediaDb,'readwrite',s=>s.put(rec));ok++}catch(e){toast('Browser storage full');break}
 }
 await loadBrowserLibrary();toast(ok?`Imported ${ok} track${ok===1?'':'s'}`:'No supported audio files');
}
/* Motif — provider playlist and catalog import. No streaming audio ripping.
 * Tokens are retained only in RAM for the current session. */
icons.import='<path d="M12 3v12m-4-4 4 4 4-4"/><path d="M4 16v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4"/>';
icons.importSolid='<path d="M12 3a1.2 1.2 0 0 1 1.2 1.2v9.3l2-2a1.2 1.2 0 0 1 1.7 1.7l-4 4a1.2 1.2 0 0 1-1.7 0l-4-4a1.2 1.2 0 0 1 1.7-1.7l1.9 2V4.2A1.2 1.2 0 0 1 12 3Z" fill="currentColor" stroke="none"/><path d="M4 18v2a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2"/>';
icons.link='<path d="M10.5 13.5a5 5 0 0 0 7.2 0l2.4-2.4a5 5 0 0 0-7.1-7.1l-1.4 1.4"/><path d="M13.5 10.5a5 5 0 0 0-7.2 0l-2.4 2.4a5 5 0 0 0 7.1 7.1l1.4-1.4"/>';
icons.filetext='<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h8"/>';
icons.alert='<path d="m12 2 10 19H2L12 2Z"/><path d="M12 9v5m0 3h.01"/>';
icons.external='<path d="M13 4h7v7m0-7-9 9"/><path d="M19 13v6H5V5h6"/>';
const IMP={url:'',source:'auto',busy:false,advanced:false,provider:'',keyYoutube:'',tokenSpotify:'',tokenApple:'',error:'',notice:'',title:'',image:'',items:[],sourceLink:'',format:'',hideUnmatched:false};
const IMPORT_MAX=1000;
function impProvider(url){try{let u=new URL(url),h=u.hostname.toLowerCase();if(/(^|\.)spotify\.com$|(^|\.)spotify\.link$/.test(h))return 'Spotify';if(/(^|\.)(youtube\.com|youtu\.be)$/.test(h))return 'YouTube';if(/(^|\.)(apple\.com)$/.test(h))return 'Apple Music';return ''}catch{return ''}}
function cleanName(x){return String(x||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\((?:feat|ft|with)[^)]*\)/g,'').replace(/\[(?:feat|ft|with)[^\]]*\]/g,'').replace(/\b(?:official music video|official video|official audio|lyrics video|visualizer)\b/g,'').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ')}
function impMatch(rec){const title=cleanName(rec.title),artist=cleanName(rec.artist);if(!title)return null;let matches=tracks.filter(t=>cleanName(t.title)===title);if(matches.length===1 && (!artist||artist==='unknown artist'||cleanName(matches[0].artist)===artist||artist.includes(cleanName(matches[0].artist))))return matches[0];const exact=matches.filter(t=>artist && (cleanName(t.artist)===artist||artist.includes(cleanName(t.artist))||cleanName(t.artist).includes(artist)));return exact.length===1?exact[0]:null}
function impNormalize(x){return {title:String(x.title||x.name||'Untitled').trim().slice(0,230),artist:String(x.artist||'').trim().slice(0,180),album:String(x.album||'').trim().slice(0,180),url:String(x.url||'').slice(0,600),duration:Number(x.duration)||0}}
function impSelect(source,title,items,notice='',image=''){IMP.provider=source;IMP.title=String(title||`${source} collection`).slice(0,150);IMP.items=items.slice(0,IMPORT_MAX).map(impNormalize);IMP.notice=notice;IMP.image=image;IMP.error='';IMP.busy=false;render()}
function impCard(n,desc,cls,icon){return `<button class="import-source ${IMP.source===cls?'chosen':''}" data-act="impSource" data-value="${cls}"><span class="import-brand ${cls}">${icon}</span><strong>${n}</strong><small>${desc}</small></button>`}
function importPage(){const isReview=!!IMP.items.length;const matches=IMP.items.filter(r=>impMatch(r)).length;const display=IMP.hideUnmatched?IMP.items.filter(x=>impMatch(x)):IMP.items;
 return `<div class="screen import-screen"><div class="import-glow"></div><div class="import-top"><div><div class="import-eyebrow">MOTIF / COLLECTIONS</div><h1>Import</h1></div><button class="icon-button" data-act="profile" aria-label="Profile">${profileAvatar(account(),'small')}</button></div><div class="import-intro">Bring your playlists together.</div>
 <div class="import-sources">${impCard('Spotify','Tracks & playlists','spotify','<span class="spotify-symbol">≋</span>')}${impCard('YouTube','Videos & playlists','youtube','<span class="youtube-symbol">▶</span>')}${impCard('Apple Music','Songs & albums','apple','<span class="apple-symbol">♫</span>')}</div>
 <div class="import-section-title">Import from a link</div><div class="import-urlbox">${I('link','sm')}<input id="import-url" type="url" autocomplete="off" spellcheck="false" placeholder="Paste a music or playlist link" value="${esc(IMP.url)}" ${IMP.busy?'disabled':''}><button data-act="importPaste" aria-label="Paste from clipboard">${I('plus','sm')}</button></div>
 <button class="import-submit" data-act="analyzeImport" ${IMP.busy?'disabled':''}>${IMP.busy?`<span class="import-spinner"></span> Reading collection...`:`${I('arrowRight','sm')} Preview collection`}</button>
 <button class="import-advanced" data-act="impAdvanced">${I('sliders','sm')} Provider connections ${I('chevronDown','sm')}</button>${IMP.advanced?`<div class="import-options"><label>YouTube Data API key<input type="password" autocomplete="off" id="imp-youtube-key" placeholder="Optional API key" value="${esc(IMP.keyYoutube)}"></label><label>Spotify OAuth access token<input type="password" autocomplete="off" id="imp-spotify-token" placeholder="For your playlists" value="${esc(IMP.tokenSpotify)}"></label><label>Apple Music developer token<input type="password" autocomplete="off" id="imp-apple-token" placeholder="Optional catalog access" value="${esc(IMP.tokenApple)}"></label><p>Credentials stay in app memory for this session and are sent only to the selected provider API. Spotify currently limits playlist contents to playlists you own or collaborate on.</p></div>`:''}
 ${IMP.error?`<div class="imp-banner imp-error">${I('alert','sm')} <span>${esc(IMP.error)}</span></div>`:''}${IMP.notice?`<div class="imp-banner imp-note">${I('info','sm')} <span>${esc(IMP.notice)}</span></div>`:''}
 <div class="import-file"><div class="import-file-icon">${I('filetext')}</div><div><strong>Import a playlist file</strong><p>CSV, M3U, M3U8 or JSON exports</p></div><button class="import-file-action" data-act="importPlaylistFile">Browse</button></div>
 ${isReview?`<div class="import-preview"><div class="import-preview-head"><div class="import-result-title">${esc(IMP.title)}</div><div class="import-result-caption">${esc(IMP.provider)} · ${IMP.items.length} entries · ${matches} matched to your music</div></div><div class="import-progress"><span style="width:${IMP.items.length?matches/IMP.items.length*100:0}%"></span></div><div class="import-options-row"><span>Review tracks</span><button data-act="impUnmatched">${IMP.hideUnmatched?'Show all':'Matched only'}</button></div><div class="import-tracklist">${display.slice(0,150).map((r,i)=>{let t=impMatch(r);return `<div class="import-track"><div class="import-trackicon">${I(t?'check':'music','sm')}</div><div class="import-trackcopy"><strong>${esc(r.title)}</strong><small>${esc(r.artist||r.album||IMP.provider)}</small></div><span class="import-match ${t?'yes':'no'}">${t?'Matched':'Missing'}</span></div>`}).join('')}${display.length>150?`<div class="import-truncated">Showing first 150 of ${display.length} entries</div>`:''}</div><div class="import-results-foot"><button class="import-reset" data-act="impReset">Clear</button><button class="import-save" data-act="impSavePlaylist">${I('plus','sm')} Create playlist</button></div><p class="import-footnote">Unavailable tracks remain in the playlist as unplayable entries until matched to music on your device. Nothing is downloaded from streaming services.</p></div>`:''}
 <div class="import-foot"><strong>Made for your music.</strong><p>Import playlist information from supported services, then match it with tracks in your library. Audio stays under your control.</p></div></div>`}
function csvRows(src){let rows=[],row=[],cur='',quoted=false;for(let i=0;i<src.length;i++){const ch=src[i];if(ch==='"'){if(quoted&&src[i+1]==='"'){cur+='"';i++}else quoted=!quoted}else if(ch===','&&!quoted){row.push(cur);cur=''}else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&src[i+1]==='\n')i++;row.push(cur);if(row.some(s=>s.trim()))rows.push(row);row=[];cur=''}else cur+=ch}row.push(cur);if(row.some(s=>s.trim()))rows.push(row);return rows}
function impParseFile(file,src){let suffix=file.name.split('.').pop().toLowerCase(),items=[];if(suffix==='csv'){
 const rows=csvRows(src.replace(/^\uFEFF/,''));if(rows.length<2)throw Error('This CSV has no tracks.');const keys=rows[0].map(s=>s.toLowerCase().replace(/[^a-z0-9]/g,''));const get=(r,names)=>{for(const n of names){let i=keys.indexOf(n);if(i>=0&&r[i])return r[i]}return ''};
 items=rows.slice(1).filter(r=>r.some(x=>x.trim())).map(r=>({title:get(r,['trackname','tracktitle','songname','title','name']),artist:get(r,['artistnames','artistname','artists','artist']),album:get(r,['albumname','album']),url:get(r,['trackurl','url','spotifyuri','uri'])})).filter(x=>x.title);
 }else if(suffix==='m3u'||suffix==='m3u8'){
 let hint='';for(const raw of src.split(/\r?\n/)){let line=raw.trim();if(!line)continue;if(line.startsWith('#EXTINF:')){hint=line.slice(line.indexOf(',')+1).trim();continue}if(line.startsWith('#'))continue;let name=hint||decodeURIComponent(line.split(/[\\/]/).pop()||'').replace(/\.[^.]+$/,'');let parts=name.split(/\s+-\s+/);items.push({title:parts.length>1?parts.slice(1).join(' - '):name,artist:parts.length>1?parts[0]:''});hint=''}
 }else if(suffix==='json'){
 const obj=JSON.parse(src);let vals=Array.isArray(obj)?obj:obj.tracks||obj.items||obj.playlist?.tracks||[];if(!Array.isArray(vals))throw Error('Unsupported JSON playlist structure');items=vals.map(x=>{const t=x.track||x.item||x;return {title:t.title||t.name,artist:typeof t.artist==='string'?t.artist:Array.isArray(t.artists)?t.artists.map(y=>y.name||y).join(', '):'',album:typeof t.album==='string'?t.album:t.album?.name||'',url:t.url||t.external_urls?.spotify||''}}).filter(x=>x.title)
 }else throw Error('Choose a CSV, M3U, M3U8, or JSON file.');if(!items.length)throw Error('No track names found in this file.');return items.slice(0,IMPORT_MAX)}
async function impReadFile(file){if(!file)return;try{if(file.size>5*1024*1024)throw Error('Playlist files must be smaller than 5 MB.');const rows=impParseFile(file,await file.text());IMP.source='file';IMP.url='';IMP.sourceLink='';impSelect('Playlist file',file.name.replace(/\.[^.]+$/,''),rows,`${rows.length} track references imported. Files are matched by title and artist.`)}catch(e){IMP.error=e.message||'Could not open playlist file';IMP.busy=false;render()}}
async function impFetch(url,opts={}){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),16000);try{const r=await fetch(url,{...opts,signal:controller.signal});if(!r.ok)throw Error(`Provider returned HTTP ${r.status}${r.status===401?' (token expired or missing)':''}${r.status===403?' (access restricted)':''}`);return await r.json()}finally{clearTimeout(timer)}}
function sourceEntries(json){return (json.data||json.items||[]).map(x=>x.item||x.track||x).filter(Boolean).map(x=>({title:x.name||x.attributes?.name||x.snippet?.title||'Untitled',artist:x.artists?.map(a=>a.name).join(', ')||x.attributes?.artistName||x.snippet?.videoOwnerChannelTitle||x.album?.artists?.[0]?.name||'',album:x.album?.name||x.attributes?.albumName||'',url:x.external_urls?.spotify||x.attributes?.url||'',duration:x.duration_ms?x.duration_ms/1000:x.attributes?.durationInMillis?x.attributes.durationInMillis/1000:0}))}
async function impSpotify(u){const kind=(u.pathname.match(/\/(track|playlist|album)\/([a-zA-Z0-9]+)/)||[]),type=kind[1],id=kind[2];if(!type||!id)throw Error('Paste a Spotify track, album, or playlist link.');const token=IMP.tokenSpotify.trim();if(!token){if(type!=='track')throw Error('Spotify playlist and album tracks require an access token. Use Provider connections, or import a CSV playlist export.');const x=await impFetch(`https://open.spotify.com/oembed?url=${encodeURIComponent(u.toString())}`);let s=(x.title||'').split(/\s*[–—-]\s*/);return impSelect('Spotify',s[0]||x.title,[{title:s[0]||x.title,artist:s.slice(1).join(' - '),url:u.toString()}],'Matched tracks can be added to a playlist. Spotify audio cannot be downloaded.',x.thumbnail_url||'')}
 const auth={Authorization:`Bearer ${token}`},base='https://api.spotify.com/v1';if(type==='track'){let t=await impFetch(`${base}/tracks/${encodeURIComponent(id)}`,{headers:auth});return impSelect('Spotify',t.name,sourceEntries({items:[t]}))}
 const info=await impFetch(`${base}/${type}s/${encodeURIComponent(id)}`,{headers:auth});let list=[];
 if(type==='album'){let next=`${base}/albums/${encodeURIComponent(id)}/tracks?limit=50`;while(next&&list.length<IMPORT_MAX){let z=await impFetch(next,{headers:auth});list.push(...sourceEntries(z).map(x=>({...x,artist:x.artist||info.artists?.map(a=>a.name).join(', '),album:info.name})));next=z.next}}
 else{let next=`${base}/playlists/${encodeURIComponent(id)}/items?limit=50`;while(next&&list.length<IMPORT_MAX){let z=await impFetch(next,{headers:auth});list.push(...sourceEntries(z));next=z.next}}
 if(!list.length)throw Error('No accessible tracks. Spotify only exposes playlist items to owners and collaborators under its current API rules.');return impSelect('Spotify',info.name,list,'Metadata only. Original Spotify audio cannot be copied.');}
async function impYoutube(u){const key=IMP.keyYoutube.trim(),id=u.searchParams.get('list'),vid=u.hostname.includes('youtu.be')?u.pathname.replace('/',''):u.searchParams.get('v');if(!key)throw Error('YouTube playlist and video metadata requires a YouTube Data API key. Add one under Provider connections.');let items=[],name='YouTube playlist';const base='https://www.googleapis.com/youtube/v3/';if(id){const obj=await impFetch(`${base}playlists?part=snippet&id=${encodeURIComponent(id)}&key=${encodeURIComponent(key)}`);name=obj.items?.[0]?.snippet?.title||name;let cursor='';do{const z=await impFetch(`${base}playlistItems?part=snippet&maxResults=50&playlistId=${encodeURIComponent(id)}&key=${encodeURIComponent(key)}${cursor?'&pageToken='+encodeURIComponent(cursor):''}`);items.push(...(z.items||[]).filter(x=>x.snippet?.resourceId?.videoId&&x.snippet?.title!=='Deleted video'&&x.snippet?.title!=='Private video').map(x=>({title:x.snippet.title,artist:x.snippet.videoOwnerChannelTitle||'',url:'https://www.youtube.com/watch?v='+x.snippet.resourceId.videoId})));cursor=z.nextPageToken||''}while(cursor&&items.length<IMPORT_MAX)}else if(vid){const z=await impFetch(`${base}videos?part=snippet&id=${encodeURIComponent(vid)}&key=${encodeURIComponent(key)}`),t=z.items?.[0];if(!t)throw Error('Video unavailable');name=t.snippet.title;items=[{title:t.snippet.title,artist:t.snippet.channelTitle,url:u.toString()}]}else throw Error('Paste a YouTube video or playlist link.');if(!items.length)throw Error('No accessible videos found.');impSelect('YouTube',name,items,'Video titles are matched to your music. YouTube video/audio is not downloaded.');}
async function impApple(u){let parts=u.pathname.match(/\/(album|song|playlist)\/[^/]*\/(pl\.[a-zA-Z0-9.-]+|\d+)/),type=parts?.[1],id=parts?.[2];if(!type){let m=u.pathname.match(/\/(pl\.[a-zA-Z0-9.-]+|\d+)/);id=m?.[1];type=id?.startsWith('pl.')?'playlist':'album'}if(!id)throw Error('Paste an Apple Music song, album, or playlist link.');if(type==='playlist'){
 if(!IMP.tokenApple.trim())throw Error('Apple Music playlists require an Apple Music API developer token. Add one under Provider connections.');let code=u.pathname.split('/').filter(Boolean)[0]||'us';if(!/^[a-z]{2}$/i.test(code))code='us';let base=`https://api.music.apple.com/v1/catalog/${code}/playlists/${encodeURIComponent(id)}`;const hdr={Authorization:'Bearer '+IMP.tokenApple.trim()};let info=await impFetch(base,{headers:hdr});let next=base+'/tracks?limit=100',all=[];while(next&&all.length<IMPORT_MAX){let z=await impFetch(next,{headers:hdr});all.push(...sourceEntries(z));next=z.next?(z.next.startsWith('https:')?z.next:'https://api.music.apple.com'+z.next):''}if(!all.length)throw Error('No tracks returned by Apple Music for that playlist.');return impSelect('Apple Music',info.data?.[0]?.attributes?.name||'Apple Music playlist',all)}
 const songId=u.searchParams.get('i')||id;const url=`https://itunes.apple.com/lookup?id=${encodeURIComponent(songId)}&entity=song&limit=200&country=us`;const z=await impFetch(url);let list=(z.results||[]).filter(x=>x.wrapperType==='track'&&x.kind==='song').map(x=>({title:x.trackName,artist:x.artistName,album:x.collectionName,url:x.trackViewUrl,duration:(x.trackTimeMillis||0)/1000}));if(!list.length)throw Error('No songs found in the iTunes catalog for that link.');impSelect('Apple Music',type==='song'?list[0].title:(z.results?.[0]?.collectionName||list[0].album),list,'Catalog information is imported. Audio remains in your music library.');}
async function impAnalyze(){const raw=(document.querySelector('#import-url')?.value||IMP.url).trim();IMP.url=raw;IMP.error='';IMP.notice='';IMP.items=[];IMP.title='';const provider=impProvider(raw);if(!provider){IMP.error='This link is not from Spotify, YouTube, or Apple Music.';render();return}IMP.busy=true;IMP.provider=provider;render();try{let u=new URL(raw);if(provider==='Spotify')await impSpotify(u);else if(provider==='YouTube')await impYoutube(u);else await impApple(u)}catch(e){IMP.busy=false;IMP.error=e.name==='AbortError'?'The provider did not respond in time.':String(e.message||e);render()}}
function impSave(){if(!IMP.items.length)return toast('Preview a playlist first');if(!S.accounts.length)return toast('Create a Motif profile first');let matched=[],missing=[],seen=new Set();for(const row of IMP.items){let t=impMatch(row);if(t){if(!seen.has(String(t.id))){matched.push(String(t.id));seen.add(String(t.id))}}else missing.push({...row,source:IMP.provider})}const c={id:'custom-import-'+Date.now(),type:'Playlist',name:IMP.title.slice(0,95)||'Imported playlist',desc:`Imported from ${IMP.provider}`,art:'focus',songIds:matched,importedMissing:missing};S.custom.unshift(c);S.detail=c.id;S.screen='detail';S.tab='library';S.screenStack=[];persist();render();toast(`${matched.length} matched · ${missing.length} need audio`)}
function pendingTrackRows(c){const rows=c.importedMissing||[];if(!rows.length)return '';return `<div class="missing-section"><div class="missing-heading">Needs music <span>${rows.length}</span></div><p>These tracks are listed in your playlist but can't play until you match a file.</p>${rows.map((r,i)=>`<button class="missing-row" data-act="impResolve" data-id="${c.id}" data-index="${i}"><span class="missing-glyph">${I('music','sm')}</span><span><strong>${esc(r.title)}</strong><small>${esc(r.artist||r.source||'Unknown artist')}</small></span><em>Match ${I('arrowRight','xs')}</em></button>`).join('')}</div>`}
function resolvePage(){const c=S.custom.find(x=>x.id===S.resolveInfo?.id),r=c?.importedMissing?.[S.resolveInfo?.index];if(!c||!r)return `<div class="screen"><button data-act="back">Back</button></div>`;let matches=tracks.filter(t=>cleanName(t.title).includes(cleanName(r.title))||cleanName(r.title).includes(cleanName(t.title)));return `<div class="screen resolve-screen"><div class="settings-header"><button class="icon-button" data-act="back">${I('arrowLeft')}</button><h1>Match track</h1></div><div class="resolve-target"><strong>${esc(r.title)}</strong><p>${esc(r.artist||'Unknown artist')} · ${esc(c.name)}</p></div><h2>${tracks.length?`Choose an audio file (${tracks.length})`:'No audio files yet'}</h2>${tracks.length?(matches.length?matches:tracks).map(t=>`<button class="resolve-row" data-act="impPickMatch" data-id="${esc(t.id)}"><img src="${trackArt(t)}" alt=""><span><strong>${esc(t.title)}</strong><small>${esc(t.artist)}</small></span>${I('plus','sm')}</button>`).join(''):`<p class="resolve-empty">Add music to your library, then return here to link it.</p><button class="import-submit" data-act="importMusic">Add music</button>`}<button class="resolve-remove" data-act="impRemoveMissing">Remove missing entry</button></div>`}

// When launched in an Android WebView, retrieve the real MediaStore catalog.
if(HAS_NATIVE){window.addEventListener('load',()=>{if(S.accounts.length)setTimeout(requestMusicScan,160)})}
else{window.addEventListener('load',()=>loadBrowserLibrary().catch(e=>{console.error(e);libraryLoaded=true;render()}))}
render();

/* Download providers. Spotify path is experimental and relies on embedded Python/librespot.
   No placeholder track metadata is fabricated; only native responses populate items. */
const DL={url:'',provider:'spotify',spotifyConnected:false,spotifyUsername:'',format:'ogg',busy:false,selected:new Set(),items:[],jobs:[],title:'',error:'',notice:'',showOptions:false};
function dlCleanUrl(raw,provider=DL.provider){try{const u=new URL(raw.trim());if(u.protocol!=='https:')return '';const h=u.hostname.toLowerCase();if(provider==='spotify'){const m=u.pathname.match(/\/(?:intl-[a-z]+\/)?(track|album|playlist)\/([a-zA-Z0-9]{22})(?:\/|$)/);return (h==='open.spotify.com'||h==='play.spotify.com')&&m?u.href:''}return /(^|\.)(youtube\.com|youtu\.be)$/.test(h)?u.href:''}catch{return ''}}
function downloadsPage(){
 const isSpotify=DL.provider==='spotify',canResolve=!!dlCleanUrl(DL.url);
 return `<div class="screen download-screen">
 <div class="download-header"><div><span class="download-eyebrow">MOTIF</span><h1>Downloads</h1><p>Get audio from the original source when supported.</p></div><button data-act="profile" class="icon-button">${profileAvatar(account(),'small')}</button></div>
 <div class="download-providers"><button data-act="downloadProvider" data-value="spotify" class="download-provider ${isSpotify?'selected':''}"><span class="provider-mark spotify">≋</span><div><strong>Spotify Premium</strong><small>Experimental on-device extractor</small></div><span class="${isSpotify?'provider-status':'provider-limited'}">${isSpotify?'Selected':'Choose'}</span></button><button data-act="downloadProvider" data-value="youtube" class="download-provider ${!isSpotify?'selected':''}"><span class="provider-mark youtube">▶</span><div><strong>YouTube</strong><small>Videos & playlists</small></div><span class="provider-status">${!isSpotify?'Selected':'Choose'}</span></button><div class="download-provider disabled" aria-disabled="true"><span class="provider-mark apple">♫</span><div><strong>Apple Music</strong><small>Not connected</small></div><span class="provider-limited">Later</span></div></div>
 ${isSpotify?`<div class="download-section spotify-connect-panel"><div class="download-result-heading"><div><span class="download-label">ACCOUNT</span><h2>${DL.spotifyConnected?'Spotify Premium connected':'Connect Spotify Premium'}</h2></div><span class="provider-status">320 kbps</span></div><p>Authenticate in your browser. Motif does not ask for your Spotify password.</p>${DL.spotifyConnected?`<div class="spotify-connected">${I('check','sm')} ${esc(DL.spotifyUsername||'Premium account ready')}</div>`:`<button class="download-primary" data-act="spotifyConnect" ${DL.busy?'disabled':''}>${DL.busy?'Opening Spotify login…':'Connect Spotify'}</button>`}</div>`:''}
 <div class="download-section"><div class="download-label">Paste a link</div><div class="download-url"><span>${I('link','sm')}</span><input id="download-url" placeholder="${isSpotify?'Spotify track, album or playlist URL':'YouTube video or playlist URL'}" autocomplete="off" spellcheck="false" type="url" value="${esc(DL.url)}"></div>
 <div class="download-quality"><div><strong>Audio quality</strong><small>${isSpotify?'Original Ogg Vorbis stream; no fake FLAC conversion':'Original available audio format'}</small></div>${isSpotify?`<span class="spotify-quality">Up to 320 kbps</span>`:`<select id="download-format"><option value="best" ${DL.format==='best'?'selected':''}>Best available</option><option value="m4a" ${DL.format==='m4a'?'selected':''}>M4A (AAC)</option><option value="webm" ${DL.format==='webm'?'selected':''}>WebM (Opus)</option></select>`}</div>
 <button data-act="downloadInspect" class="download-primary" ${DL.busy?'disabled':''}>${DL.busy?'<span class="download-wheel"></span> Inspecting source…':`${I('search','sm')} Inspect ${isSpotify?'Spotify':'YouTube'} link`}</button>
 <div class="download-smallprint">${isSpotify?'Experimental: an Android build with an embedded librespot runtime is required. Authentication and downloads are not verified on a device. Spotify may restrict playback or catalog access; your account could be affected. Lossless extraction is not available.':!canResolve&&DL.url?'Enter a valid YouTube or YouTube Music link.':'YouTube downloads retain the original available format and are saved into Music/Motif.'}</div></div>
 ${DL.error?`<div class="download-error">${I('alert','sm')} ${esc(DL.error)}</div>`:''}
 ${DL.items.length?`<div class="download-section download-found"><div class="download-result-heading"><div><span class="download-label">Found ${DL.items.length} tracks</span><h2>${esc(DL.title)}</h2></div><button data-act="downloadAll">Select all</button></div><div class="download-results">${DL.items.map((t,i)=>`<button class="download-result" data-act="downloadToggle" data-index="${i}"><span class="download-check ${DL.selected.has(i)?'active':''}">${DL.selected.has(i)?I('check','sm'):''}</span><div class="download-result-text"><strong>${esc(t.title)}</strong><small>${esc(t.artist)} ${t.seconds?'· '+format(t.seconds):''}</small></div></button>`).join('')}</div><button class="download-primary" data-act="downloadQueue" ${DL.selected.size?'':'disabled'}>${I('download','sm')} Download ${DL.selected.size} selected</button></div>`:''}
 <div class="download-section"><div class="download-result-heading"><h2>Download queue</h2>${DL.jobs.length?`<span class="download-count">${DL.jobs.length} items</span>`:''}</div>${DL.jobs.length?DL.jobs.map(j=>`<div class="download-job"><span class="download-job-icon">${I(j.status==='complete'?'check':j.status==='failed'?'alert':'music','sm')}</span><div class="download-job-info"><strong>${esc(j.title||'Audio track')}</strong><small>${esc(j.status||'queued')}${j.progress!=null&&j.status==='downloading'?' · '+Math.floor(j.progress)+'%':''}</small>${['downloading','queued'].includes(j.status)?`<div class="download-progress"><span style="width:${Math.max(0,Math.min(100,Number(j.progress)||0))}%"></span></div>`:''}${j.message?`<small>${esc(j.message)}</small>`:''}</div>${['complete','failed','cancelled'].includes(j.status)?`<button data-act="downloadRemove" data-id="${esc(j.id)}" aria-label="Remove item">${I('close','sm')}</button>`:`<button data-act="downloadCancel" data-id="${esc(j.id)}" aria-label="Cancel download">${I('close','sm')}</button>`}</div>`).join(''):`<div class="download-empty">${I('download','lg')}<strong>No downloads yet</strong><small>Completed tracks appear automatically in Your Library.</small></div>`}</div>
 </div>`}
function scrapeInspect(){const url=dlCleanUrl(DL.url);if(!url){DL.error=`Enter a valid ${DL.provider==='spotify'?'Spotify':'YouTube'} track, album, or playlist link.`;render();return}const method=DL.provider==='spotify'?'inspectSpotify':'inspectYouTube';if(typeof MotifAndroid==='undefined'||typeof MotifAndroid[method]!=='function'){DL.error=`The ${DL.provider} extractor is not available in this build.`;render();return}DL.busy=true;DL.items=[];DL.selected.clear();DL.error='';render();try{MotifAndroid[method](url)}catch(e){DL.busy=false;DL.error=String(e);render()}}
function scrapeQueueSelected(){const method=DL.provider==='spotify'?'downloadSpotify':'downloadYouTube';if(typeof MotifAndroid==='undefined'||typeof MotifAndroid[method]!=='function'){DL.error='The Android downloader is unavailable in this build.';render();return}const selection=[...DL.selected].sort((a,b)=>a-b);if(!selection.length)return;if(selection.length>250){DL.error='Choose at most 250 tracks at a time.';render();return}for(const i of selection){const t=DL.items[i];if(t?.url){try{if(DL.provider==='spotify')MotifAndroid.downloadSpotify(t.url,t.title||'Spotify audio');else MotifAndroid.downloadYouTube(t.url,DL.format)}catch(e){DL.error=String(e)}}}DL.selected.clear();render()}
window.motifScrapeEvent=(raw)=>{try{const data=typeof raw==='string'?JSON.parse(raw):raw;if(data.type==='inspect'){DL.busy=false;DL.title=data.title||'Audio';DL.items=Array.isArray(data.items)?data.items:[];DL.selected=new Set(DL.items.map((_,i)=>i));DL.error='';}
else if(data.type==='spotify-connected'){DL.busy=false;DL.spotifyConnected=true;DL.spotifyUsername=data.username||'Premium connected';DL.error=''}
else if(data.type==='error'){DL.busy=false;DL.error=data.message||'Unable to extract this source.'}
else if(data.type==='job'){const i=DL.jobs.findIndex(j=>String(j.id)===String(data.id));if(i<0)DL.jobs.unshift(data);else DL.jobs[i]={...DL.jobs[i],...data};if(data.status==='complete'&&typeof MotifAndroid!=='undefined'&&MotifAndroid.requestLibrary){MotifAndroid.requestLibrary()}}
render()}catch(e){console.error('Downloader callback',e)}};
