# Motif — Downloader integration (Android source prototype)

This is a **source-code change**, not a verified Android APK.

## What it does

- A **Downloads** tab replaces the metadata-only playlist importer.
- YouTube and YouTube Music video/playlist URL inspection via **NewPipeExtractor v0.26.5** (runs on the Android phone).
- Resolves the available *progressive HTTP audio* formats and selects best available, M4A or WebM. No MP3 conversion or false bitrate claims.
- Queues individual files through Android's system `DownloadManager`, which handles retries and notifications; displays real progress and supports cancellation.
- Saves into the public **Music/Motif/** directory and requests a music library rescan after completed transfers.
- Rejects invalid or non-YouTube URLs rather than pretending to have downloaded audio.
- Spotify and Apple Music cards accurately indicate that DRM-protected subscription streams are not directly downloaded; their catalog metadata is not masqueraded as ripped audio.

## Requirements / limitations

- Android API level 24+; Android Gradle Plugin in source; requires internet for extraction/downloads.
- NewPipeExtractor dependency is fetched from JitPack at compile time. Android build not compiled or run in this environment.
- This is an **unverified implementation**. YouTube sometimes changes its extraction requirements and may restrict access; some streams are segmented or require authenticated sessions and are not supported by this initial engine.
- Playlist inspection currently fetches up to 250 entries. Each download is resolved when queued. Selection quality is based on the best available bitrate in a container type.
- `DownloadManager` stores the original compressed stream. No lossy re-encoding or metadata rewriting is performed. Filenames contain the track title; embedded tags, lyrics and album art are **not guaranteed**.
- Android background download tasks are persistent, but the queue's visible state exists only while the Activity is active; a persistent history database is a future improvement.
- Only save media you have rights or permission to download and comply with source terms.

## Build

Open `Motif/` in Android Studio, sync dependencies, and build a debug APK. The source includes the `.github/workflows/android-apk.yml` workflow.

## Licensing

NewPipeExtractor is GPL-3.0 licensed. Linking/distributing the extractor requires that the combined app distribution satisfies its GPL-3.0 obligations, including source availability and notices.

## Tested here

- JavaScript syntax validation with Node.js.
- Browser UI smoke testing with Chromium (layout, tab navigation, URL validation, no seeded media and no fake download jobs).
- Source-file and manifest inspections.

**Not tested here:** Android build success, dependency resolution, downloads from YouTube, playback of downloaded files on a phone, Android media-library rescans. Treat this as an implementation candidate, not a shipping release.
