# Motif QA v1.4.6 — Transfer diagnostics and stream lifetime

- Read the exact remaining byte count instead of requesting data beyond the end of librespot-python's fixed-length stream.
- Handle a closed audio socket with one bounded saved-session recovery, without opening Spotify OAuth again.
- Distinguish storage write failures, truncated audio, connection loss, and invalid Ogg headers.
- Remove partial files after failure or cancellation; never mark a partial stream as a completed download.
- Keep the Motif QA application ID and preserve the v1.4.5 signing identity for in-place updates.
- 27 offline Python tests; source is NOT evidence that Spotify permits exporting the track. Real authenticated audio transfer remains unverified.
