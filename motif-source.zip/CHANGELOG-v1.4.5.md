# Motif QA v1.4.5

- Provider album artwork is displayed next to fetched Spotify tracks and in the download queue, using the cover URLs already included in Spotify metadata.
- Completed tracks download a reduced-size JPEG cover into Motif's private app storage; the library returns this saved cover for offline display. If the cover cannot be fetched, audio saving continues.
- `Find tracks` is renamed to **Fetch**.
- Spotify login is silently recovered on app launch from credential material in app-private storage. The app does not cache login status as a trustworthy flag and does not start OAuth unless the user explicitly chooses Connect.
- Version code increased to support install-over update with the retained Motif QA signing certificate.
- Regression tests added for offline artwork persistence hooks, silent login recovery, and artwork rendering on mobile.

**Known blocker**: The third-party Spotify engine may fail when requesting a protected audio key. A successful login and a successful track-information lookup do **not** demonstrate a successful audio download. No bypass is claimed.
