# Motif — Spotify Premium direct-source integration candidate

## Status: **EXPERIMENTAL; NOT ANDROID-COMPILED OR LIVE-TESTED**

This package extends Motif with an embedded, on-device Spotify source candidate.
It does not require a computer or remote companion *if* its Android Python
runtime and dependencies can be packaged successfully. It is **not** a finished
Spotify downloader or a verified APK. A real Android build is required.

### Implementation

- **Source selection:** Spotify Premium and existing YouTube extractors appear in the Downloads UI. Apple Music is explicitly not connected.
- **Account authentication:** `SpotifyDownloads.connect()` starts an in-app Python `librespot` session. Login is initiated in the external browser and Motif does not request the Spotify password in its WebView.
- **Supported URLs:** Validates Spotify share links for tracks, albums, playlists, and optional `intl-*` paths. Unsupported domains are rejected.
- **Catalog:** Fetches real track metadata and albums/playlist entries using the authenticated Spotify session; no mock tracks are displayed.
- **Audio path:** Attempts to read a `VERY_HIGH` Ogg Vorbis stream through `librespot-python` and writes it to app-private temporary storage. The code does not substitute YouTube audio, call a remote downloading server, or transcode lossy audio into FLAC.
- **Android output:** After a successful transfer, copies the `.ogg` source into Android MediaStore under `Music/Motif/`, tagging title, artist, and album, then notifies Motif to rescan.
- **Queue:** Reports extraction, progress, cancellation, failure, completion to the existing Motif Downloads UI.

### Quality limits

- **Expected upper bound:** 320 kbps Ogg Vorbis with Premium, subject to availability/actual library behavior.
- Spotify advertises lossless up to 24-bit/44.1 kHz FLAC in its official client; this implementation **does not extract FLAC**.
- Never infer that using FLAC as the output extension or converting Ogg to FLAC creates lossless audio.

### Unverified integration blockers

1. **Chaquopy** must package Python 3.11 and the complete Android dependency tree for `librespot==0.0.10`, particularly `pycryptodomex`, `pyogg`, and `zeroconf`. Native-wheel availability is not verified and might stop compilation.
2. **OAuth in a phone browser** must return correctly to librespot's local OAuth endpoint. Login is not tested on Android and cached credentials could fail to persist depending on version.
3. **Spotify account/server compatibility** may change: catalog permission and stream negotiation are not guaranteed; playlists you don't own may be inaccessible.
4. **Playable Ogg and metadata:** A full download must be played from MediaStore; no physical device test was possible.
5. **Security:** Stored credentials currently reside in the app-private files directory. Before production use, credentials should be encrypted with Android Keystore, and account revocation/disconnection handling added.
6. **Background transfers:** The experimental implementation runs from an activity-owned executor. It is not a durable foreground download service; the operating system may terminate it if Motif leaves the foreground.
7. **Android 7–9:** The fallback storage path is app-owned rather than public Music. Tested target is modern Android; old versions need explicit storage permission handling.
8. **Dependencies / ToS:** Spotify's terms prohibit stream ripping. Third-party use can expose a Premium account to rate limits, access failures, or restrictions. Evaluate legal rights and account risk before enabling.

### Tests performed here

- `node --check` of the bundled interface: PASS.
- Python AST/syntax compilation: PASS.
- Unit tests for Spotify URL filtering and metadata normalization (mocked network/session): PASS.
- Chromium browser tests for onboarding, provider selection, URL handling, source list and download callback rendering: PASS.
- **No Android SDK/Gradle available here. No compiled native APK and no live authenticated Spotify extraction test.**

### Build

The project includes `.github/workflows/android-apk.yml` with Java 17 and Gradle setup. This workflow was **not run** for this experimental build; the Chaquopy dependency compatibility remains unverified.

### Relevant references

- https://github.com/ots-downloader/onthespot — reviewed architecture and current limitations (GPL-2.0).
- https://github.com/kokarare1212/librespot-python — underlying client package (Apache-2.0).
- https://chaquo.com/chaquopy/ — Android Python runtime.
- https://developer.spotify.com/terms — Spotify developer/user platform restrictions.

This is original Motif experimental adapter code informed by the public API architecture, not a bundled copy of OnTheSpot's GUI or library.

## October 2026 audit updates

- Playlist inspection now uses `/playlists/{id}/items` rather than the legacy `/tracks` endpoint.
- Catalog requests distinguish network, 401/403/404/429, and malformed-response errors.
- Ogg outputs are checked for their native `OggS` magic bytes before MediaStore import.
- Album and playlist pagination skips unsupported items and advances by API entries (not accepted track count).
- Source-level tests cover pagination, malformed entries, rate limits, URL parsing, and file-integrity validation.
- **Still not compiled for Android and not authenticated against Spotify. No APK is claimed ready.**
