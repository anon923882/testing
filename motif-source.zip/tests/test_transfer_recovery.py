import importlib.util
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

MODULE = Path(__file__).resolve().parents[1] / 'app/src/main/python/motif_spotify.py'
spec = importlib.util.spec_from_file_location('motif_spotify_transfer', str(MODULE))
spotify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(spotify)
TRACK = '5Kjz86OFAoNaABcdEfGHIJ'

class FixedStream:
    def __init__(self, data): self.data=data; self.offset=0; self.requested=[]
    def read(self,n):
        self.requested.append(n)
        if self.offset >= len(self.data): raise AssertionError('Read past EOF')
        out=self.data[self.offset:self.offset+n];self.offset+=len(out);return out

class EofStream(FixedStream):
    def read(self,n):
        if self.offset >= len(self.data): return b''
        return super().read(n)

class FaultStream(FixedStream):
    def read(self,n):raise OSError(9,'Bad file descriptor')

class CopyTests(unittest.TestCase):
    def tearDown(self):spotify._CANCELLED.clear();spotify._SESSION=None
    def test_exact_stream_length_never_reads_past_end(self):
        sample=b'OggS'+b'x'*(128*1024+9)
        with tempfile.TemporaryDirectory() as d:
            stream=FixedStream(sample)
            value=spotify._copy_stream(stream,Path(d)/'one.ogg','j',len(sample),notify=lambda *args:None)
            self.assertEqual(value,len(sample))
            self.assertEqual((Path(d)/'one.ogg').read_bytes(),sample)
            self.assertEqual(stream.requested[-1],13)
    def test_premature_eof_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            st=EofStream(b'OggS')
            with self.assertRaises(spotify.SpotifyError) as caught:
                spotify._copy_stream(st,Path(d)/'bad.ogg','j',15,notify=lambda *args:None)
            self.assertEqual(caught.exception.code,'truncated_stream')
    def test_bad_descriptor_in_read_translated_to_connection_error(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(spotify.SpotifyError) as caught:
                spotify._copy_stream(FaultStream(b'OggS'),Path(d)/'x.ogg','j',4,notify=lambda *args:None)
            self.assertEqual(caught.exception.code,'stale_connection')
    def test_cancel_stops_without_writing(self):
        with tempfile.TemporaryDirectory() as d:
            spotify._CANCELLED.add('jobcancel')
            with self.assertRaises(spotify.SpotifyError) as caught:
                spotify._copy_stream(FixedStream(b'OggS'),Path(d)/'x.ogg','jobcancel',4)
            self.assertEqual(caught.exception.code,'cancelled')
    def test_once_only_reconnect_preserves_login(self):
        with tempfile.TemporaryDirectory() as d:
            creds=Path(d)/'spotify_credentials.json';creds.write_text('test-session')
            invocations=[]
            def transfer(directory,track,job,out):
                invocations.append(track)
                if len(invocations)==1:
                    out.write_bytes(b'partial')
                    raise spotify.SpotifyError('Socket closed', 'stale_connection')
                self.assertFalse(out.exists())
                out.write_bytes(b'OggShello')
                return {'title':'Test song'}
            with patch.object(spotify,'_copy_from_spotify_session',side_effect=transfer),patch.object(spotify,'_reset_closed_session') as reset:
                result=json.loads(spotify.download(d,'https://open.spotify.com/track/'+TRACK,'123'))
            self.assertEqual(result['bytes'],9)
            self.assertEqual(len(invocations),2)
            reset.assert_called_once()
            self.assertEqual(creds.read_text(),'test-session')
    def test_other_error_not_retried_and_partial_removed(self):
        with tempfile.TemporaryDirectory() as d:
            def fail(directory,track,job,out):
                out.write_bytes(b'bad')
                raise spotify.SpotifyError('Key denied','key_denied')
            with patch.object(spotify,'_copy_from_spotify_session',side_effect=fail) as transfer:
                with self.assertRaises(spotify.SpotifyError):
                    spotify.download(d,'https://open.spotify.com/track/'+TRACK,'123')
            transfer.assert_called_once()
            self.assertEqual(list((Path(d)/'temp_audio').iterdir()),[])
    def test_twice_failed_connection_reports_specific_error(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(spotify,'_copy_from_spotify_session',side_effect=spotify.SpotifyError('closed','stale_connection')) as transfer,patch.object(spotify,'_reset_closed_session') as reset:
                with self.assertRaises(spotify.SpotifyError) as caught:
                    spotify.download(d,'https://open.spotify.com/track/'+TRACK,'123')
            self.assertEqual(transfer.call_count,2)
            self.assertEqual(caught.exception.code,'connection_lost')
            reset.assert_called_once()

if __name__ == '__main__': unittest.main()
