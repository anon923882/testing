import sys
import unittest
from unittest.mock import patch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app' / 'src' / 'main' / 'python'))
import motif_spotify as spotify
ID1 = '0'*22
ID2 = '1'*22
ID3 = '2'*22

def item(i, name, album=None):
    return {'id':i,'type':'track','name':name,'artists':[{'name':'Artist'}],
            'album':album or {'name':'Album','images':[{'url':'https://example.com/pic.png'}]},'duration_ms':182000}

class TestSpotify(unittest.TestCase):
 def test_dependency_preflight_reports_missing_module(self):
    # Regression: previous APK was missing urllib3 and failed only after the user tapped Connect.
    with patch('importlib.import_module',side_effect=ModuleNotFoundError("No module named 'urllib3'")):
     with self.assertRaisesRegex(spotify.SpotifyError,'urllib3'):
      spotify.dependency_check()
 def test_unused_pyogg_must_not_be_imported_or_packaged(self):
    # Regression: Android PyOgg 0.5.11a1 searches / during import and raises EACCES.
    # librespot copies the original encrypted-stream output as Ogg bytes; the
    # decoder library is not required. Do not add it back just to make tests pass.
    import ast
    gradle=(Path(__file__).resolve().parents[1]/'app'/'build.gradle').read_text()
    self.assertNotIn("install 'pyogg",gradle)
    import inspect
    source=inspect.getsource(spotify.dependency_check)
    assert '"pyogg"' not in source, source
    def load_without_pyogg(name):
     if name.startswith('pyogg'):
      raise PermissionError(13, 'Permission denied', '/')
     return object()
    with patch('importlib.import_module',side_effect=load_without_pyogg) as mocked:
     self.assertTrue(spotify.dependency_check())
     self.assertFalse(any(str(c.args[0]).startswith('pyogg') for c in mocked.call_args_list))

 def test_connect_checks_dependencies_before_network(self):
    with patch.object(spotify,'dependency_check',side_effect=spotify.SpotifyError('Missing packaging')):
     with patch.object(spotify,'_session') as create_session:
      with self.assertRaisesRegex(spotify.SpotifyError,'Missing packaging'):
       spotify.connect('/temp/no-account')
      create_session.assert_not_called()
 def test_zeroconf_dependency_is_declared(self):
    # zeroconf 0.39.x is running on Python 3.11, where async_timeout is required.
    self.assertIn('"async_timeout"', Path(spotify.__file__).read_text())
    gradle=Path(__file__).resolve().parents[1] / 'app' / 'build.gradle'
    self.assertIn("install 'async-timeout==4.0.3'",gradle.read_text())
 def test_valid_url(self):
    for prefix in ('https://open.spotify.com/track/','https://open.spotify.com/intl-en/track/'):
     self.assertEqual(('track',ID1), spotify.parse_url(prefix+ID1+'?si=example'))
 def test_invalid_urls(self):
    for u in ['http://open.spotify.com/track/'+ID1,'https://fake.open.spotify.com/track/'+ID1,'https://spotify.com/track/'+ID1,'https://open.spotify.com/track/bad','file:///foo','https://open.spotify.com/episode/'+ID1]:
     with self.assertRaises(spotify.SpotifyError, msg=u):spotify.parse_url(u)
 def test_playlist_pagination_current_api(self):
    calls=[]
    def api(session,path,params=None):
     calls.append((path,params))
     if path == 'playlists/'+ID1:return {'name':'Playlist','items':{}}
     if path.endswith('/items'):
      if params['offset']==0:
       return {'items':[{'item':item(ID2,'First')},{'item':{'type':'episode','id':ID3}},{'item':None}],'next':'page2'}
      return {'items':[{'item':item(ID3,'Second')}],'next':None}
     raise AssertionError(path)
    with patch.object(spotify,'_session',return_value=object()),patch.object(spotify,'_request_json',side_effect=api):
     result=__import__('json').loads(spotify.inspect('/tmp','https://open.spotify.com/playlist/'+ID1))
    self.assertEqual(['First','Second'],[x['title'] for x in result['items']]);self.assertEqual([0,3],[p['offset'] for _,p in calls[1:]])
    self.assertEqual('playlists/'+ID1+'/items',calls[1][0])
 def test_track_link_uses_authenticated_metadata_instead_of_web_api(self):
    from unittest.mock import Mock
    from types import SimpleNamespace as NS
    class Id:
      @staticmethod
      def from_base62(value):return value
    import types
    fake_metadata=types.ModuleType('librespot.metadata')
    fake_metadata.TrackId=Id
    album=NS(name='Album',cover=[NS(file_id=b'\x01'*20,width=640,height=640)],artist=[])
    md=NS(name='Direct Track',artist=[NS(name='Direct Artist')],album=album,duration=187000)
    session=Mock();session.api().get_metadata_4_track.return_value=md
    with patch.object(spotify,'_session',return_value=session),patch.object(spotify,'_request_json') as web_api, patch.dict('sys.modules', {'librespot.metadata':fake_metadata}):
      result=__import__('json').loads(spotify.inspect('/tmp','https://open.spotify.com/track/'+ID1))
    web_api.assert_not_called()
    self.assertEqual(result['items'][0]['artist'],'Direct Artist')
    self.assertEqual(result['items'][0]['seconds'],187)
    self.assertEqual(result['items'][0]['cover'],'https://i.scdn.co/image/'+('01'*20))
 def test_album_link_uses_session_metadata_instead_of_web_api(self):
    from unittest.mock import Mock
    from types import SimpleNamespace as NS
    import types
    class Id:
      @staticmethod
      def from_base62(value):return value
      @staticmethod
      def from_hex(value):return NS(to_spotify_uri=lambda:'spotify:track:'+ID2)
    fake_metadata=types.ModuleType('librespot.metadata')
    fake_metadata.AlbumId=Id
    fake_metadata.TrackId=Id
    album=NS(name='My Album',cover=[],artist=[NS(name='Album Artist')],disc=[NS(track=[NS(name='First',gid=b'\x04'*16,artist=[],duration=83000)])])
    session=Mock();session.api().get_metadata_4_album.return_value=album
    with patch.object(spotify,'_session',return_value=session),patch.object(spotify,'_request_json') as web_api, patch.dict('sys.modules',{'librespot.metadata':fake_metadata}):
      result=__import__('json').loads(spotify.inspect('/tmp','https://open.spotify.com/album/'+ID1))
    web_api.assert_not_called()
    self.assertEqual(result['title'],'My Album')
    self.assertEqual(len(result['items']),1)
    self.assertEqual(result['items'][0]['artist'],'Album Artist')
    self.assertEqual(result['items'][0]['url'],'https://open.spotify.com/track/'+ID2)
 def test_native_metadata_429_reports_service_error_no_web_api_retry(self):
    from unittest.mock import Mock
    from types import SimpleNamespace as NS
    import types
    class Id:
      @staticmethod
      def from_base62(v):return v
    fake=types.ModuleType('librespot.metadata');fake.TrackId=Id
    s=Mock();s.api().get_metadata_4_track.side_effect=Exception('HTTP 429')
    with patch.dict('sys.modules',{'librespot.metadata':fake}),patch.object(spotify,'_session',return_value=s),patch.object(spotify,'_request_json') as web:
      with self.assertRaises(spotify.SpotifyError) as er:spotify.inspect('/tmp','https://open.spotify.com/track/'+ID1)
    self.assertEqual(er.exception.code,'metadata_rate_limited')
    web.assert_not_called()
 def test_errors(self):
    with patch.object(spotify,'_session_track_data',side_effect=spotify.SpotifyError('Spotify denied access')):
      with patch.object(spotify,'_session',return_value=object()):
        with self.assertRaisesRegex(spotify.SpotifyError,'denied access'):
          spotify.inspect('/tmp','https://open.spotify.com/track/'+ID1)
 def test_invalid_item(self):
    for v in ({'id':'bad','name':'x'},{'id':ID1,'type':'episode','name':'x'}):
     with self.assertRaises(spotify.SpotifyError):spotify._track_data(v)
 def test_no_false_lossless(self):
    src=Path(spotify.__file__).read_text()
    self.assertIn('if check.read(4) != b"OggS"',src)
    self.assertIn('\"codec\": \"ogg\"', src)

if __name__=='__main__':unittest.main(verbosity=2)

class TestSpotifyRateLimits(unittest.TestCase):
 def setUp(self):
  spotify._RATE_LIMIT_UNTIL = 0.0
 def tearDown(self):
  spotify._RATE_LIMIT_UNTIL = 0.0
 def test_429_with_retry_after_sets_cooldown_and_avoids_second_request(self):
  from unittest.mock import Mock
  reply = Mock(status_code=429, headers={'Retry-After':'42'})
  reply.json.return_value={'error':{'status':429,'message':'Too many requests'}}
  session=Mock(); session.tokens.return_value={'user-read-email':'test-token'}
  with patch('requests.get', return_value=reply) as getter:
   with self.assertRaises(spotify.SpotifyError) as e:spotify._request_json(session,'tracks/'+ID1)
   self.assertEqual('rate_limited',e.exception.code)
   self.assertEqual(42,e.exception.retry_after)
   with self.assertRaises(spotify.SpotifyError) as second:spotify._request_json(session,'tracks/'+ID1)
   self.assertEqual('rate_limited',second.exception.code)
   self.assertEqual(1,getter.call_count)
 def test_429_quota_is_not_mistaken_for_short_rate_limit(self):
  from unittest.mock import Mock
  reply=Mock(status_code=429,headers={'Retry-After':'60'})
  reply.json.return_value={'error':{'reason':'QUOTA_EXCEEDED'}}
  session=Mock(); session.tokens.return_value={'user-read-email':'token'}
  with patch('requests.get',return_value=reply):
   with self.assertRaises(spotify.SpotifyError) as e:spotify._request_json(session,'tracks/'+ID1)
  self.assertEqual('quota_exceeded',e.exception.code)
  self.assertEqual(0,spotify._rate_limit_wait())
 def test_search_limits_results_to_ten_and_skips_invalid_items(self):
  calls=[]
  def api(session,path,params=None):
   calls.append((path,params));return {'tracks':{'items':[item(ID1,'Moon and Stars'),{'type':'episode','id':ID2}]}}
  with patch.object(spotify,'_session',return_value=object()), patch.object(spotify,'_request_json',side_effect=api):
   result=__import__('json').loads(spotify.search('/tmp','moon and stars'))
  self.assertEqual('search',calls[0][0]);self.assertEqual(10,calls[0][1]['limit'])
  self.assertEqual(1,len(result['items']))
  self.assertEqual('Moon and Stars',result['items'][0]['title'])
 def test_inspect_safe_returns_structured_error(self):
  with patch.object(spotify,'inspect',side_effect=spotify.SpotifyError('Wait for Spotify', 'rate_limited', 50)):
   value=__import__('json').loads(spotify.inspect_safe('/tmp','url'))
  self.assertEqual(('rate_limited',50),(value['code'],value['retryAfter']))
