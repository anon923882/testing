import sys
import unittest
from unittest.mock import patch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app' / 'src' / 'main' / 'python'))
import motif_spotify as spotify
ID1 = '0'*22
ID2 = '1'*22
ID3 = '2'*22

def item(i, name, album=None):
    return {'id':i,'type':'track','name':name,'artists':[{'name':'Artist'}],
            'album':album or {'name':'Album','images':[{'url':'https://example.com/pic.png'}]},'duration_ms':182000}

class TestSpotify(unittest.TestCase):
 def test_valid_url(self):
    for prefix in ('https://open.spotify.com/track/','https://open.spotify.com/intl-en/track/'):
     self.assertEqual(('track',ID1), spotify.parse_url(prefix+ID1+'?si=example'))
 def test_invalid_urls(self):
    for u in ['http://open.spotify.com/track/'+ID1,'https://fake.open.spotify.com/track/'+ID1,'https://spotify.com/track/'+ID1,'https://open.spotify.com/track/bad','file:///foo','https://open.spotify.com/episode/'+ID1]:
     with self.assertRaises(spotify.SpotifyError, msg=u):spotify.parse_url(u)
 def test_playlist_pagination_current_api(self):
    calls=[]
    def api(session,path,params=None):
     calls.append((path,params))
     if path == 'playlists/'+ID1:return {'name':'Playlist','items':{}}
     if path.endswith('/items'):
      if params['offset']==0:
       return {'items':[{'item':item(ID2,'First')},{'item':{'type':'episode','id':ID3}},{'item':None}],'next':'page2'}
      return {'items':[{'item':item(ID3,'Second')}],'next':None}
     raise AssertionError(path)
    with patch.object(spotify,'_session',return_value=object()),patch.object(spotify,'_request_json',side_effect=api):
     result=__import__('json').loads(spotify.inspect('/tmp','https://open.spotify.com/playlist/'+ID1))
    self.assertEqual(['First','Second'],[x['title'] for x in result['items']]);self.assertEqual([0,3],[p['offset'] for _,p in calls[1:]])
    self.assertEqual('playlists/'+ID1+'/items',calls[1][0])
 def test_album_pagination(self):
    calls=[]
    def api(sess,path,params=None):
     calls.append((path,params));a={'name':'Album','images':[],'tracks':{'items':[item(ID2,'One'),{'id':'bad','type':'track'}],'next':'page2'}}
     if path=='albums/'+ID1:return a
     return {'items':[item(ID3,'Two')],'next':None}
    with patch.object(spotify,'_session',return_value=object()),patch.object(spotify,'_request_json',side_effect=api):
     r=__import__('json').loads(spotify.inspect('/tmp','https://open.spotify.com/album/'+ID1))
    self.assertEqual(2,len(r['items']));self.assertEqual(2,calls[1][1]['offset'])
 def test_errors(self):
    class ReqError(Exception):pass
    class Reply:
     def __init__(self,code):self.status_code=code
    class R:
     class RequestException(Exception):pass
     @staticmethod
     def get(*a,**kw):return Reply(403)
    with patch.object(spotify,'_request_json',side_effect=spotify.SpotifyError('Spotify denied access')):
     with patch.object(spotify,'_session',return_value=object()):
      with self.assertRaisesRegex(spotify.SpotifyError,'denied access'):spotify.inspect('/tmp','https://open.spotify.com/track/'+ID1)
 def test_invalid_item(self):
    for v in ({'id':'bad','name':'x'},{'id':ID1,'type':'episode','name':'x'}):
     with self.assertRaises(spotify.SpotifyError):spotify._track_data(v)
 def test_no_false_lossless(self):
    src=Path(spotify.__file__).read_text()
    self.assertIn('if check.read(4) != b"OggS"',src)
    self.assertIn('\"codec\": \"ogg\"', src)

if __name__=='__main__':unittest.main(verbosity=2)
