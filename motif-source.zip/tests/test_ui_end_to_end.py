"""Browser interaction regression for Motif. No live Spotify credentials required.
Real Android status insets, DownloadManager and native OAuth need device tests.
"""
import functools
import http.server
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
handler=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(ROOT/'app/src/main/assets'))
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
URL=f'http://127.0.0.1:{server.server_port}/index.html'

FAKE_BRIDGE='''
window.__calls=[];
window.MotifAndroid={
 requestLibrary:()=>window.__calls.push('scan'),
 importAudio:()=>window.__calls.push('import'),
 setAutoAddDownloads:(v)=>window.__calls.push('auto:'+v),
 revealDownloadedTrack:(filename)=>window.__calls.push('reveal:'+filename),
 connectSpotify:()=>window.__calls.push('connect'),
 inspectSpotify:(url)=>window.__calls.push('inspectSpotify:'+url),
 downloadSpotify:(url,title)=>window.__calls.push('downloadSpotify:'+url),
 inspectYouTube:(url)=>window.__calls.push('inspectYouTube:'+url),
 downloadYouTube:(url,quality)=>window.__calls.push('downloadYouTube:'+url),
 play:()=>window.__calls.push('play'), toggle:()=>{},seek:()=>{},setShuffle:()=>{},setRepeat:()=>{},setQueue:()=>{}
};'''

def click(page, act, **attrs):
    selector=f'[data-act="{act}"]'+''.join(f'[data-{k.replace("_","-")}="{v}"]' for k,v in attrs.items())
    page.locator(selector).first.click(timeout=10000)

def setup_account(page):
    click(page,'newAccount')
    page.locator('#profile-name').fill('QA Listener')
    page.locator('#profile-handle').fill('qa_listener')
    click(page,'saveProfile')
    assert page.locator('[data-act="tab"][data-value="home"]').count()==1

def track_fixture(count=90):
    return {'tracks':[{'id':str(i),'uri':f'content://media/external/audio/media/{i}',
      'title':f'Song {i:03d}','artist':('Living In A Box' if i%3==0 else 'Test Artist'),
      'album':'Sample Album','seconds':203,'bytes':4*1024*1024,'dateAdded':2000000000-i}
      for i in range(1,count+1)], 'freeBytes':3*1024**3}

def run_case(page):
    errors=[]
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.goto(URL,wait_until='domcontentloaded')
    setup_account(page)
    # Navigation should maintain a single mounted screen during fast switches.
    for tab in ['library','search','home','import','library','import','home']*3:
        click(page,'tab',value=tab)
        assert page.locator('#app > .screen').count()==1,(tab,page.locator('#app > .screen').count())
    # Native catalog and metadata rendering.
    payload=track_fixture()
    page.evaluate('payload=>window.motifLibraryReceived(JSON.stringify(payload))',payload)
    click(page,'tab',value='library')
    click(page,'libFilter',value='Tracks')
    assert page.locator('.track').count()==90
    assert page.locator('.track').first.locator('.meta').inner_text() in ('Test Artist','Living In A Box')
    # Check deep scroll: even bottom tracks must be reachable.
    sc=page.locator('#app > .screen')
    before=sc.evaluate('(e)=>e.scrollTop')
    sc.evaluate('(e)=>{e.scrollTop=e.scrollHeight}')
    assert sc.evaluate('(e)=>e.scrollTop')>before
    assert sc.evaluate('(e)=>e.scrollTop')>400
    # Search and filtered library.
    click(page,'tab',value='search')
    page.locator('#search-input').fill('Song 002')
    assert page.locator('.track').count()==1
    click(page,'tab',value='import')
    assert page.locator('h1').filter(has_text='Downloads').count()==1
    assert page.locator('#download-autoadd').is_checked()
    page.locator('#download-autoadd').uncheck()
    assert not page.locator('#download-autoadd').is_checked()
    assert 'auto:false' in page.evaluate('window.__calls')
    # Spotify auth button must give immediate visible feedback and invoke bridge.
    click(page,'spotifyConnect')
    assert 'connect' in page.evaluate('window.__calls')
    assert page.get_by_text('Opening Spotify login…').count()>=1
    page.evaluate('window.motifScrapeEvent(JSON.stringify({type:"spotify-login-opening",message:"Opening browser"}))')
    assert page.get_by_text('Spotify sign-in opened in your browser').count()==1
    page.evaluate('window.motifScrapeEvent(JSON.stringify({type:"error",provider:"spotify",message:"Authentication failed: test"}))')
    assert page.get_by_text('Authentication failed: test').count()==1
    # Spotify catalog inspection and queue progress callbacks.
    page.locator('#download-url').fill('https://open.spotify.com/track/4uLU6hMCjMI75M1A2tKUQC')
    click(page,'downloadInspect')
    assert any(x.startswith('inspectSpotify:') for x in page.evaluate('window.__calls'))
    page.evaluate('window.motifScrapeEvent(JSON.stringify({type:"inspect",provider:"spotify",title:"Demo",items:[{title:"Demo Song",artist:"Artist",url:"https://open.spotify.com/track/4uLU6hMCjMI75M1A2tKUQC"}]}))')
    click(page,'downloadQueue')
    assert any(x.startswith('downloadSpotify:') for x in page.evaluate('window.__calls'))
    page.evaluate('window.motifScrapeEvent(JSON.stringify({type:"job",provider:"spotify",id:"job-1",title:"Demo Song",status:"downloading",progress:36}))')
    assert page.locator('.download-progress').count()>=1
    page.evaluate('window.motifScrapeEvent(JSON.stringify({type:"job",provider:"spotify",id:"job-1",title:"Demo Song",status:"complete",filename:"demo.ogg",progress:100}))')
    assert page.locator('[data-act="downloadReveal"]').count()==1
    click(page,'downloadReveal')
    assert 'reveal:demo.ogg' in page.evaluate('window.__calls')
    # Settings option must survive navigation and reload.
    click(page,'tab',value='home')
    click(page,'settings')
    assert 'Add downloads to library' in page.locator('.screen').inner_text()
    page.reload(wait_until='domcontentloaded')
    assert page.evaluate('JSON.parse(localStorage.getItem("motif-state")).opts.autoAddDownloads') is False
    # New playlist and preferences persistence.
    click(page,'tab',value='library')
    click(page,'create')
    assert page.locator('#playlist-name').count()==1
    page.locator('#playlist-name').fill('Road Trip')
    page.locator('#playlist-desc').fill('Weekend mix')
    click(page,'savePlaylist')
    click(page,'tab',value='library')
    assert 'Road Trip' in page.locator('.screen').inner_text()
    page.screenshot(path=str(ROOT/'qa-stress-library.png'))
    assert not errors,errors
    print('PASS: onboarding, 21 rapid tabs, 90-track scroll, metadata display, search, downloads toggle, Spotify auth feedback, URL inspect, progress, queue, opt-in, playlist, persistence')

if __name__=='__main__':
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        try:
            ctx=browser.new_context(viewport={'width':393,'height':852},device_scale_factor=2,is_mobile=True,has_touch=True)
            page=ctx.new_page()
            page.add_init_script(FAKE_BRIDGE)
            run_case(page)
        finally:browser.close()
