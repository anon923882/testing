# Motif — Android music player (Spotify Premium integration candidate)

This Android Studio project contains the current Motif UI, local music player,
YouTube extraction candidate, and an **experimental Spotify Premium direct-source
module**. The Spotify module has not been compiled or tested on Android. It is
NOT a working/released APK.

**Start with [SPOTIFY-EXPERIMENT.md](SPOTIFY-EXPERIMENT.md)** for exact feature
scope, dependencies, risks, limitations, and verification status.

Build path: Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, Android SDK 35,
and Chaquopy Python SDK 17.0.0. The included workflow can be adapted for CI.

Files:
- `app/src/main/python/motif_spotify.py`: direct-source candidate; OAuth, link
  parsing, Spotify catalog lookup, stream transfer, progress/cancellation.
- `app/src/main/java/com/motif/player/SpotifyDownloads.java`: Java/Python
  bridge and Android MediaStore import, no remote server required.
- `app/src/main/assets/app.js`: account UI, provider selectors, queue, progress.
- `app/src/main/java/com/motif/player/MainActivity.java`: native bridge API.

Spotify credentials should not be supplied directly to a WebView or copied into
Motif development logs. Spotify Premium does not authorize unrestricted export
of protected files; the account owner is responsible for compliance.


## v1.4.2 Android Spotify QA
- Removed unused PyOgg, which blocked initialization on Android with a root directory PermissionError.
- Spotify's extraction path copies original Ogg bytes; PyOgg was not imported by the packaged librespot code.
- Added a regression that fails if PyOgg is reintroduced in Python startup checks or Gradle.
- This remains an experimental third-party Spotify client; a successful live Premium login/download cannot be asserted without device authentication.
